import{siteConfig as Di}from"./site-config-CqbHk6xq.js";import{_ as rd}from"./preload-helper-BZTpFI01.js";/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Er="160",cd=0,pc=1,ld=2,Tr=1,jl=2,Rn=3,Yn=0,He=1,me=2,Wn=0,os=1,Vo=2,fc=3,mc=4,hd=5,hi=100,dd=101,ud=102,gc=103,wc=104,pd=200,fd=201,md=202,gd=203,dr=204,ur=205,wd=206,yd=207,xd=208,vd=209,_d=210,Md=211,Sd=212,bd=213,Ed=214,Td=0,Ad=1,Cd=2,Wo=3,Rd=4,Ld=5,Pd=6,Id=7,Ar=0,Dd=1,Ud=2,Xn=0,Kl=1,Nd=2,Bd=3,Fd=4,Od=5,zd=6,Jl=300,rs=301,cs=302,pr=303,fr=304,ta=306,mr=1e3,ln=1001,gr=1002,ze=1003,yc=1004,Aa=1005,tn=1006,kd=1007,Us=1008,qn=1009,Gd=1010,Hd=1011,Cr=1012,Ql=1013,Gn=1014,Hn=1015,Ns=1016,th=1017,eh=1018,ui=1020,Vd=1021,hn=1023,Wd=1024,Xd=1025,pi=1026,ls=1027,qd=1028,nh=1029,Yd=1030,ih=1031,sh=1033,Ca=33776,Ra=33777,La=33778,Pa=33779,xc=35840,vc=35841,_c=35842,Mc=35843,oh=36196,Sc=37492,bc=37496,Ec=37808,Tc=37809,Ac=37810,Cc=37811,Rc=37812,Lc=37813,Pc=37814,Ic=37815,Dc=37816,Uc=37817,Nc=37818,Bc=37819,Fc=37820,Oc=37821,Ia=36492,zc=36494,kc=36495,$d=36283,Gc=36284,Hc=36285,Vc=36286,ah=3e3,fi=3001,Zd=3200,jd=3201,rh=0,Kd=1,nn="",Pe="srgb",Un="srgb-linear",Rr="display-p3",ea="display-p3-linear",Xo="linear",ue="srgb",qo="rec709",Yo="p3",Ui=7680,Wc=519,Jd=512,Qd=513,tu=514,ch=515,eu=516,nu=517,iu=518,su=519,wr=35044,Xc="300 es",yr=1035,In=2e3,$o=2001;class ds{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;const n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;const i=this._listeners[t];if(i!==void 0){const s=i.indexOf(e);s!==-1&&i.splice(s,1)}}dispatchEvent(t){if(this._listeners===void 0)return;const n=this._listeners[t.type];if(n!==void 0){t.target=this;const i=n.slice(0);for(let s=0,a=i.length;s<a;s++)i[s].call(this,t);t.target=null}}}const De=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Da=Math.PI/180,Zo=180/Math.PI;function Dn(){const o=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(De[o&255]+De[o>>8&255]+De[o>>16&255]+De[o>>24&255]+"-"+De[t&255]+De[t>>8&255]+"-"+De[t>>16&15|64]+De[t>>24&255]+"-"+De[e&63|128]+De[e>>8&255]+"-"+De[e>>16&255]+De[e>>24&255]+De[n&255]+De[n>>8&255]+De[n>>16&255]+De[n>>24&255]).toLowerCase()}function Ne(o,t,e){return Math.max(t,Math.min(e,o))}function ou(o,t){return(o%t+t)%t}function Ua(o,t,e){return(1-e)*o+e*t}function qc(o){return(o&o-1)===0&&o!==0}function xr(o){return Math.pow(2,Math.floor(Math.log(o)/Math.LN2))}function Ln(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function he(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}class dt{constructor(t=0,e=0){dt.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Ne(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),i=Math.sin(e),s=this.x-t.x,a=this.y-t.y;return this.x=s*n-a*i+t.x,this.y=s*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Qt{constructor(t,e,n,i,s,a,r,c,l){Qt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,r,c,l)}set(t,e,n,i,s,a,r,c,l){const h=this.elements;return h[0]=t,h[1]=i,h[2]=r,h[3]=e,h[4]=s,h[5]=c,h[6]=n,h[7]=a,h[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],r=n[3],c=n[6],l=n[1],h=n[4],d=n[7],u=n[2],p=n[5],g=n[8],y=i[0],m=i[3],f=i[6],_=i[1],x=i[4],M=i[7],R=i[2],A=i[5],E=i[8];return s[0]=a*y+r*_+c*R,s[3]=a*m+r*x+c*A,s[6]=a*f+r*M+c*E,s[1]=l*y+h*_+d*R,s[4]=l*m+h*x+d*A,s[7]=l*f+h*M+d*E,s[2]=u*y+p*_+g*R,s[5]=u*m+p*x+g*A,s[8]=u*f+p*M+g*E,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8];return e*a*h-e*r*l-n*s*h+n*r*c+i*s*l-i*a*c}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8],d=h*a-r*l,u=r*c-h*s,p=l*s-a*c,g=e*d+n*u+i*p;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const y=1/g;return t[0]=d*y,t[1]=(i*l-h*n)*y,t[2]=(r*n-i*a)*y,t[3]=u*y,t[4]=(h*e-i*c)*y,t[5]=(i*s-r*e)*y,t[6]=p*y,t[7]=(n*c-l*e)*y,t[8]=(a*e-n*s)*y,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,s,a,r){const c=Math.cos(s),l=Math.sin(s);return this.set(n*c,n*l,-n*(c*a+l*r)+a+t,-i*l,i*c,-i*(-l*a+c*r)+r+e,0,0,1),this}scale(t,e){return this.premultiply(Na.makeScale(t,e)),this}rotate(t){return this.premultiply(Na.makeRotation(-t)),this}translate(t,e){return this.premultiply(Na.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const Na=new Qt;function lh(o){for(let t=o.length-1;t>=0;--t)if(o[t]>=65535)return!0;return!1}function jo(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function au(){const o=jo("canvas");return o.style.display="block",o}const Yc={};function Rs(o){o in Yc||(Yc[o]=!0,console.warn(o))}const $c=new Qt().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Zc=new Qt().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),ho={[Un]:{transfer:Xo,primaries:qo,toReference:o=>o,fromReference:o=>o},[Pe]:{transfer:ue,primaries:qo,toReference:o=>o.convertSRGBToLinear(),fromReference:o=>o.convertLinearToSRGB()},[ea]:{transfer:Xo,primaries:Yo,toReference:o=>o.applyMatrix3(Zc),fromReference:o=>o.applyMatrix3($c)},[Rr]:{transfer:ue,primaries:Yo,toReference:o=>o.convertSRGBToLinear().applyMatrix3(Zc),fromReference:o=>o.applyMatrix3($c).convertLinearToSRGB()}},ru=new Set([Un,ea]),re={enabled:!0,_workingColorSpace:Un,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(o){if(!ru.has(o))throw new Error(`Unsupported working color space, "${o}".`);this._workingColorSpace=o},convert:function(o,t,e){if(this.enabled===!1||t===e||!t||!e)return o;const n=ho[t].toReference,i=ho[e].fromReference;return i(n(o))},fromWorkingColorSpace:function(o,t){return this.convert(o,this._workingColorSpace,t)},toWorkingColorSpace:function(o,t){return this.convert(o,t,this._workingColorSpace)},getPrimaries:function(o){return ho[o].primaries},getTransfer:function(o){return o===nn?Xo:ho[o].transfer}};function as(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function Ba(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Ni;class hh{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Ni===void 0&&(Ni=jo("canvas")),Ni.width=t.width,Ni.height=t.height;const n=Ni.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Ni}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=jo("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height),s=i.data;for(let a=0;a<s.length;a++)s[a]=as(s[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(as(e[n]/255)*255):e[n]=as(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let cu=0;class dh{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:cu++}),this.uuid=Dn(),this.data=t,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let a=0,r=i.length;a<r;a++)i[a].isDataTexture?s.push(Fa(i[a].image)):s.push(Fa(i[a]))}else s=Fa(i);n.url=s}return e||(t.images[this.uuid]=n),n}}function Fa(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?hh.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let lu=0;class Ve extends ds{constructor(t=Ve.DEFAULT_IMAGE,e=Ve.DEFAULT_MAPPING,n=ln,i=ln,s=tn,a=Us,r=hn,c=qn,l=Ve.DEFAULT_ANISOTROPY,h=nn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:lu++}),this.uuid=Dn(),this.name="",this.source=new dh(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=a,this.anisotropy=l,this.format=r,this.internalFormat=null,this.type=c,this.offset=new dt(0,0),this.repeat=new dt(1,1),this.center=new dt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Qt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof h=="string"?this.colorSpace=h:(Rs("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=h===fi?Pe:nn),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Jl)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case mr:t.x=t.x-Math.floor(t.x);break;case ln:t.x=t.x<0?0:1;break;case gr:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case mr:t.y=t.y-Math.floor(t.y);break;case ln:t.y=t.y<0?0:1;break;case gr:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Rs("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===Pe?fi:ah}set encoding(t){Rs("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=t===fi?Pe:nn}}Ve.DEFAULT_IMAGE=null;Ve.DEFAULT_MAPPING=Jl;Ve.DEFAULT_ANISOTROPY=1;class ge{constructor(t=0,e=0,n=0,i=1){ge.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*s,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*s,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*s,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*s,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,s;const c=t.elements,l=c[0],h=c[4],d=c[8],u=c[1],p=c[5],g=c[9],y=c[2],m=c[6],f=c[10];if(Math.abs(h-u)<.01&&Math.abs(d-y)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+y)<.1&&Math.abs(g+m)<.1&&Math.abs(l+p+f-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const x=(l+1)/2,M=(p+1)/2,R=(f+1)/2,A=(h+u)/4,E=(d+y)/4,I=(g+m)/4;return x>M&&x>R?x<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(x),i=A/n,s=E/n):M>R?M<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(M),n=A/i,s=I/i):R<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(R),n=E/s,i=I/s),this.set(n,i,s,e),this}let _=Math.sqrt((m-g)*(m-g)+(d-y)*(d-y)+(u-h)*(u-h));return Math.abs(_)<.001&&(_=1),this.x=(m-g)/_,this.y=(d-y)/_,this.z=(u-h)/_,this.w=Math.acos((l+p+f-1)/2),this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class hu extends ds{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new ge(0,0,t,e),this.scissorTest=!1,this.viewport=new ge(0,0,t,e);const i={width:t,height:e,depth:1};n.encoding!==void 0&&(Rs("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),n.colorSpace=n.encoding===fi?Pe:nn),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:tn,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},n),this.texture=new Ve(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps,this.texture.internalFormat=n.internalFormat,this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}setSize(t,e,n=1){(this.width!==t||this.height!==e||this.depth!==n)&&(this.width=t,this.height=e,this.depth=n,this.texture.image.width=t,this.texture.image.height=e,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.texture=t.texture.clone(),this.texture.isRenderTargetTexture=!0;const e=Object.assign({},t.texture.image);return this.texture.source=new dh(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class mi extends hu{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class uh extends Ve{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=ze,this.minFilter=ze,this.wrapR=ln,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class du extends Ve{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=ze,this.minFilter=ze,this.wrapR=ln,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class ks{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,s,a,r){let c=n[i+0],l=n[i+1],h=n[i+2],d=n[i+3];const u=s[a+0],p=s[a+1],g=s[a+2],y=s[a+3];if(r===0){t[e+0]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d;return}if(r===1){t[e+0]=u,t[e+1]=p,t[e+2]=g,t[e+3]=y;return}if(d!==y||c!==u||l!==p||h!==g){let m=1-r;const f=c*u+l*p+h*g+d*y,_=f>=0?1:-1,x=1-f*f;if(x>Number.EPSILON){const R=Math.sqrt(x),A=Math.atan2(R,f*_);m=Math.sin(m*A)/R,r=Math.sin(r*A)/R}const M=r*_;if(c=c*m+u*M,l=l*m+p*M,h=h*m+g*M,d=d*m+y*M,m===1-r){const R=1/Math.sqrt(c*c+l*l+h*h+d*d);c*=R,l*=R,h*=R,d*=R}}t[e]=c,t[e+1]=l,t[e+2]=h,t[e+3]=d}static multiplyQuaternionsFlat(t,e,n,i,s,a){const r=n[i],c=n[i+1],l=n[i+2],h=n[i+3],d=s[a],u=s[a+1],p=s[a+2],g=s[a+3];return t[e]=r*g+h*d+c*p-l*u,t[e+1]=c*g+h*u+l*d-r*p,t[e+2]=l*g+h*p+r*u-c*d,t[e+3]=h*g-r*d-c*u-l*p,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,i=t._y,s=t._z,a=t._order,r=Math.cos,c=Math.sin,l=r(n/2),h=r(i/2),d=r(s/2),u=c(n/2),p=c(i/2),g=c(s/2);switch(a){case"XYZ":this._x=u*h*d+l*p*g,this._y=l*p*d-u*h*g,this._z=l*h*g+u*p*d,this._w=l*h*d-u*p*g;break;case"YXZ":this._x=u*h*d+l*p*g,this._y=l*p*d-u*h*g,this._z=l*h*g-u*p*d,this._w=l*h*d+u*p*g;break;case"ZXY":this._x=u*h*d-l*p*g,this._y=l*p*d+u*h*g,this._z=l*h*g+u*p*d,this._w=l*h*d-u*p*g;break;case"ZYX":this._x=u*h*d-l*p*g,this._y=l*p*d+u*h*g,this._z=l*h*g-u*p*d,this._w=l*h*d+u*p*g;break;case"YZX":this._x=u*h*d+l*p*g,this._y=l*p*d+u*h*g,this._z=l*h*g-u*p*d,this._w=l*h*d-u*p*g;break;case"XZY":this._x=u*h*d-l*p*g,this._y=l*p*d-u*h*g,this._z=l*h*g+u*p*d,this._w=l*h*d+u*p*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],i=e[4],s=e[8],a=e[1],r=e[5],c=e[9],l=e[2],h=e[6],d=e[10],u=n+r+d;if(u>0){const p=.5/Math.sqrt(u+1);this._w=.25/p,this._x=(h-c)*p,this._y=(s-l)*p,this._z=(a-i)*p}else if(n>r&&n>d){const p=2*Math.sqrt(1+n-r-d);this._w=(h-c)/p,this._x=.25*p,this._y=(i+a)/p,this._z=(s+l)/p}else if(r>d){const p=2*Math.sqrt(1+r-n-d);this._w=(s-l)/p,this._x=(i+a)/p,this._y=.25*p,this._z=(c+h)/p}else{const p=2*Math.sqrt(1+d-n-r);this._w=(a-i)/p,this._x=(s+l)/p,this._y=(c+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ne(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,i=t._y,s=t._z,a=t._w,r=e._x,c=e._y,l=e._z,h=e._w;return this._x=n*h+a*r+i*l-s*c,this._y=i*h+a*c+s*r-n*l,this._z=s*h+a*l+n*c-i*r,this._w=a*h-n*r-i*c-s*l,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,i=this._y,s=this._z,a=this._w;let r=a*t._w+n*t._x+i*t._y+s*t._z;if(r<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,r=-r):this.copy(t),r>=1)return this._w=a,this._x=n,this._y=i,this._z=s,this;const c=1-r*r;if(c<=Number.EPSILON){const p=1-e;return this._w=p*a+e*this._w,this._x=p*n+e*this._x,this._y=p*i+e*this._y,this._z=p*s+e*this._z,this.normalize(),this}const l=Math.sqrt(c),h=Math.atan2(l,r),d=Math.sin((1-e)*h)/l,u=Math.sin(e*h)/l;return this._w=a*d+this._w*u,this._x=n*d+this._x*u,this._y=i*d+this._y*u,this._z=s*d+this._z*u,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=Math.random(),e=Math.sqrt(1-t),n=Math.sqrt(t),i=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(e*Math.cos(i),n*Math.sin(s),n*Math.cos(s),e*Math.sin(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class L{constructor(t=0,e=0,n=0){L.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(jc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(jc.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6]*i,this.y=s[1]*e+s[4]*n+s[7]*i,this.z=s[2]*e+s[5]*n+s[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,i=this.z,s=t.elements,a=1/(s[3]*e+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*e+s[4]*n+s[8]*i+s[12])*a,this.y=(s[1]*e+s[5]*n+s[9]*i+s[13])*a,this.z=(s[2]*e+s[6]*n+s[10]*i+s[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,i=this.z,s=t.x,a=t.y,r=t.z,c=t.w,l=2*(a*i-r*n),h=2*(r*e-s*i),d=2*(s*n-a*e);return this.x=e+c*l+a*d-r*h,this.y=n+c*h+r*l-s*d,this.z=i+c*d+s*h-a*l,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,i=this.z,s=t.elements;return this.x=s[0]*e+s[4]*n+s[8]*i,this.y=s[1]*e+s[5]*n+s[9]*i,this.z=s[2]*e+s[6]*n+s[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,i=t.y,s=t.z,a=e.x,r=e.y,c=e.z;return this.x=i*c-s*r,this.y=s*a-n*c,this.z=n*r-i*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Oa.copy(this).projectOnVector(t),this.sub(Oa)}reflect(t){return this.sub(Oa.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(Ne(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=(Math.random()-.5)*2,e=Math.random()*Math.PI*2,n=Math.sqrt(1-t**2);return this.x=n*Math.cos(e),this.y=n*Math.sin(e),this.z=t,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Oa=new L,jc=new ks;class Gs{constructor(t=new L(1/0,1/0,1/0),e=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(an.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(an.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=an.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const s=n.getAttribute("position");if(e===!0&&s!==void 0&&t.isInstancedMesh!==!0)for(let a=0,r=s.count;a<r;a++)t.isMesh===!0?t.getVertexPosition(a,an):an.fromBufferAttribute(s,a),an.applyMatrix4(t.matrixWorld),this.expandByPoint(an);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),uo.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),uo.copy(n.boundingBox)),uo.applyMatrix4(t.matrixWorld),this.union(uo)}const i=t.children;for(let s=0,a=i.length;s<a;s++)this.expandByObject(i[s],e);return this}containsPoint(t){return!(t.x<this.min.x||t.x>this.max.x||t.y<this.min.y||t.y>this.max.y||t.z<this.min.z||t.z>this.max.z)}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return!(t.max.x<this.min.x||t.min.x>this.max.x||t.max.y<this.min.y||t.min.y>this.max.y||t.max.z<this.min.z||t.min.z>this.max.z)}intersectsSphere(t){return this.clampPoint(t.center,an),an.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(_s),po.subVectors(this.max,_s),Bi.subVectors(t.a,_s),Fi.subVectors(t.b,_s),Oi.subVectors(t.c,_s),Bn.subVectors(Fi,Bi),Fn.subVectors(Oi,Fi),si.subVectors(Bi,Oi);let e=[0,-Bn.z,Bn.y,0,-Fn.z,Fn.y,0,-si.z,si.y,Bn.z,0,-Bn.x,Fn.z,0,-Fn.x,si.z,0,-si.x,-Bn.y,Bn.x,0,-Fn.y,Fn.x,0,-si.y,si.x,0];return!za(e,Bi,Fi,Oi,po)||(e=[1,0,0,0,1,0,0,0,1],!za(e,Bi,Fi,Oi,po))?!1:(fo.crossVectors(Bn,Fn),e=[fo.x,fo.y,fo.z],za(e,Bi,Fi,Oi,po))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,an).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(an).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(bn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),bn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),bn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),bn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),bn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),bn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),bn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),bn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(bn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}}const bn=[new L,new L,new L,new L,new L,new L,new L,new L],an=new L,uo=new Gs,Bi=new L,Fi=new L,Oi=new L,Bn=new L,Fn=new L,si=new L,_s=new L,po=new L,fo=new L,oi=new L;function za(o,t,e,n,i){for(let s=0,a=o.length-3;s<=a;s+=3){oi.fromArray(o,s);const r=i.x*Math.abs(oi.x)+i.y*Math.abs(oi.y)+i.z*Math.abs(oi.z),c=t.dot(oi),l=e.dot(oi),h=n.dot(oi);if(Math.max(-Math.max(c,l,h),Math.min(c,l,h))>r)return!1}return!0}const uu=new Gs,Ms=new L,ka=new L;class Hs{constructor(t=new L,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):uu.setFromPoints(t).getCenter(n);let i=0;for(let s=0,a=t.length;s<a;s++)i=Math.max(i,n.distanceToSquared(t[s]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ms.subVectors(t,this.center);const e=Ms.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(Ms,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(ka.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ms.copy(t.center).add(ka)),this.expandByPoint(Ms.copy(t.center).sub(ka))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}}const En=new L,Ga=new L,mo=new L,On=new L,Ha=new L,go=new L,Va=new L;class na{constructor(t=new L,e=new L(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,En)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=En.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(En.copy(this.origin).addScaledVector(this.direction,e),En.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){Ga.copy(t).add(e).multiplyScalar(.5),mo.copy(e).sub(t).normalize(),On.copy(this.origin).sub(Ga);const s=t.distanceTo(e)*.5,a=-this.direction.dot(mo),r=On.dot(this.direction),c=-On.dot(mo),l=On.lengthSq(),h=Math.abs(1-a*a);let d,u,p,g;if(h>0)if(d=a*c-r,u=a*r-c,g=s*h,d>=0)if(u>=-g)if(u<=g){const y=1/h;d*=y,u*=y,p=d*(d+a*u+2*r)+u*(a*d+u+2*c)+l}else u=s,d=Math.max(0,-(a*u+r)),p=-d*d+u*(u+2*c)+l;else u=-s,d=Math.max(0,-(a*u+r)),p=-d*d+u*(u+2*c)+l;else u<=-g?(d=Math.max(0,-(-a*s+r)),u=d>0?-s:Math.min(Math.max(-s,-c),s),p=-d*d+u*(u+2*c)+l):u<=g?(d=0,u=Math.min(Math.max(-s,-c),s),p=u*(u+2*c)+l):(d=Math.max(0,-(a*s+r)),u=d>0?s:Math.min(Math.max(-s,-c),s),p=-d*d+u*(u+2*c)+l);else u=a>0?-s:s,d=Math.max(0,-(a*u+r)),p=-d*d+u*(u+2*c)+l;return n&&n.copy(this.origin).addScaledVector(this.direction,d),i&&i.copy(Ga).addScaledVector(mo,u),p}intersectSphere(t,e){En.subVectors(t.center,this.origin);const n=En.dot(this.direction),i=En.dot(En)-n*n,s=t.radius*t.radius;if(i>s)return null;const a=Math.sqrt(s-i),r=n-a,c=n+a;return c<0?null:r<0?this.at(c,e):this.at(r,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,s,a,r,c;const l=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return l>=0?(n=(t.min.x-u.x)*l,i=(t.max.x-u.x)*l):(n=(t.max.x-u.x)*l,i=(t.min.x-u.x)*l),h>=0?(s=(t.min.y-u.y)*h,a=(t.max.y-u.y)*h):(s=(t.max.y-u.y)*h,a=(t.min.y-u.y)*h),n>a||s>i||((s>n||isNaN(n))&&(n=s),(a<i||isNaN(i))&&(i=a),d>=0?(r=(t.min.z-u.z)*d,c=(t.max.z-u.z)*d):(r=(t.max.z-u.z)*d,c=(t.min.z-u.z)*d),n>c||r>i)||((r>n||n!==n)&&(n=r),(c<i||i!==i)&&(i=c),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,En)!==null}intersectTriangle(t,e,n,i,s){Ha.subVectors(e,t),go.subVectors(n,t),Va.crossVectors(Ha,go);let a=this.direction.dot(Va),r;if(a>0){if(i)return null;r=1}else if(a<0)r=-1,a=-a;else return null;On.subVectors(this.origin,t);const c=r*this.direction.dot(go.crossVectors(On,go));if(c<0)return null;const l=r*this.direction.dot(Ha.cross(On));if(l<0||c+l>a)return null;const h=-r*On.dot(Va);return h<0?null:this.at(h/a,s)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class we{constructor(t,e,n,i,s,a,r,c,l,h,d,u,p,g,y,m){we.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,s,a,r,c,l,h,d,u,p,g,y,m)}set(t,e,n,i,s,a,r,c,l,h,d,u,p,g,y,m){const f=this.elements;return f[0]=t,f[4]=e,f[8]=n,f[12]=i,f[1]=s,f[5]=a,f[9]=r,f[13]=c,f[2]=l,f[6]=h,f[10]=d,f[14]=u,f[3]=p,f[7]=g,f[11]=y,f[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new we().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,i=1/zi.setFromMatrixColumn(t,0).length(),s=1/zi.setFromMatrixColumn(t,1).length(),a=1/zi.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*s,e[5]=n[5]*s,e[6]=n[6]*s,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,i=t.y,s=t.z,a=Math.cos(n),r=Math.sin(n),c=Math.cos(i),l=Math.sin(i),h=Math.cos(s),d=Math.sin(s);if(t.order==="XYZ"){const u=a*h,p=a*d,g=r*h,y=r*d;e[0]=c*h,e[4]=-c*d,e[8]=l,e[1]=p+g*l,e[5]=u-y*l,e[9]=-r*c,e[2]=y-u*l,e[6]=g+p*l,e[10]=a*c}else if(t.order==="YXZ"){const u=c*h,p=c*d,g=l*h,y=l*d;e[0]=u+y*r,e[4]=g*r-p,e[8]=a*l,e[1]=a*d,e[5]=a*h,e[9]=-r,e[2]=p*r-g,e[6]=y+u*r,e[10]=a*c}else if(t.order==="ZXY"){const u=c*h,p=c*d,g=l*h,y=l*d;e[0]=u-y*r,e[4]=-a*d,e[8]=g+p*r,e[1]=p+g*r,e[5]=a*h,e[9]=y-u*r,e[2]=-a*l,e[6]=r,e[10]=a*c}else if(t.order==="ZYX"){const u=a*h,p=a*d,g=r*h,y=r*d;e[0]=c*h,e[4]=g*l-p,e[8]=u*l+y,e[1]=c*d,e[5]=y*l+u,e[9]=p*l-g,e[2]=-l,e[6]=r*c,e[10]=a*c}else if(t.order==="YZX"){const u=a*c,p=a*l,g=r*c,y=r*l;e[0]=c*h,e[4]=y-u*d,e[8]=g*d+p,e[1]=d,e[5]=a*h,e[9]=-r*h,e[2]=-l*h,e[6]=p*d+g,e[10]=u-y*d}else if(t.order==="XZY"){const u=a*c,p=a*l,g=r*c,y=r*l;e[0]=c*h,e[4]=-d,e[8]=l*h,e[1]=u*d+y,e[5]=a*h,e[9]=p*d-g,e[2]=g*d-p,e[6]=r*h,e[10]=y*d+u}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(pu,t,fu)}lookAt(t,e,n){const i=this.elements;return Ye.subVectors(t,e),Ye.lengthSq()===0&&(Ye.z=1),Ye.normalize(),zn.crossVectors(n,Ye),zn.lengthSq()===0&&(Math.abs(n.z)===1?Ye.x+=1e-4:Ye.z+=1e-4,Ye.normalize(),zn.crossVectors(n,Ye)),zn.normalize(),wo.crossVectors(Ye,zn),i[0]=zn.x,i[4]=wo.x,i[8]=Ye.x,i[1]=zn.y,i[5]=wo.y,i[9]=Ye.y,i[2]=zn.z,i[6]=wo.z,i[10]=Ye.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,i=e.elements,s=this.elements,a=n[0],r=n[4],c=n[8],l=n[12],h=n[1],d=n[5],u=n[9],p=n[13],g=n[2],y=n[6],m=n[10],f=n[14],_=n[3],x=n[7],M=n[11],R=n[15],A=i[0],E=i[4],I=i[8],v=i[12],S=i[1],P=i[5],O=i[9],j=i[13],D=i[2],F=i[6],z=i[10],Z=i[14],Y=i[3],q=i[7],J=i[11],nt=i[15];return s[0]=a*A+r*S+c*D+l*Y,s[4]=a*E+r*P+c*F+l*q,s[8]=a*I+r*O+c*z+l*J,s[12]=a*v+r*j+c*Z+l*nt,s[1]=h*A+d*S+u*D+p*Y,s[5]=h*E+d*P+u*F+p*q,s[9]=h*I+d*O+u*z+p*J,s[13]=h*v+d*j+u*Z+p*nt,s[2]=g*A+y*S+m*D+f*Y,s[6]=g*E+y*P+m*F+f*q,s[10]=g*I+y*O+m*z+f*J,s[14]=g*v+y*j+m*Z+f*nt,s[3]=_*A+x*S+M*D+R*Y,s[7]=_*E+x*P+M*F+R*q,s[11]=_*I+x*O+M*z+R*J,s[15]=_*v+x*j+M*Z+R*nt,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],i=t[8],s=t[12],a=t[1],r=t[5],c=t[9],l=t[13],h=t[2],d=t[6],u=t[10],p=t[14],g=t[3],y=t[7],m=t[11],f=t[15];return g*(+s*c*d-i*l*d-s*r*u+n*l*u+i*r*p-n*c*p)+y*(+e*c*p-e*l*u+s*a*u-i*a*p+i*l*h-s*c*h)+m*(+e*l*d-e*r*p-s*a*d+n*a*p+s*r*h-n*l*h)+f*(-i*r*h-e*c*d+e*r*u+i*a*d-n*a*u+n*c*h)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],i=t[2],s=t[3],a=t[4],r=t[5],c=t[6],l=t[7],h=t[8],d=t[9],u=t[10],p=t[11],g=t[12],y=t[13],m=t[14],f=t[15],_=d*m*l-y*u*l+y*c*p-r*m*p-d*c*f+r*u*f,x=g*u*l-h*m*l-g*c*p+a*m*p+h*c*f-a*u*f,M=h*y*l-g*d*l+g*r*p-a*y*p-h*r*f+a*d*f,R=g*d*c-h*y*c-g*r*u+a*y*u+h*r*m-a*d*m,A=e*_+n*x+i*M+s*R;if(A===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const E=1/A;return t[0]=_*E,t[1]=(y*u*s-d*m*s-y*i*p+n*m*p+d*i*f-n*u*f)*E,t[2]=(r*m*s-y*c*s+y*i*l-n*m*l-r*i*f+n*c*f)*E,t[3]=(d*c*s-r*u*s-d*i*l+n*u*l+r*i*p-n*c*p)*E,t[4]=x*E,t[5]=(h*m*s-g*u*s+g*i*p-e*m*p-h*i*f+e*u*f)*E,t[6]=(g*c*s-a*m*s-g*i*l+e*m*l+a*i*f-e*c*f)*E,t[7]=(a*u*s-h*c*s+h*i*l-e*u*l-a*i*p+e*c*p)*E,t[8]=M*E,t[9]=(g*d*s-h*y*s-g*n*p+e*y*p+h*n*f-e*d*f)*E,t[10]=(a*y*s-g*r*s+g*n*l-e*y*l-a*n*f+e*r*f)*E,t[11]=(h*r*s-a*d*s-h*n*l+e*d*l+a*n*p-e*r*p)*E,t[12]=R*E,t[13]=(h*y*i-g*d*i+g*n*u-e*y*u-h*n*m+e*d*m)*E,t[14]=(g*r*i-a*y*i-g*n*c+e*y*c+a*n*m-e*r*m)*E,t[15]=(a*d*i-h*r*i+h*n*c-e*d*c-a*n*u+e*r*u)*E,this}scale(t){const e=this.elements,n=t.x,i=t.y,s=t.z;return e[0]*=n,e[4]*=i,e[8]*=s,e[1]*=n,e[5]*=i,e[9]*=s,e[2]*=n,e[6]*=i,e[10]*=s,e[3]*=n,e[7]*=i,e[11]*=s,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),i=Math.sin(e),s=1-n,a=t.x,r=t.y,c=t.z,l=s*a,h=s*r;return this.set(l*a+n,l*r-i*c,l*c+i*r,0,l*r+i*c,h*r+n,h*c-i*a,0,l*c-i*r,h*c+i*a,s*c*c+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,s,a){return this.set(1,n,s,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){const i=this.elements,s=e._x,a=e._y,r=e._z,c=e._w,l=s+s,h=a+a,d=r+r,u=s*l,p=s*h,g=s*d,y=a*h,m=a*d,f=r*d,_=c*l,x=c*h,M=c*d,R=n.x,A=n.y,E=n.z;return i[0]=(1-(y+f))*R,i[1]=(p+M)*R,i[2]=(g-x)*R,i[3]=0,i[4]=(p-M)*A,i[5]=(1-(u+f))*A,i[6]=(m+_)*A,i[7]=0,i[8]=(g+x)*E,i[9]=(m-_)*E,i[10]=(1-(u+y))*E,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){const i=this.elements;let s=zi.set(i[0],i[1],i[2]).length();const a=zi.set(i[4],i[5],i[6]).length(),r=zi.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),t.x=i[12],t.y=i[13],t.z=i[14],rn.copy(this);const l=1/s,h=1/a,d=1/r;return rn.elements[0]*=l,rn.elements[1]*=l,rn.elements[2]*=l,rn.elements[4]*=h,rn.elements[5]*=h,rn.elements[6]*=h,rn.elements[8]*=d,rn.elements[9]*=d,rn.elements[10]*=d,e.setFromRotationMatrix(rn),n.x=s,n.y=a,n.z=r,this}makePerspective(t,e,n,i,s,a,r=In){const c=this.elements,l=2*s/(e-t),h=2*s/(n-i),d=(e+t)/(e-t),u=(n+i)/(n-i);let p,g;if(r===In)p=-(a+s)/(a-s),g=-2*a*s/(a-s);else if(r===$o)p=-a/(a-s),g=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+r);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=h,c[9]=u,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=g,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,i,s,a,r=In){const c=this.elements,l=1/(e-t),h=1/(n-i),d=1/(a-s),u=(e+t)*l,p=(n+i)*h;let g,y;if(r===In)g=(a+s)*d,y=-2*d;else if(r===$o)g=s*d,y=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+r);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-u,c[1]=0,c[5]=2*h,c[9]=0,c[13]=-p,c[2]=0,c[6]=0,c[10]=y,c[14]=-g,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const zi=new L,rn=new we,pu=new L(0,0,0),fu=new L(1,1,1),zn=new L,wo=new L,Ye=new L,Kc=new we,Jc=new ks;class ia{constructor(t=0,e=0,n=0,i=ia.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const i=t.elements,s=i[0],a=i[4],r=i[8],c=i[1],l=i[5],h=i[9],d=i[2],u=i[6],p=i[10];switch(e){case"XYZ":this._y=Math.asin(Ne(r,-1,1)),Math.abs(r)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Ne(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(r,p),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,s),this._z=0);break;case"ZXY":this._x=Math.asin(Ne(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,p),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-Ne(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,p),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Ne(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-h,l),this._y=Math.atan2(-d,s)):(this._x=0,this._y=Math.atan2(r,p));break;case"XZY":this._z=Math.asin(-Ne(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(r,s)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Kc.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Kc,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Jc.setFromEuler(this),this.setFromQuaternion(Jc,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}ia.DEFAULT_ORDER="XYZ";class Lr{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let mu=0;const Qc=new L,ki=new ks,Tn=new we,yo=new L,Ss=new L,gu=new L,wu=new ks,tl=new L(1,0,0),el=new L(0,1,0),nl=new L(0,0,1),yu={type:"added"},xu={type:"removed"};class _e extends ds{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:mu++}),this.uuid=Dn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=_e.DEFAULT_UP.clone();const t=new L,e=new ia,n=new ks,i=new L(1,1,1);function s(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new we},normalMatrix:{value:new Qt}}),this.matrix=new we,this.matrixWorld=new we,this.matrixAutoUpdate=_e.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=_e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Lr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return ki.setFromAxisAngle(t,e),this.quaternion.multiply(ki),this}rotateOnWorldAxis(t,e){return ki.setFromAxisAngle(t,e),this.quaternion.premultiply(ki),this}rotateX(t){return this.rotateOnAxis(tl,t)}rotateY(t){return this.rotateOnAxis(el,t)}rotateZ(t){return this.rotateOnAxis(nl,t)}translateOnAxis(t,e){return Qc.copy(t).applyQuaternion(this.quaternion),this.position.add(Qc.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(tl,t)}translateY(t){return this.translateOnAxis(el,t)}translateZ(t){return this.translateOnAxis(nl,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Tn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?yo.copy(t):yo.set(t,e,n);const i=this.parent;this.updateWorldMatrix(!0,!1),Ss.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Tn.lookAt(Ss,yo,this.up):Tn.lookAt(yo,Ss,this.up),this.quaternion.setFromRotationMatrix(Tn),i&&(Tn.extractRotation(i.matrixWorld),ki.setFromRotationMatrix(Tn),this.quaternion.premultiply(ki.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.parent!==null&&t.parent.remove(t),t.parent=this,this.children.push(t),t.dispatchEvent(yu)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(xu)),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Tn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Tn.multiply(t.parent.matrixWorld)),t.applyMatrix4(Tn),this.add(t),t.updateWorldMatrix(!1,!0),this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const i=this.children;for(let s=0,a=i.length;s<a;s++)i[s].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ss,t,gu),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ss,wu,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,i=e.length;n<i;n++){const s=e[n];(s.matrixWorldAutoUpdate===!0||t===!0)&&s.updateMatrixWorld(t)}}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),e===!0){const i=this.children;for(let s=0,a=i.length;s<a;s++){const r=i[s];r.matrixWorldAutoUpdate===!0&&r.updateWorldMatrix(!1,!0)}}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(r=>({boxInitialized:r.boxInitialized,boxMin:r.box.min.toArray(),boxMax:r.box.max.toArray(),sphereInitialized:r.sphereInitialized,sphereRadius:r.sphere.radius,sphereCenter:r.sphere.center.toArray()})),i.maxGeometryCount=this._maxGeometryCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(t),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function s(r,c){return r[c.uuid]===void 0&&(r[c.uuid]=c.toJSON(t)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(t.geometries,this.geometry);const r=this.geometry.parameters;if(r!==void 0&&r.shapes!==void 0){const c=r.shapes;if(Array.isArray(c))for(let l=0,h=c.length;l<h;l++){const d=c[l];s(t.shapes,d)}else s(t.shapes,c)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const r=[];for(let c=0,l=this.material.length;c<l;c++)r.push(s(t.materials,this.material[c]));i.material=r}else i.material=s(t.materials,this.material);if(this.children.length>0){i.children=[];for(let r=0;r<this.children.length;r++)i.children.push(this.children[r].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let r=0;r<this.animations.length;r++){const c=this.animations[r];i.animations.push(s(t.animations,c))}}if(e){const r=a(t.geometries),c=a(t.materials),l=a(t.textures),h=a(t.images),d=a(t.shapes),u=a(t.skeletons),p=a(t.animations),g=a(t.nodes);r.length>0&&(n.geometries=r),c.length>0&&(n.materials=c),l.length>0&&(n.textures=l),h.length>0&&(n.images=h),d.length>0&&(n.shapes=d),u.length>0&&(n.skeletons=u),p.length>0&&(n.animations=p),g.length>0&&(n.nodes=g)}return n.object=i,n;function a(r){const c=[];for(const l in r){const h=r[l];delete h.metadata,c.push(h)}return c}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const i=t.children[n];this.add(i.clone())}return this}}_e.DEFAULT_UP=new L(0,1,0);_e.DEFAULT_MATRIX_AUTO_UPDATE=!0;_e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const cn=new L,An=new L,Wa=new L,Cn=new L,Gi=new L,Hi=new L,il=new L,Xa=new L,qa=new L,Ya=new L;let xo=!1;class en{constructor(t=new L,e=new L,n=new L){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),cn.subVectors(t,e),i.cross(cn);const s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(t,e,n,i,s){cn.subVectors(i,e),An.subVectors(n,e),Wa.subVectors(t,e);const a=cn.dot(cn),r=cn.dot(An),c=cn.dot(Wa),l=An.dot(An),h=An.dot(Wa),d=a*l-r*r;if(d===0)return s.set(0,0,0),null;const u=1/d,p=(l*c-r*h)*u,g=(a*h-r*c)*u;return s.set(1-p-g,g,p)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,Cn)===null?!1:Cn.x>=0&&Cn.y>=0&&Cn.x+Cn.y<=1}static getUV(t,e,n,i,s,a,r,c){return xo===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),xo=!0),this.getInterpolation(t,e,n,i,s,a,r,c)}static getInterpolation(t,e,n,i,s,a,r,c){return this.getBarycoord(t,e,n,i,Cn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,Cn.x),c.addScaledVector(a,Cn.y),c.addScaledVector(r,Cn.z),c)}static isFrontFacing(t,e,n,i){return cn.subVectors(n,e),An.subVectors(t,e),cn.cross(An).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return cn.subVectors(this.c,this.b),An.subVectors(this.a,this.b),cn.cross(An).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return en.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return en.getBarycoord(t,this.a,this.b,this.c,e)}getUV(t,e,n,i,s){return xo===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),xo=!0),en.getInterpolation(t,this.a,this.b,this.c,e,n,i,s)}getInterpolation(t,e,n,i,s){return en.getInterpolation(t,this.a,this.b,this.c,e,n,i,s)}containsPoint(t){return en.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return en.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,i=this.b,s=this.c;let a,r;Gi.subVectors(i,n),Hi.subVectors(s,n),Xa.subVectors(t,n);const c=Gi.dot(Xa),l=Hi.dot(Xa);if(c<=0&&l<=0)return e.copy(n);qa.subVectors(t,i);const h=Gi.dot(qa),d=Hi.dot(qa);if(h>=0&&d<=h)return e.copy(i);const u=c*d-h*l;if(u<=0&&c>=0&&h<=0)return a=c/(c-h),e.copy(n).addScaledVector(Gi,a);Ya.subVectors(t,s);const p=Gi.dot(Ya),g=Hi.dot(Ya);if(g>=0&&p<=g)return e.copy(s);const y=p*l-c*g;if(y<=0&&l>=0&&g<=0)return r=l/(l-g),e.copy(n).addScaledVector(Hi,r);const m=h*g-p*d;if(m<=0&&d-h>=0&&p-g>=0)return il.subVectors(s,i),r=(d-h)/(d-h+(p-g)),e.copy(i).addScaledVector(il,r);const f=1/(m+y+u);return a=y*f,r=u*f,e.copy(n).addScaledVector(Gi,a).addScaledVector(Hi,r)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const ph={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},kn={h:0,s:0,l:0},vo={h:0,s:0,l:0};function $a(o,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?o+(t-o)*6*e:e<1/2?t:e<2/3?o+(t-o)*6*(2/3-e):o}class Vt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Pe){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,re.toWorkingColorSpace(this,e),this}setRGB(t,e,n,i=re.workingColorSpace){return this.r=t,this.g=e,this.b=n,re.toWorkingColorSpace(this,i),this}setHSL(t,e,n,i=re.workingColorSpace){if(t=ou(t,1),e=Ne(e,0,1),n=Ne(n,0,1),e===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+e):n+e-n*e,a=2*n-s;this.r=$a(a,s,t+1/3),this.g=$a(a,s,t),this.b=$a(a,s,t-1/3)}return re.toWorkingColorSpace(this,i),this}setStyle(t,e=Pe){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let s;const a=i[1],r=i[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,e);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,e);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(r))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){const s=i[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(s,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Pe){const n=ph[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=as(t.r),this.g=as(t.g),this.b=as(t.b),this}copyLinearToSRGB(t){return this.r=Ba(t.r),this.g=Ba(t.g),this.b=Ba(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Pe){return re.fromWorkingColorSpace(Ue.copy(this),t),Math.round(Ne(Ue.r*255,0,255))*65536+Math.round(Ne(Ue.g*255,0,255))*256+Math.round(Ne(Ue.b*255,0,255))}getHexString(t=Pe){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=re.workingColorSpace){re.fromWorkingColorSpace(Ue.copy(this),e);const n=Ue.r,i=Ue.g,s=Ue.b,a=Math.max(n,i,s),r=Math.min(n,i,s);let c,l;const h=(r+a)/2;if(r===a)c=0,l=0;else{const d=a-r;switch(l=h<=.5?d/(a+r):d/(2-a-r),a){case n:c=(i-s)/d+(i<s?6:0);break;case i:c=(s-n)/d+2;break;case s:c=(n-i)/d+4;break}c/=6}return t.h=c,t.s=l,t.l=h,t}getRGB(t,e=re.workingColorSpace){return re.fromWorkingColorSpace(Ue.copy(this),e),t.r=Ue.r,t.g=Ue.g,t.b=Ue.b,t}getStyle(t=Pe){re.fromWorkingColorSpace(Ue.copy(this),t);const e=Ue.r,n=Ue.g,i=Ue.b;return t!==Pe?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(kn),this.setHSL(kn.h+t,kn.s+e,kn.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(kn),t.getHSL(vo);const n=Ua(kn.h,vo.h,e),i=Ua(kn.s,vo.s,e),s=Ua(kn.l,vo.l,e);return this.setHSL(n,i,s),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,i=this.b,s=t.elements;return this.r=s[0]*e+s[3]*n+s[6]*i,this.g=s[1]*e+s[4]*n+s[7]*i,this.b=s[2]*e+s[5]*n+s[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ue=new Vt;Vt.NAMES=ph;let vu=0;class $n extends ds{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:vu++}),this.uuid=Dn(),this.name="",this.type="Material",this.blending=os,this.side=Yn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=dr,this.blendDst=ur,this.blendEquation=hi,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Vt(0,0,0),this.blendAlpha=0,this.depthFunc=Wo,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Wc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ui,this.stencilZFail=Ui,this.stencilZPass=Ui,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==os&&(n.blending=this.blending),this.side!==Yn&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==dr&&(n.blendSrc=this.blendSrc),this.blendDst!==ur&&(n.blendDst=this.blendDst),this.blendEquation!==hi&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==Wo&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Wc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ui&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ui&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ui&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(s){const a=[];for(const r in s){const c=s[r];delete c.metadata,a.push(c)}return a}if(e){const s=i(t.textures),a=i(t.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const i=e.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=e[s].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}class _t extends $n{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Vt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Ar,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const Ee=new L,_o=new dt;class sn{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=wr,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Hn,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)_o.fromBufferAttribute(this,e),_o.applyMatrix3(t),this.setXY(e,_o.x,_o.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix3(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyMatrix4(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.applyNormalMatrix(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ee.fromBufferAttribute(this,e),Ee.transformDirection(t),this.setXYZ(e,Ee.x,Ee.y,Ee.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Ln(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=he(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Ln(e,this.array)),e}setX(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Ln(e,this.array)),e}setY(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Ln(e,this.array)),e}setZ(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Ln(e,this.array)),e}setW(t,e){return this.normalized&&(e=he(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=he(e,this.array),n=he(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=he(e,this.array),n=he(n,this.array),i=he(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,s){return t*=this.itemSize,this.normalized&&(e=he(e,this.array),n=he(n,this.array),i=he(i,this.array),s=he(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=s,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==wr&&(t.usage=this.usage),t}}class fh extends sn{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class mh extends sn{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class te extends sn{constructor(t,e,n){super(new Float32Array(t),e,n)}}let _u=0;const Qe=new we,Za=new _e,Vi=new L,$e=new Gs,bs=new Gs,Le=new L;class Te extends ds{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:_u++}),this.uuid=Dn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(lh(t)?mh:fh)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new Qt().getNormalMatrix(t);n.applyNormalMatrix(s),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Qe.makeRotationFromQuaternion(t),this.applyMatrix4(Qe),this}rotateX(t){return Qe.makeRotationX(t),this.applyMatrix4(Qe),this}rotateY(t){return Qe.makeRotationY(t),this.applyMatrix4(Qe),this}rotateZ(t){return Qe.makeRotationZ(t),this.applyMatrix4(Qe),this}translate(t,e,n){return Qe.makeTranslation(t,e,n),this.applyMatrix4(Qe),this}scale(t,e,n){return Qe.makeScale(t,e,n),this.applyMatrix4(Qe),this}lookAt(t){return Za.lookAt(t),Za.updateMatrix(),this.applyMatrix4(Za.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Vi).negate(),this.translate(Vi.x,Vi.y,Vi.z),this}setFromPoints(t){const e=[];for(let n=0,i=t.length;n<i;n++){const s=t[n];e.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new te(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Gs);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){const s=e[n];$e.setFromBufferAttribute(s),this.morphTargetsRelative?(Le.addVectors(this.boundingBox.min,$e.min),this.boundingBox.expandByPoint(Le),Le.addVectors(this.boundingBox.max,$e.max),this.boundingBox.expandByPoint(Le)):(this.boundingBox.expandByPoint($e.min),this.boundingBox.expandByPoint($e.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Hs);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new L,1/0);return}if(t){const n=this.boundingSphere.center;if($e.setFromBufferAttribute(t),e)for(let s=0,a=e.length;s<a;s++){const r=e[s];bs.setFromBufferAttribute(r),this.morphTargetsRelative?(Le.addVectors($e.min,bs.min),$e.expandByPoint(Le),Le.addVectors($e.max,bs.max),$e.expandByPoint(Le)):($e.expandByPoint(bs.min),$e.expandByPoint(bs.max))}$e.getCenter(n);let i=0;for(let s=0,a=t.count;s<a;s++)Le.fromBufferAttribute(t,s),i=Math.max(i,n.distanceToSquared(Le));if(e)for(let s=0,a=e.length;s<a;s++){const r=e[s],c=this.morphTargetsRelative;for(let l=0,h=r.count;l<h;l++)Le.fromBufferAttribute(r,l),c&&(Vi.fromBufferAttribute(t,l),Le.add(Vi)),i=Math.max(i,n.distanceToSquared(Le))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.array,i=e.position.array,s=e.normal.array,a=e.uv.array,r=i.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new sn(new Float32Array(4*r),4));const c=this.getAttribute("tangent").array,l=[],h=[];for(let S=0;S<r;S++)l[S]=new L,h[S]=new L;const d=new L,u=new L,p=new L,g=new dt,y=new dt,m=new dt,f=new L,_=new L;function x(S,P,O){d.fromArray(i,S*3),u.fromArray(i,P*3),p.fromArray(i,O*3),g.fromArray(a,S*2),y.fromArray(a,P*2),m.fromArray(a,O*2),u.sub(d),p.sub(d),y.sub(g),m.sub(g);const j=1/(y.x*m.y-m.x*y.y);isFinite(j)&&(f.copy(u).multiplyScalar(m.y).addScaledVector(p,-y.y).multiplyScalar(j),_.copy(p).multiplyScalar(y.x).addScaledVector(u,-m.x).multiplyScalar(j),l[S].add(f),l[P].add(f),l[O].add(f),h[S].add(_),h[P].add(_),h[O].add(_))}let M=this.groups;M.length===0&&(M=[{start:0,count:n.length}]);for(let S=0,P=M.length;S<P;++S){const O=M[S],j=O.start,D=O.count;for(let F=j,z=j+D;F<z;F+=3)x(n[F+0],n[F+1],n[F+2])}const R=new L,A=new L,E=new L,I=new L;function v(S){E.fromArray(s,S*3),I.copy(E);const P=l[S];R.copy(P),R.sub(E.multiplyScalar(E.dot(P))).normalize(),A.crossVectors(I,P);const j=A.dot(h[S])<0?-1:1;c[S*4]=R.x,c[S*4+1]=R.y,c[S*4+2]=R.z,c[S*4+3]=j}for(let S=0,P=M.length;S<P;++S){const O=M[S],j=O.start,D=O.count;for(let F=j,z=j+D;F<z;F+=3)v(n[F+0]),v(n[F+1]),v(n[F+2])}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new sn(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let u=0,p=n.count;u<p;u++)n.setXYZ(u,0,0,0);const i=new L,s=new L,a=new L,r=new L,c=new L,l=new L,h=new L,d=new L;if(t)for(let u=0,p=t.count;u<p;u+=3){const g=t.getX(u+0),y=t.getX(u+1),m=t.getX(u+2);i.fromBufferAttribute(e,g),s.fromBufferAttribute(e,y),a.fromBufferAttribute(e,m),h.subVectors(a,s),d.subVectors(i,s),h.cross(d),r.fromBufferAttribute(n,g),c.fromBufferAttribute(n,y),l.fromBufferAttribute(n,m),r.add(h),c.add(h),l.add(h),n.setXYZ(g,r.x,r.y,r.z),n.setXYZ(y,c.x,c.y,c.z),n.setXYZ(m,l.x,l.y,l.z)}else for(let u=0,p=e.count;u<p;u+=3)i.fromBufferAttribute(e,u+0),s.fromBufferAttribute(e,u+1),a.fromBufferAttribute(e,u+2),h.subVectors(a,s),d.subVectors(i,s),h.cross(d),n.setXYZ(u+0,h.x,h.y,h.z),n.setXYZ(u+1,h.x,h.y,h.z),n.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Le.fromBufferAttribute(t,e),Le.normalize(),t.setXYZ(e,Le.x,Le.y,Le.z)}toNonIndexed(){function t(r,c){const l=r.array,h=r.itemSize,d=r.normalized,u=new l.constructor(c.length*h);let p=0,g=0;for(let y=0,m=c.length;y<m;y++){r.isInterleavedBufferAttribute?p=c[y]*r.data.stride+r.offset:p=c[y]*h;for(let f=0;f<h;f++)u[g++]=l[p++]}return new sn(u,h,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new Te,n=this.index.array,i=this.attributes;for(const r in i){const c=i[r],l=t(c,n);e.setAttribute(r,l)}const s=this.morphAttributes;for(const r in s){const c=[],l=s[r];for(let h=0,d=l.length;h<d;h++){const u=l[h],p=t(u,n);c.push(p)}e.morphAttributes[r]=c}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let r=0,c=a.length;r<c;r++){const l=a[r];e.addGroup(l.start,l.count,l.materialIndex)}return e}toJSON(){const t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(t[l]=c[l]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const c in n){const l=n[c];t.data.attributes[c]=l.toJSON(t.data)}const i={};let s=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],h=[];for(let d=0,u=l.length;d<u;d++){const p=l[d];h.push(p.toJSON(t.data))}h.length>0&&(i[c]=h,s=!0)}s&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const r=this.boundingSphere;return r!==null&&(t.data.boundingSphere={center:r.center.toArray(),radius:r.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone(e));const i=t.attributes;for(const l in i){const h=i[l];this.setAttribute(l,h.clone(e))}const s=t.morphAttributes;for(const l in s){const h=[],d=s[l];for(let u=0,p=d.length;u<p;u++)h.push(d[u].clone(e));this.morphAttributes[l]=h}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let l=0,h=a.length;l<h;l++){const d=a[l];this.addGroup(d.start,d.count,d.materialIndex)}const r=t.boundingBox;r!==null&&(this.boundingBox=r.clone());const c=t.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const sl=new we,ai=new na,Mo=new Hs,ol=new L,Wi=new L,Xi=new L,qi=new L,ja=new L,So=new L,bo=new dt,Eo=new dt,To=new dt,al=new L,rl=new L,cl=new L,Ao=new L,Co=new L;class w extends _e{constructor(t=new Te,e=new _t){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}getVertexPosition(t,e){const n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);const r=this.morphTargetInfluences;if(s&&r){So.set(0,0,0);for(let c=0,l=s.length;c<l;c++){const h=r[c],d=s[c];h!==0&&(ja.fromBufferAttribute(d,t),a?So.addScaledVector(ja,h):So.addScaledVector(ja.sub(e),h))}e.add(So)}return e}raycast(t,e){const n=this.geometry,i=this.material,s=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Mo.copy(n.boundingSphere),Mo.applyMatrix4(s),ai.copy(t.ray).recast(t.near),!(Mo.containsPoint(ai.origin)===!1&&(ai.intersectSphere(Mo,ol)===null||ai.origin.distanceToSquared(ol)>(t.far-t.near)**2))&&(sl.copy(s).invert(),ai.copy(t.ray).applyMatrix4(sl),!(n.boundingBox!==null&&ai.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,ai)))}_computeIntersections(t,e,n){let i;const s=this.geometry,a=this.material,r=s.index,c=s.attributes.position,l=s.attributes.uv,h=s.attributes.uv1,d=s.attributes.normal,u=s.groups,p=s.drawRange;if(r!==null)if(Array.isArray(a))for(let g=0,y=u.length;g<y;g++){const m=u[g],f=a[m.materialIndex],_=Math.max(m.start,p.start),x=Math.min(r.count,Math.min(m.start+m.count,p.start+p.count));for(let M=_,R=x;M<R;M+=3){const A=r.getX(M),E=r.getX(M+1),I=r.getX(M+2);i=Ro(this,f,t,n,l,h,d,A,E,I),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,p.start),y=Math.min(r.count,p.start+p.count);for(let m=g,f=y;m<f;m+=3){const _=r.getX(m),x=r.getX(m+1),M=r.getX(m+2);i=Ro(this,a,t,n,l,h,d,_,x,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}else if(c!==void 0)if(Array.isArray(a))for(let g=0,y=u.length;g<y;g++){const m=u[g],f=a[m.materialIndex],_=Math.max(m.start,p.start),x=Math.min(c.count,Math.min(m.start+m.count,p.start+p.count));for(let M=_,R=x;M<R;M+=3){const A=M,E=M+1,I=M+2;i=Ro(this,f,t,n,l,h,d,A,E,I),i&&(i.faceIndex=Math.floor(M/3),i.face.materialIndex=m.materialIndex,e.push(i))}}else{const g=Math.max(0,p.start),y=Math.min(c.count,p.start+p.count);for(let m=g,f=y;m<f;m+=3){const _=m,x=m+1,M=m+2;i=Ro(this,a,t,n,l,h,d,_,x,M),i&&(i.faceIndex=Math.floor(m/3),e.push(i))}}}}function Mu(o,t,e,n,i,s,a,r){let c;if(t.side===He?c=n.intersectTriangle(a,s,i,!0,r):c=n.intersectTriangle(i,s,a,t.side===Yn,r),c===null)return null;Co.copy(r),Co.applyMatrix4(o.matrixWorld);const l=e.ray.origin.distanceTo(Co);return l<e.near||l>e.far?null:{distance:l,point:Co.clone(),object:o}}function Ro(o,t,e,n,i,s,a,r,c,l){o.getVertexPosition(r,Wi),o.getVertexPosition(c,Xi),o.getVertexPosition(l,qi);const h=Mu(o,t,e,n,Wi,Xi,qi,Ao);if(h){i&&(bo.fromBufferAttribute(i,r),Eo.fromBufferAttribute(i,c),To.fromBufferAttribute(i,l),h.uv=en.getInterpolation(Ao,Wi,Xi,qi,bo,Eo,To,new dt)),s&&(bo.fromBufferAttribute(s,r),Eo.fromBufferAttribute(s,c),To.fromBufferAttribute(s,l),h.uv1=en.getInterpolation(Ao,Wi,Xi,qi,bo,Eo,To,new dt),h.uv2=h.uv1),a&&(al.fromBufferAttribute(a,r),rl.fromBufferAttribute(a,c),cl.fromBufferAttribute(a,l),h.normal=en.getInterpolation(Ao,Wi,Xi,qi,al,rl,cl,new L),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a:r,b:c,c:l,normal:new L,materialIndex:0};en.getNormal(Wi,Xi,qi,d.normal),h.face=d}return h}class U extends Te{constructor(t=1,e=1,n=1,i=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:s,depthSegments:a};const r=this;i=Math.floor(i),s=Math.floor(s),a=Math.floor(a);const c=[],l=[],h=[],d=[];let u=0,p=0;g("z","y","x",-1,-1,n,e,t,a,s,0),g("z","y","x",1,-1,n,e,-t,a,s,1),g("x","z","y",1,1,t,n,e,i,a,2),g("x","z","y",1,-1,t,n,-e,i,a,3),g("x","y","z",1,-1,t,e,n,i,s,4),g("x","y","z",-1,-1,t,e,-n,i,s,5),this.setIndex(c),this.setAttribute("position",new te(l,3)),this.setAttribute("normal",new te(h,3)),this.setAttribute("uv",new te(d,2));function g(y,m,f,_,x,M,R,A,E,I,v){const S=M/E,P=R/I,O=M/2,j=R/2,D=A/2,F=E+1,z=I+1;let Z=0,Y=0;const q=new L;for(let J=0;J<z;J++){const nt=J*P-j;for(let ct=0;ct<F;ct++){const X=ct*S-O;q[y]=X*_,q[m]=nt*x,q[f]=D,l.push(q.x,q.y,q.z),q[y]=0,q[m]=0,q[f]=A>0?1:-1,h.push(q.x,q.y,q.z),d.push(ct/E),d.push(1-J/I),Z+=1}}for(let J=0;J<I;J++)for(let nt=0;nt<E;nt++){const ct=u+nt+F*J,X=u+nt+F*(J+1),et=u+(nt+1)+F*(J+1),pt=u+(nt+1)+F*J;c.push(ct,X,pt),c.push(X,et,pt),Y+=6}r.addGroup(p,Y,v),p+=Y,u+=Z}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new U(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function hs(o){const t={};for(const e in o){t[e]={};for(const n in o[e]){const i=o[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function Oe(o){const t={};for(let e=0;e<o.length;e++){const n=hs(o[e]);for(const i in n)t[i]=n[i]}return t}function Su(o){const t=[];for(let e=0;e<o.length;e++)t.push(o[e].clone());return t}function gh(o){return o.getRenderTarget()===null?o.outputColorSpace:re.workingColorSpace}const bu={clone:hs,merge:Oe};var Eu=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Tu=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class gi extends $n{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Eu,this.fragmentShader=Tu,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=hs(t.uniforms),this.uniformsGroups=Su(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const i in this.uniforms){const a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class wh extends _e{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new we,this.projectionMatrix=new we,this.projectionMatrixInverse=new we,this.coordinateSystem=In}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class Ge extends wh{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=Zo*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(Da*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Zo*2*Math.atan(Math.tan(Da*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(t,e,n,i,s,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(Da*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,s=-.5*i;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;s+=a.offsetX*i/c,e-=a.offsetY*n/l,i*=a.width/c,n*=a.height/l}const r=this.filmOffset;r!==0&&(s+=t*r/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const Yi=-90,$i=1;class Au extends _e{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new Ge(Yi,$i,t,e);i.layers=this.layers,this.add(i);const s=new Ge(Yi,$i,t,e);s.layers=this.layers,this.add(s);const a=new Ge(Yi,$i,t,e);a.layers=this.layers,this.add(a);const r=new Ge(Yi,$i,t,e);r.layers=this.layers,this.add(r);const c=new Ge(Yi,$i,t,e);c.layers=this.layers,this.add(c);const l=new Ge(Yi,$i,t,e);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,i,s,a,r,c]=e;for(const l of e)this.remove(l);if(t===In)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),r.up.set(0,1,0),r.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(t===$o)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),r.up.set(0,-1,0),r.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const l of e)this.add(l),l.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[s,a,r,c,l,h]=this.children,d=t.getRenderTarget(),u=t.getActiveCubeFace(),p=t.getActiveMipmapLevel(),g=t.xr.enabled;t.xr.enabled=!1;const y=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,s),t.setRenderTarget(n,1,i),t.render(e,a),t.setRenderTarget(n,2,i),t.render(e,r),t.setRenderTarget(n,3,i),t.render(e,c),t.setRenderTarget(n,4,i),t.render(e,l),n.texture.generateMipmaps=y,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(d,u,p),t.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class yh extends Ve{constructor(t,e,n,i,s,a,r,c,l,h){t=t!==void 0?t:[],e=e!==void 0?e:rs,super(t,e,n,i,s,a,r,c,l,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class Cu extends mi{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];e.encoding!==void 0&&(Rs("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),e.colorSpace=e.encoding===fi?Pe:nn),this.texture=new yh(i,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:tn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new U(5,5,5),s=new gi({name:"CubemapFromEquirect",uniforms:hs(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:He,blending:Wn});s.uniforms.tEquirect.value=e;const a=new w(i,s),r=e.minFilter;return e.minFilter===Us&&(e.minFilter=tn),new Au(1,10,this).update(t,a),e.minFilter=r,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,i){const s=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(s)}}const Ka=new L,Ru=new L,Lu=new Qt;class ci{constructor(t=new L(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const i=Ka.subVectors(n,e).cross(Ru.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Ka),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const s=-(t.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:e.copy(t.start).addScaledVector(n,s)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||Lu.getNormalMatrix(t),i=this.coplanarPoint(Ka).applyMatrix4(t),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ri=new Hs,Lo=new L;class Pr{constructor(t=new ci,e=new ci,n=new ci,i=new ci,s=new ci,a=new ci){this.planes=[t,e,n,i,s,a]}set(t,e,n,i,s,a){const r=this.planes;return r[0].copy(t),r[1].copy(e),r[2].copy(n),r[3].copy(i),r[4].copy(s),r[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=In){const n=this.planes,i=t.elements,s=i[0],a=i[1],r=i[2],c=i[3],l=i[4],h=i[5],d=i[6],u=i[7],p=i[8],g=i[9],y=i[10],m=i[11],f=i[12],_=i[13],x=i[14],M=i[15];if(n[0].setComponents(c-s,u-l,m-p,M-f).normalize(),n[1].setComponents(c+s,u+l,m+p,M+f).normalize(),n[2].setComponents(c+a,u+h,m+g,M+_).normalize(),n[3].setComponents(c-a,u-h,m-g,M-_).normalize(),n[4].setComponents(c-r,u-d,m-y,M-x).normalize(),e===In)n[5].setComponents(c+r,u+d,m+y,M+x).normalize();else if(e===$o)n[5].setComponents(r,d,y,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ri.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ri.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ri)}intersectsSprite(t){return ri.center.set(0,0,0),ri.radius=.7071067811865476,ri.applyMatrix4(t.matrixWorld),this.intersectsSphere(ri)}intersectsSphere(t){const e=this.planes,n=t.center,i=-t.radius;for(let s=0;s<6;s++)if(e[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const i=e[n];if(Lo.x=i.normal.x>0?t.max.x:t.min.x,Lo.y=i.normal.y>0?t.max.y:t.min.y,Lo.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(Lo)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function xh(){let o=null,t=!1,e=null,n=null;function i(s,a){e(s,a),n=o.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=o.requestAnimationFrame(i),t=!0)},stop:function(){o.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(s){e=s},setContext:function(s){o=s}}}function Pu(o,t){const e=t.isWebGL2,n=new WeakMap;function i(l,h){const d=l.array,u=l.usage,p=d.byteLength,g=o.createBuffer();o.bindBuffer(h,g),o.bufferData(h,d,u),l.onUploadCallback();let y;if(d instanceof Float32Array)y=o.FLOAT;else if(d instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(e)y=o.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else y=o.UNSIGNED_SHORT;else if(d instanceof Int16Array)y=o.SHORT;else if(d instanceof Uint32Array)y=o.UNSIGNED_INT;else if(d instanceof Int32Array)y=o.INT;else if(d instanceof Int8Array)y=o.BYTE;else if(d instanceof Uint8Array)y=o.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)y=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:g,type:y,bytesPerElement:d.BYTES_PER_ELEMENT,version:l.version,size:p}}function s(l,h,d){const u=h.array,p=h._updateRange,g=h.updateRanges;if(o.bindBuffer(d,l),p.count===-1&&g.length===0&&o.bufferSubData(d,0,u),g.length!==0){for(let y=0,m=g.length;y<m;y++){const f=g[y];e?o.bufferSubData(d,f.start*u.BYTES_PER_ELEMENT,u,f.start,f.count):o.bufferSubData(d,f.start*u.BYTES_PER_ELEMENT,u.subarray(f.start,f.start+f.count))}h.clearUpdateRanges()}p.count!==-1&&(e?o.bufferSubData(d,p.offset*u.BYTES_PER_ELEMENT,u,p.offset,p.count):o.bufferSubData(d,p.offset*u.BYTES_PER_ELEMENT,u.subarray(p.offset,p.offset+p.count)),p.count=-1),h.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),n.get(l)}function r(l){l.isInterleavedBufferAttribute&&(l=l.data);const h=n.get(l);h&&(o.deleteBuffer(h.buffer),n.delete(l))}function c(l,h){if(l.isGLBufferAttribute){const u=n.get(l);(!u||u.version<l.version)&&n.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);const d=n.get(l);if(d===void 0)n.set(l,i(l,h));else if(d.version<l.version){if(d.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(d.buffer,l,h),d.version=l.version}}return{get:a,remove:r,update:c}}class wn extends Te{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};const s=t/2,a=e/2,r=Math.floor(n),c=Math.floor(i),l=r+1,h=c+1,d=t/r,u=e/c,p=[],g=[],y=[],m=[];for(let f=0;f<h;f++){const _=f*u-a;for(let x=0;x<l;x++){const M=x*d-s;g.push(M,-_,0),y.push(0,0,1),m.push(x/r),m.push(1-f/c)}}for(let f=0;f<c;f++)for(let _=0;_<r;_++){const x=_+l*f,M=_+l*(f+1),R=_+1+l*(f+1),A=_+1+l*f;p.push(x,M,A),p.push(M,R,A)}this.setIndex(p),this.setAttribute("position",new te(g,3)),this.setAttribute("normal",new te(y,3)),this.setAttribute("uv",new te(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new wn(t.width,t.height,t.widthSegments,t.heightSegments)}}var Iu=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Du=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Uu=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Nu=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Bu=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Fu=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ou=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,zu=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,ku=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Gu=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,Hu=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Vu=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Wu=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Xu=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,qu=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Yu=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,$u=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Zu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,ju=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ku=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Ju=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Qu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,tp=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,ep=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,np=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,ip=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,sp=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,op=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,ap=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,rp=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,cp="gl_FragColor = linearToOutputTexel( gl_FragColor );",lp=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,hp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,dp=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,up=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,pp=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,fp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,mp=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,gp=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,wp=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,yp=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,xp=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,vp=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,_p=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Mp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Sp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,bp=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Ep=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Tp=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Ap=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Cp=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Rp=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Lp=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Pp=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Ip=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Dp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Up=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Np=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Bp=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Fp=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,Op=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,zp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,kp=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Gp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Hp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Vp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Wp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Xp=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,qp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Yp=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,$p=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Zp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,jp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Kp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Jp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Qp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,tf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,ef=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,nf=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,sf=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,of=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,af=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,rf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,cf=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,lf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,hf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,df=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,uf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,pf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,ff=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,mf=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,gf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,wf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,yf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,xf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,vf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,_f=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Mf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,Sf=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,bf=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Ef=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Tf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Af=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Cf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Rf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Lf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Pf=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const If=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Df=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Uf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Nf=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ff=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Of=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,zf=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,kf=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Gf=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Hf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Vf=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Wf=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Xf=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,qf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Yf=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$f=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Zf=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jf=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Kf=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jf=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Qf=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,t0=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,e0=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,n0=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,i0=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,s0=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,o0=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,a0=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,r0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,c0=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,l0=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,h0=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,d0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Kt={alphahash_fragment:Iu,alphahash_pars_fragment:Du,alphamap_fragment:Uu,alphamap_pars_fragment:Nu,alphatest_fragment:Bu,alphatest_pars_fragment:Fu,aomap_fragment:Ou,aomap_pars_fragment:zu,batching_pars_vertex:ku,batching_vertex:Gu,begin_vertex:Hu,beginnormal_vertex:Vu,bsdfs:Wu,iridescence_fragment:Xu,bumpmap_pars_fragment:qu,clipping_planes_fragment:Yu,clipping_planes_pars_fragment:$u,clipping_planes_pars_vertex:Zu,clipping_planes_vertex:ju,color_fragment:Ku,color_pars_fragment:Ju,color_pars_vertex:Qu,color_vertex:tp,common:ep,cube_uv_reflection_fragment:np,defaultnormal_vertex:ip,displacementmap_pars_vertex:sp,displacementmap_vertex:op,emissivemap_fragment:ap,emissivemap_pars_fragment:rp,colorspace_fragment:cp,colorspace_pars_fragment:lp,envmap_fragment:hp,envmap_common_pars_fragment:dp,envmap_pars_fragment:up,envmap_pars_vertex:pp,envmap_physical_pars_fragment:Ep,envmap_vertex:fp,fog_vertex:mp,fog_pars_vertex:gp,fog_fragment:wp,fog_pars_fragment:yp,gradientmap_pars_fragment:xp,lightmap_fragment:vp,lightmap_pars_fragment:_p,lights_lambert_fragment:Mp,lights_lambert_pars_fragment:Sp,lights_pars_begin:bp,lights_toon_fragment:Tp,lights_toon_pars_fragment:Ap,lights_phong_fragment:Cp,lights_phong_pars_fragment:Rp,lights_physical_fragment:Lp,lights_physical_pars_fragment:Pp,lights_fragment_begin:Ip,lights_fragment_maps:Dp,lights_fragment_end:Up,logdepthbuf_fragment:Np,logdepthbuf_pars_fragment:Bp,logdepthbuf_pars_vertex:Fp,logdepthbuf_vertex:Op,map_fragment:zp,map_pars_fragment:kp,map_particle_fragment:Gp,map_particle_pars_fragment:Hp,metalnessmap_fragment:Vp,metalnessmap_pars_fragment:Wp,morphcolor_vertex:Xp,morphnormal_vertex:qp,morphtarget_pars_vertex:Yp,morphtarget_vertex:$p,normal_fragment_begin:Zp,normal_fragment_maps:jp,normal_pars_fragment:Kp,normal_pars_vertex:Jp,normal_vertex:Qp,normalmap_pars_fragment:tf,clearcoat_normal_fragment_begin:ef,clearcoat_normal_fragment_maps:nf,clearcoat_pars_fragment:sf,iridescence_pars_fragment:of,opaque_fragment:af,packing:rf,premultiplied_alpha_fragment:cf,project_vertex:lf,dithering_fragment:hf,dithering_pars_fragment:df,roughnessmap_fragment:uf,roughnessmap_pars_fragment:pf,shadowmap_pars_fragment:ff,shadowmap_pars_vertex:mf,shadowmap_vertex:gf,shadowmask_pars_fragment:wf,skinbase_vertex:yf,skinning_pars_vertex:xf,skinning_vertex:vf,skinnormal_vertex:_f,specularmap_fragment:Mf,specularmap_pars_fragment:Sf,tonemapping_fragment:bf,tonemapping_pars_fragment:Ef,transmission_fragment:Tf,transmission_pars_fragment:Af,uv_pars_fragment:Cf,uv_pars_vertex:Rf,uv_vertex:Lf,worldpos_vertex:Pf,background_vert:If,background_frag:Df,backgroundCube_vert:Uf,backgroundCube_frag:Nf,cube_vert:Bf,cube_frag:Ff,depth_vert:Of,depth_frag:zf,distanceRGBA_vert:kf,distanceRGBA_frag:Gf,equirect_vert:Hf,equirect_frag:Vf,linedashed_vert:Wf,linedashed_frag:Xf,meshbasic_vert:qf,meshbasic_frag:Yf,meshlambert_vert:$f,meshlambert_frag:Zf,meshmatcap_vert:jf,meshmatcap_frag:Kf,meshnormal_vert:Jf,meshnormal_frag:Qf,meshphong_vert:t0,meshphong_frag:e0,meshphysical_vert:n0,meshphysical_frag:i0,meshtoon_vert:s0,meshtoon_frag:o0,points_vert:a0,points_frag:r0,shadow_vert:c0,shadow_frag:l0,sprite_vert:h0,sprite_frag:d0},gt={common:{diffuse:{value:new Vt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Qt},alphaMap:{value:null},alphaMapTransform:{value:new Qt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Qt}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Qt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Qt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Qt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Qt},normalScale:{value:new dt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Qt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Qt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Qt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Qt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Vt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Vt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Qt},alphaTest:{value:0},uvTransform:{value:new Qt}},sprite:{diffuse:{value:new Vt(16777215)},opacity:{value:1},center:{value:new dt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Qt},alphaMap:{value:null},alphaMapTransform:{value:new Qt},alphaTest:{value:0}}},gn={basic:{uniforms:Oe([gt.common,gt.specularmap,gt.envmap,gt.aomap,gt.lightmap,gt.fog]),vertexShader:Kt.meshbasic_vert,fragmentShader:Kt.meshbasic_frag},lambert:{uniforms:Oe([gt.common,gt.specularmap,gt.envmap,gt.aomap,gt.lightmap,gt.emissivemap,gt.bumpmap,gt.normalmap,gt.displacementmap,gt.fog,gt.lights,{emissive:{value:new Vt(0)}}]),vertexShader:Kt.meshlambert_vert,fragmentShader:Kt.meshlambert_frag},phong:{uniforms:Oe([gt.common,gt.specularmap,gt.envmap,gt.aomap,gt.lightmap,gt.emissivemap,gt.bumpmap,gt.normalmap,gt.displacementmap,gt.fog,gt.lights,{emissive:{value:new Vt(0)},specular:{value:new Vt(1118481)},shininess:{value:30}}]),vertexShader:Kt.meshphong_vert,fragmentShader:Kt.meshphong_frag},standard:{uniforms:Oe([gt.common,gt.envmap,gt.aomap,gt.lightmap,gt.emissivemap,gt.bumpmap,gt.normalmap,gt.displacementmap,gt.roughnessmap,gt.metalnessmap,gt.fog,gt.lights,{emissive:{value:new Vt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Kt.meshphysical_vert,fragmentShader:Kt.meshphysical_frag},toon:{uniforms:Oe([gt.common,gt.aomap,gt.lightmap,gt.emissivemap,gt.bumpmap,gt.normalmap,gt.displacementmap,gt.gradientmap,gt.fog,gt.lights,{emissive:{value:new Vt(0)}}]),vertexShader:Kt.meshtoon_vert,fragmentShader:Kt.meshtoon_frag},matcap:{uniforms:Oe([gt.common,gt.bumpmap,gt.normalmap,gt.displacementmap,gt.fog,{matcap:{value:null}}]),vertexShader:Kt.meshmatcap_vert,fragmentShader:Kt.meshmatcap_frag},points:{uniforms:Oe([gt.points,gt.fog]),vertexShader:Kt.points_vert,fragmentShader:Kt.points_frag},dashed:{uniforms:Oe([gt.common,gt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Kt.linedashed_vert,fragmentShader:Kt.linedashed_frag},depth:{uniforms:Oe([gt.common,gt.displacementmap]),vertexShader:Kt.depth_vert,fragmentShader:Kt.depth_frag},normal:{uniforms:Oe([gt.common,gt.bumpmap,gt.normalmap,gt.displacementmap,{opacity:{value:1}}]),vertexShader:Kt.meshnormal_vert,fragmentShader:Kt.meshnormal_frag},sprite:{uniforms:Oe([gt.sprite,gt.fog]),vertexShader:Kt.sprite_vert,fragmentShader:Kt.sprite_frag},background:{uniforms:{uvTransform:{value:new Qt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Kt.background_vert,fragmentShader:Kt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Kt.backgroundCube_vert,fragmentShader:Kt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Kt.cube_vert,fragmentShader:Kt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Kt.equirect_vert,fragmentShader:Kt.equirect_frag},distanceRGBA:{uniforms:Oe([gt.common,gt.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Kt.distanceRGBA_vert,fragmentShader:Kt.distanceRGBA_frag},shadow:{uniforms:Oe([gt.lights,gt.fog,{color:{value:new Vt(0)},opacity:{value:1}}]),vertexShader:Kt.shadow_vert,fragmentShader:Kt.shadow_frag}};gn.physical={uniforms:Oe([gn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Qt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Qt},clearcoatNormalScale:{value:new dt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Qt},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Qt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Qt},sheen:{value:0},sheenColor:{value:new Vt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Qt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Qt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Qt},transmissionSamplerSize:{value:new dt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Qt},attenuationDistance:{value:0},attenuationColor:{value:new Vt(0)},specularColor:{value:new Vt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Qt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Qt},anisotropyVector:{value:new dt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Qt}}]),vertexShader:Kt.meshphysical_vert,fragmentShader:Kt.meshphysical_frag};const Po={r:0,b:0,g:0};function u0(o,t,e,n,i,s,a){const r=new Vt(0);let c=s===!0?0:1,l,h,d=null,u=0,p=null;function g(m,f){let _=!1,x=f.isScene===!0?f.background:null;x&&x.isTexture&&(x=(f.backgroundBlurriness>0?e:t).get(x)),x===null?y(r,c):x&&x.isColor&&(y(x,1),_=!0);const M=o.xr.getEnvironmentBlendMode();M==="additive"?n.buffers.color.setClear(0,0,0,1,a):M==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(o.autoClear||_)&&o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil),x&&(x.isCubeTexture||x.mapping===ta)?(h===void 0&&(h=new w(new U(1,1,1),new gi({name:"BackgroundCubeMaterial",uniforms:hs(gn.backgroundCube.uniforms),vertexShader:gn.backgroundCube.vertexShader,fragmentShader:gn.backgroundCube.fragmentShader,side:He,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(R,A,E){this.matrixWorld.copyPosition(E.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),h.material.uniforms.envMap.value=x,h.material.uniforms.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,h.material.toneMapped=re.getTransfer(x.colorSpace)!==ue,(d!==x||u!==x.version||p!==o.toneMapping)&&(h.material.needsUpdate=!0,d=x,u=x.version,p=o.toneMapping),h.layers.enableAll(),m.unshift(h,h.geometry,h.material,0,0,null)):x&&x.isTexture&&(l===void 0&&(l=new w(new wn(2,2),new gi({name:"BackgroundMaterial",uniforms:hs(gn.background.uniforms),vertexShader:gn.background.vertexShader,fragmentShader:gn.background.fragmentShader,side:Yn,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(l)),l.material.uniforms.t2D.value=x,l.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,l.material.toneMapped=re.getTransfer(x.colorSpace)!==ue,x.matrixAutoUpdate===!0&&x.updateMatrix(),l.material.uniforms.uvTransform.value.copy(x.matrix),(d!==x||u!==x.version||p!==o.toneMapping)&&(l.material.needsUpdate=!0,d=x,u=x.version,p=o.toneMapping),l.layers.enableAll(),m.unshift(l,l.geometry,l.material,0,0,null))}function y(m,f){m.getRGB(Po,gh(o)),n.buffers.color.setClear(Po.r,Po.g,Po.b,f,a)}return{getClearColor:function(){return r},setClearColor:function(m,f=1){r.set(m),c=f,y(r,c)},getClearAlpha:function(){return c},setClearAlpha:function(m){c=m,y(r,c)},render:g}}function p0(o,t,e,n){const i=o.getParameter(o.MAX_VERTEX_ATTRIBS),s=n.isWebGL2?null:t.get("OES_vertex_array_object"),a=n.isWebGL2||s!==null,r={},c=m(null);let l=c,h=!1;function d(D,F,z,Z,Y){let q=!1;if(a){const J=y(Z,z,F);l!==J&&(l=J,p(l.object)),q=f(D,Z,z,Y),q&&_(D,Z,z,Y)}else{const J=F.wireframe===!0;(l.geometry!==Z.id||l.program!==z.id||l.wireframe!==J)&&(l.geometry=Z.id,l.program=z.id,l.wireframe=J,q=!0)}Y!==null&&e.update(Y,o.ELEMENT_ARRAY_BUFFER),(q||h)&&(h=!1,I(D,F,z,Z),Y!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,e.get(Y).buffer))}function u(){return n.isWebGL2?o.createVertexArray():s.createVertexArrayOES()}function p(D){return n.isWebGL2?o.bindVertexArray(D):s.bindVertexArrayOES(D)}function g(D){return n.isWebGL2?o.deleteVertexArray(D):s.deleteVertexArrayOES(D)}function y(D,F,z){const Z=z.wireframe===!0;let Y=r[D.id];Y===void 0&&(Y={},r[D.id]=Y);let q=Y[F.id];q===void 0&&(q={},Y[F.id]=q);let J=q[Z];return J===void 0&&(J=m(u()),q[Z]=J),J}function m(D){const F=[],z=[],Z=[];for(let Y=0;Y<i;Y++)F[Y]=0,z[Y]=0,Z[Y]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:z,attributeDivisors:Z,object:D,attributes:{},index:null}}function f(D,F,z,Z){const Y=l.attributes,q=F.attributes;let J=0;const nt=z.getAttributes();for(const ct in nt)if(nt[ct].location>=0){const et=Y[ct];let pt=q[ct];if(pt===void 0&&(ct==="instanceMatrix"&&D.instanceMatrix&&(pt=D.instanceMatrix),ct==="instanceColor"&&D.instanceColor&&(pt=D.instanceColor)),et===void 0||et.attribute!==pt||pt&&et.data!==pt.data)return!0;J++}return l.attributesNum!==J||l.index!==Z}function _(D,F,z,Z){const Y={},q=F.attributes;let J=0;const nt=z.getAttributes();for(const ct in nt)if(nt[ct].location>=0){let et=q[ct];et===void 0&&(ct==="instanceMatrix"&&D.instanceMatrix&&(et=D.instanceMatrix),ct==="instanceColor"&&D.instanceColor&&(et=D.instanceColor));const pt={};pt.attribute=et,et&&et.data&&(pt.data=et.data),Y[ct]=pt,J++}l.attributes=Y,l.attributesNum=J,l.index=Z}function x(){const D=l.newAttributes;for(let F=0,z=D.length;F<z;F++)D[F]=0}function M(D){R(D,0)}function R(D,F){const z=l.newAttributes,Z=l.enabledAttributes,Y=l.attributeDivisors;z[D]=1,Z[D]===0&&(o.enableVertexAttribArray(D),Z[D]=1),Y[D]!==F&&((n.isWebGL2?o:t.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](D,F),Y[D]=F)}function A(){const D=l.newAttributes,F=l.enabledAttributes;for(let z=0,Z=F.length;z<Z;z++)F[z]!==D[z]&&(o.disableVertexAttribArray(z),F[z]=0)}function E(D,F,z,Z,Y,q,J){J===!0?o.vertexAttribIPointer(D,F,z,Y,q):o.vertexAttribPointer(D,F,z,Z,Y,q)}function I(D,F,z,Z){if(n.isWebGL2===!1&&(D.isInstancedMesh||Z.isInstancedBufferGeometry)&&t.get("ANGLE_instanced_arrays")===null)return;x();const Y=Z.attributes,q=z.getAttributes(),J=F.defaultAttributeValues;for(const nt in q){const ct=q[nt];if(ct.location>=0){let X=Y[nt];if(X===void 0&&(nt==="instanceMatrix"&&D.instanceMatrix&&(X=D.instanceMatrix),nt==="instanceColor"&&D.instanceColor&&(X=D.instanceColor)),X!==void 0){const et=X.normalized,pt=X.itemSize,bt=e.get(X);if(bt===void 0)continue;const xt=bt.buffer,It=bt.type,Gt=bt.bytesPerElement,At=n.isWebGL2===!0&&(It===o.INT||It===o.UNSIGNED_INT||X.gpuType===Ql);if(X.isInterleavedBufferAttribute){const Et=X.data,N=Et.stride,ht=X.offset;if(Et.isInstancedInterleavedBuffer){for(let tt=0;tt<ct.locationSize;tt++)R(ct.location+tt,Et.meshPerAttribute);D.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=Et.meshPerAttribute*Et.count)}else for(let tt=0;tt<ct.locationSize;tt++)M(ct.location+tt);o.bindBuffer(o.ARRAY_BUFFER,xt);for(let tt=0;tt<ct.locationSize;tt++)E(ct.location+tt,pt/ct.locationSize,It,et,N*Gt,(ht+pt/ct.locationSize*tt)*Gt,At)}else{if(X.isInstancedBufferAttribute){for(let Et=0;Et<ct.locationSize;Et++)R(ct.location+Et,X.meshPerAttribute);D.isInstancedMesh!==!0&&Z._maxInstanceCount===void 0&&(Z._maxInstanceCount=X.meshPerAttribute*X.count)}else for(let Et=0;Et<ct.locationSize;Et++)M(ct.location+Et);o.bindBuffer(o.ARRAY_BUFFER,xt);for(let Et=0;Et<ct.locationSize;Et++)E(ct.location+Et,pt/ct.locationSize,It,et,pt*Gt,pt/ct.locationSize*Et*Gt,At)}}else if(J!==void 0){const et=J[nt];if(et!==void 0)switch(et.length){case 2:o.vertexAttrib2fv(ct.location,et);break;case 3:o.vertexAttrib3fv(ct.location,et);break;case 4:o.vertexAttrib4fv(ct.location,et);break;default:o.vertexAttrib1fv(ct.location,et)}}}}A()}function v(){O();for(const D in r){const F=r[D];for(const z in F){const Z=F[z];for(const Y in Z)g(Z[Y].object),delete Z[Y];delete F[z]}delete r[D]}}function S(D){if(r[D.id]===void 0)return;const F=r[D.id];for(const z in F){const Z=F[z];for(const Y in Z)g(Z[Y].object),delete Z[Y];delete F[z]}delete r[D.id]}function P(D){for(const F in r){const z=r[F];if(z[D.id]===void 0)continue;const Z=z[D.id];for(const Y in Z)g(Z[Y].object),delete Z[Y];delete z[D.id]}}function O(){j(),h=!0,l!==c&&(l=c,p(l.object))}function j(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:d,reset:O,resetDefaultState:j,dispose:v,releaseStatesOfGeometry:S,releaseStatesOfProgram:P,initAttributes:x,enableAttribute:M,disableUnusedAttributes:A}}function f0(o,t,e,n){const i=n.isWebGL2;let s;function a(h){s=h}function r(h,d){o.drawArrays(s,h,d),e.update(d,s,1)}function c(h,d,u){if(u===0)return;let p,g;if(i)p=o,g="drawArraysInstanced";else if(p=t.get("ANGLE_instanced_arrays"),g="drawArraysInstancedANGLE",p===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[g](s,h,d,u),e.update(d,s,u)}function l(h,d,u){if(u===0)return;const p=t.get("WEBGL_multi_draw");if(p===null)for(let g=0;g<u;g++)this.render(h[g],d[g]);else{p.multiDrawArraysWEBGL(s,h,0,d,0,u);let g=0;for(let y=0;y<u;y++)g+=d[y];e.update(g,s,1)}}this.setMode=a,this.render=r,this.renderInstances=c,this.renderMultiDraw=l}function m0(o,t,e){let n;function i(){if(n!==void 0)return n;if(t.has("EXT_texture_filter_anisotropic")===!0){const E=t.get("EXT_texture_filter_anisotropic");n=o.getParameter(E.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function s(E){if(E==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";E="mediump"}return E==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&o.constructor.name==="WebGL2RenderingContext";let r=e.precision!==void 0?e.precision:"highp";const c=s(r);c!==r&&(console.warn("THREE.WebGLRenderer:",r,"not supported, using",c,"instead."),r=c);const l=a||t.has("WEBGL_draw_buffers"),h=e.logarithmicDepthBuffer===!0,d=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),u=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),p=o.getParameter(o.MAX_TEXTURE_SIZE),g=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),y=o.getParameter(o.MAX_VERTEX_ATTRIBS),m=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),f=o.getParameter(o.MAX_VARYING_VECTORS),_=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),x=u>0,M=a||t.has("OES_texture_float"),R=x&&M,A=a?o.getParameter(o.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:i,getMaxPrecision:s,precision:r,logarithmicDepthBuffer:h,maxTextures:d,maxVertexTextures:u,maxTextureSize:p,maxCubemapSize:g,maxAttributes:y,maxVertexUniforms:m,maxVaryings:f,maxFragmentUniforms:_,vertexTextures:x,floatFragmentTextures:M,floatVertexTextures:R,maxSamples:A}}function g0(o){const t=this;let e=null,n=0,i=!1,s=!1;const a=new ci,r=new Qt,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,u){const p=d.length!==0||u||n!==0||i;return i=u,n=d.length,p},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(d,u){e=h(d,u,0)},this.setState=function(d,u,p){const g=d.clippingPlanes,y=d.clipIntersection,m=d.clipShadows,f=o.get(d);if(!i||g===null||g.length===0||s&&!m)s?h(null):l();else{const _=s?0:n,x=_*4;let M=f.clippingState||null;c.value=M,M=h(g,u,x,p);for(let R=0;R!==x;++R)M[R]=e[R];f.clippingState=M,this.numIntersection=y?this.numPlanes:0,this.numPlanes+=_}};function l(){c.value!==e&&(c.value=e,c.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(d,u,p,g){const y=d!==null?d.length:0;let m=null;if(y!==0){if(m=c.value,g!==!0||m===null){const f=p+y*4,_=u.matrixWorldInverse;r.getNormalMatrix(_),(m===null||m.length<f)&&(m=new Float32Array(f));for(let x=0,M=p;x!==y;++x,M+=4)a.copy(d[x]).applyMatrix4(_,r),a.normal.toArray(m,M),m[M+3]=a.constant}c.value=m,c.needsUpdate=!0}return t.numPlanes=y,t.numIntersection=0,m}}function w0(o){let t=new WeakMap;function e(a,r){return r===pr?a.mapping=rs:r===fr&&(a.mapping=cs),a}function n(a){if(a&&a.isTexture){const r=a.mapping;if(r===pr||r===fr)if(t.has(a)){const c=t.get(a).texture;return e(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new Cu(c.height/2);return l.fromEquirectangularTexture(o,a),t.set(a,l),a.addEventListener("dispose",i),e(l.texture,a.mapping)}else return null}}return a}function i(a){const r=a.target;r.removeEventListener("dispose",i);const c=t.get(r);c!==void 0&&(t.delete(r),c.dispose())}function s(){t=new WeakMap}return{get:n,dispose:s}}class vh extends wh{constructor(t=-1,e=1,n=1,i=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let s=n-t,a=n+t,r=i+e,c=i-e;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,a=s+l*this.view.width,r-=h*this.view.offsetY,c=r-h*this.view.height}this.projectionMatrix.makeOrthographic(s,a,r,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}const ns=4,ll=[.125,.215,.35,.446,.526,.582],di=20,Ja=new vh,hl=new Vt;let Qa=null,tr=0,er=0;const li=(1+Math.sqrt(5))/2,Zi=1/li,dl=[new L(1,1,1),new L(-1,1,1),new L(1,1,-1),new L(-1,1,-1),new L(0,li,Zi),new L(0,li,-Zi),new L(Zi,0,li),new L(-Zi,0,li),new L(li,Zi,0),new L(-li,Zi,0)];class ul{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100){Qa=this._renderer.getRenderTarget(),tr=this._renderer.getActiveCubeFace(),er=this._renderer.getActiveMipmapLevel(),this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(t,n,i,s),e>0&&this._blur(s,0,0,e),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ml(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=fl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Qa,tr,er),t.scissorTest=!1,Io(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===rs||t.mapping===cs?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Qa=this._renderer.getRenderTarget(),tr=this._renderer.getActiveCubeFace(),er=this._renderer.getActiveMipmapLevel();const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:tn,minFilter:tn,generateMipmaps:!1,type:Ns,format:hn,colorSpace:Un,depthBuffer:!1},i=pl(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=pl(t,e,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=y0(s)),this._blurMaterial=x0(s,t,e)}return i}_compileMaterial(t){const e=new w(this._lodPlanes[0],t);this._renderer.compile(e,Ja)}_sceneToCubeUV(t,e,n,i){const r=new Ge(90,1,e,n),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],h=this._renderer,d=h.autoClear,u=h.toneMapping;h.getClearColor(hl),h.toneMapping=Xn,h.autoClear=!1;const p=new _t({name:"PMREM.Background",side:He,depthWrite:!1,depthTest:!1}),g=new w(new U,p);let y=!1;const m=t.background;m?m.isColor&&(p.color.copy(m),t.background=null,y=!0):(p.color.copy(hl),y=!0);for(let f=0;f<6;f++){const _=f%3;_===0?(r.up.set(0,c[f],0),r.lookAt(l[f],0,0)):_===1?(r.up.set(0,0,c[f]),r.lookAt(0,l[f],0)):(r.up.set(0,c[f],0),r.lookAt(0,0,l[f]));const x=this._cubeSize;Io(i,_*x,f>2?x:0,x,x),h.setRenderTarget(i),y&&h.render(g,r),h.render(t,r)}g.geometry.dispose(),g.material.dispose(),h.toneMapping=u,h.autoClear=d,t.background=m}_textureToCubeUV(t,e){const n=this._renderer,i=t.mapping===rs||t.mapping===cs;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=ml()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=fl());const s=i?this._cubemapMaterial:this._equirectMaterial,a=new w(this._lodPlanes[0],s),r=s.uniforms;r.envMap.value=t;const c=this._cubeSize;Io(e,0,0,3*c,2*c),n.setRenderTarget(e),n.render(a,Ja)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;for(let i=1;i<this._lodPlanes.length;i++){const s=Math.sqrt(this._sigmas[i]*this._sigmas[i]-this._sigmas[i-1]*this._sigmas[i-1]),a=dl[(i-1)%dl.length];this._blur(t,i-1,i,s,a)}e.autoClear=n}_blur(t,e,n,i,s){const a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,i,"latitudinal",s),this._halfBlur(a,t,n,n,i,"longitudinal",s)}_halfBlur(t,e,n,i,s,a,r){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,d=new w(this._lodPlanes[i],l),u=l.uniforms,p=this._sizeLods[n]-1,g=isFinite(s)?Math.PI/(2*p):2*Math.PI/(2*di-1),y=s/g,m=isFinite(s)?1+Math.floor(h*y):di;m>di&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${di}`);const f=[];let _=0;for(let E=0;E<di;++E){const I=E/y,v=Math.exp(-I*I/2);f.push(v),E===0?_+=v:E<m&&(_+=2*v)}for(let E=0;E<f.length;E++)f[E]=f[E]/_;u.envMap.value=t.texture,u.samples.value=m,u.weights.value=f,u.latitudinal.value=a==="latitudinal",r&&(u.poleAxis.value=r);const{_lodMax:x}=this;u.dTheta.value=g,u.mipInt.value=x-n;const M=this._sizeLods[i],R=3*M*(i>x-ns?i-x+ns:0),A=4*(this._cubeSize-M);Io(e,R,A,3*M,2*M),c.setRenderTarget(e),c.render(d,Ja)}}function y0(o){const t=[],e=[],n=[];let i=o;const s=o-ns+1+ll.length;for(let a=0;a<s;a++){const r=Math.pow(2,i);e.push(r);let c=1/r;a>o-ns?c=ll[a-o+ns-1]:a===0&&(c=0),n.push(c);const l=1/(r-2),h=-l,d=1+l,u=[h,h,d,h,d,d,h,h,d,d,h,d],p=6,g=6,y=3,m=2,f=1,_=new Float32Array(y*g*p),x=new Float32Array(m*g*p),M=new Float32Array(f*g*p);for(let A=0;A<p;A++){const E=A%3*2/3-1,I=A>2?0:-1,v=[E,I,0,E+2/3,I,0,E+2/3,I+1,0,E,I,0,E+2/3,I+1,0,E,I+1,0];_.set(v,y*g*A),x.set(u,m*g*A);const S=[A,A,A,A,A,A];M.set(S,f*g*A)}const R=new Te;R.setAttribute("position",new sn(_,y)),R.setAttribute("uv",new sn(x,m)),R.setAttribute("faceIndex",new sn(M,f)),t.push(R),i>ns&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function pl(o,t,e){const n=new mi(o,t,e);return n.texture.mapping=ta,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Io(o,t,e,n,i){o.viewport.set(t,e,n,i),o.scissor.set(t,e,n,i)}function x0(o,t,e){const n=new Float32Array(di),i=new L(0,1,0);return new gi({name:"SphericalGaussianBlur",defines:{n:di,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:Ir(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Wn,depthTest:!1,depthWrite:!1})}function fl(){return new gi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ir(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Wn,depthTest:!1,depthWrite:!1})}function ml(){return new gi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ir(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Wn,depthTest:!1,depthWrite:!1})}function Ir(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function v0(o){let t=new WeakMap,e=null;function n(r){if(r&&r.isTexture){const c=r.mapping,l=c===pr||c===fr,h=c===rs||c===cs;if(l||h)if(r.isRenderTargetTexture&&r.needsPMREMUpdate===!0){r.needsPMREMUpdate=!1;let d=t.get(r);return e===null&&(e=new ul(o)),d=l?e.fromEquirectangular(r,d):e.fromCubemap(r,d),t.set(r,d),d.texture}else{if(t.has(r))return t.get(r).texture;{const d=r.image;if(l&&d&&d.height>0||h&&d&&i(d)){e===null&&(e=new ul(o));const u=l?e.fromEquirectangular(r):e.fromCubemap(r);return t.set(r,u),r.addEventListener("dispose",s),u.texture}else return null}}}return r}function i(r){let c=0;const l=6;for(let h=0;h<l;h++)r[h]!==void 0&&c++;return c===l}function s(r){const c=r.target;c.removeEventListener("dispose",s);const l=t.get(c);l!==void 0&&(t.delete(c),l.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function _0(o){const t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=o.getExtension("WEBGL_depth_texture")||o.getExtension("MOZ_WEBGL_depth_texture")||o.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=o.getExtension("EXT_texture_filter_anisotropic")||o.getExtension("MOZ_EXT_texture_filter_anisotropic")||o.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=o.getExtension("WEBGL_compressed_texture_s3tc")||o.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=o.getExtension("WEBGL_compressed_texture_pvrtc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=o.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(n){n.isWebGL2?(e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance")):(e("WEBGL_depth_texture"),e("OES_texture_float"),e("OES_texture_half_float"),e("OES_texture_half_float_linear"),e("OES_standard_derivatives"),e("OES_element_index_uint"),e("OES_vertex_array_object"),e("ANGLE_instanced_arrays")),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture")},get:function(n){const i=e(n);return i===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function M0(o,t,e,n){const i={},s=new WeakMap;function a(d){const u=d.target;u.index!==null&&t.remove(u.index);for(const g in u.attributes)t.remove(u.attributes[g]);for(const g in u.morphAttributes){const y=u.morphAttributes[g];for(let m=0,f=y.length;m<f;m++)t.remove(y[m])}u.removeEventListener("dispose",a),delete i[u.id];const p=s.get(u);p&&(t.remove(p),s.delete(u)),n.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,e.memory.geometries--}function r(d,u){return i[u.id]===!0||(u.addEventListener("dispose",a),i[u.id]=!0,e.memory.geometries++),u}function c(d){const u=d.attributes;for(const g in u)t.update(u[g],o.ARRAY_BUFFER);const p=d.morphAttributes;for(const g in p){const y=p[g];for(let m=0,f=y.length;m<f;m++)t.update(y[m],o.ARRAY_BUFFER)}}function l(d){const u=[],p=d.index,g=d.attributes.position;let y=0;if(p!==null){const _=p.array;y=p.version;for(let x=0,M=_.length;x<M;x+=3){const R=_[x+0],A=_[x+1],E=_[x+2];u.push(R,A,A,E,E,R)}}else if(g!==void 0){const _=g.array;y=g.version;for(let x=0,M=_.length/3-1;x<M;x+=3){const R=x+0,A=x+1,E=x+2;u.push(R,A,A,E,E,R)}}else return;const m=new(lh(u)?mh:fh)(u,1);m.version=y;const f=s.get(d);f&&t.remove(f),s.set(d,m)}function h(d){const u=s.get(d);if(u){const p=d.index;p!==null&&u.version<p.version&&l(d)}else l(d);return s.get(d)}return{get:r,update:c,getWireframeAttribute:h}}function S0(o,t,e,n){const i=n.isWebGL2;let s;function a(p){s=p}let r,c;function l(p){r=p.type,c=p.bytesPerElement}function h(p,g){o.drawElements(s,g,r,p*c),e.update(g,s,1)}function d(p,g,y){if(y===0)return;let m,f;if(i)m=o,f="drawElementsInstanced";else if(m=t.get("ANGLE_instanced_arrays"),f="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[f](s,g,r,p*c,y),e.update(g,s,y)}function u(p,g,y){if(y===0)return;const m=t.get("WEBGL_multi_draw");if(m===null)for(let f=0;f<y;f++)this.render(p[f]/c,g[f]);else{m.multiDrawElementsWEBGL(s,g,0,r,p,0,y);let f=0;for(let _=0;_<y;_++)f+=g[_];e.update(f,s,1)}}this.setMode=a,this.setIndex=l,this.render=h,this.renderInstances=d,this.renderMultiDraw=u}function b0(o){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,r){switch(e.calls++,a){case o.TRIANGLES:e.triangles+=r*(s/3);break;case o.LINES:e.lines+=r*(s/2);break;case o.LINE_STRIP:e.lines+=r*(s-1);break;case o.LINE_LOOP:e.lines+=r*s;break;case o.POINTS:e.points+=r*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function E0(o,t){return o[0]-t[0]}function T0(o,t){return Math.abs(t[1])-Math.abs(o[1])}function A0(o,t,e){const n={},i=new Float32Array(8),s=new WeakMap,a=new ge,r=[];for(let l=0;l<8;l++)r[l]=[l,0];function c(l,h,d){const u=l.morphTargetInfluences;if(t.isWebGL2===!0){const p=h.morphAttributes.position||h.morphAttributes.normal||h.morphAttributes.color,g=p!==void 0?p.length:0;let y=s.get(h);if(y===void 0||y.count!==g){let D=function(){O.dispose(),s.delete(h),h.removeEventListener("dispose",D)};y!==void 0&&y.texture.dispose();const _=h.morphAttributes.position!==void 0,x=h.morphAttributes.normal!==void 0,M=h.morphAttributes.color!==void 0,R=h.morphAttributes.position||[],A=h.morphAttributes.normal||[],E=h.morphAttributes.color||[];let I=0;_===!0&&(I=1),x===!0&&(I=2),M===!0&&(I=3);let v=h.attributes.position.count*I,S=1;v>t.maxTextureSize&&(S=Math.ceil(v/t.maxTextureSize),v=t.maxTextureSize);const P=new Float32Array(v*S*4*g),O=new uh(P,v,S,g);O.type=Hn,O.needsUpdate=!0;const j=I*4;for(let F=0;F<g;F++){const z=R[F],Z=A[F],Y=E[F],q=v*S*4*F;for(let J=0;J<z.count;J++){const nt=J*j;_===!0&&(a.fromBufferAttribute(z,J),P[q+nt+0]=a.x,P[q+nt+1]=a.y,P[q+nt+2]=a.z,P[q+nt+3]=0),x===!0&&(a.fromBufferAttribute(Z,J),P[q+nt+4]=a.x,P[q+nt+5]=a.y,P[q+nt+6]=a.z,P[q+nt+7]=0),M===!0&&(a.fromBufferAttribute(Y,J),P[q+nt+8]=a.x,P[q+nt+9]=a.y,P[q+nt+10]=a.z,P[q+nt+11]=Y.itemSize===4?a.w:1)}}y={count:g,texture:O,size:new dt(v,S)},s.set(h,y),h.addEventListener("dispose",D)}let m=0;for(let _=0;_<u.length;_++)m+=u[_];const f=h.morphTargetsRelative?1:1-m;d.getUniforms().setValue(o,"morphTargetBaseInfluence",f),d.getUniforms().setValue(o,"morphTargetInfluences",u),d.getUniforms().setValue(o,"morphTargetsTexture",y.texture,e),d.getUniforms().setValue(o,"morphTargetsTextureSize",y.size)}else{const p=u===void 0?0:u.length;let g=n[h.id];if(g===void 0||g.length!==p){g=[];for(let x=0;x<p;x++)g[x]=[x,0];n[h.id]=g}for(let x=0;x<p;x++){const M=g[x];M[0]=x,M[1]=u[x]}g.sort(T0);for(let x=0;x<8;x++)x<p&&g[x][1]?(r[x][0]=g[x][0],r[x][1]=g[x][1]):(r[x][0]=Number.MAX_SAFE_INTEGER,r[x][1]=0);r.sort(E0);const y=h.morphAttributes.position,m=h.morphAttributes.normal;let f=0;for(let x=0;x<8;x++){const M=r[x],R=M[0],A=M[1];R!==Number.MAX_SAFE_INTEGER&&A?(y&&h.getAttribute("morphTarget"+x)!==y[R]&&h.setAttribute("morphTarget"+x,y[R]),m&&h.getAttribute("morphNormal"+x)!==m[R]&&h.setAttribute("morphNormal"+x,m[R]),i[x]=A,f+=A):(y&&h.hasAttribute("morphTarget"+x)===!0&&h.deleteAttribute("morphTarget"+x),m&&h.hasAttribute("morphNormal"+x)===!0&&h.deleteAttribute("morphNormal"+x),i[x]=0)}const _=h.morphTargetsRelative?1:1-f;d.getUniforms().setValue(o,"morphTargetBaseInfluence",_),d.getUniforms().setValue(o,"morphTargetInfluences",i)}}return{update:c}}function C0(o,t,e,n){let i=new WeakMap;function s(c){const l=n.render.frame,h=c.geometry,d=t.get(c,h);if(i.get(d)!==l&&(t.update(d),i.set(d,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",r)===!1&&c.addEventListener("dispose",r),i.get(c)!==l&&(e.update(c.instanceMatrix,o.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,o.ARRAY_BUFFER),i.set(c,l))),c.isSkinnedMesh){const u=c.skeleton;i.get(u)!==l&&(u.update(),i.set(u,l))}return d}function a(){i=new WeakMap}function r(c){const l=c.target;l.removeEventListener("dispose",r),e.remove(l.instanceMatrix),l.instanceColor!==null&&e.remove(l.instanceColor)}return{update:s,dispose:a}}class _h extends Ve{constructor(t,e,n,i,s,a,r,c,l,h){if(h=h!==void 0?h:pi,h!==pi&&h!==ls)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===pi&&(n=Gn),n===void 0&&h===ls&&(n=ui),super(null,i,s,a,r,c,h,n,l),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=r!==void 0?r:ze,this.minFilter=c!==void 0?c:ze,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}const Mh=new Ve,Sh=new _h(1,1);Sh.compareFunction=ch;const bh=new uh,Eh=new du,Th=new yh,gl=[],wl=[],yl=new Float32Array(16),xl=new Float32Array(9),vl=new Float32Array(4);function us(o,t,e){const n=o[0];if(n<=0||n>0)return o;const i=t*e;let s=gl[i];if(s===void 0&&(s=new Float32Array(i),gl[i]=s),t!==0){n.toArray(s,0);for(let a=1,r=0;a!==t;++a)r+=e,o[a].toArray(s,r)}return s}function Ae(o,t){if(o.length!==t.length)return!1;for(let e=0,n=o.length;e<n;e++)if(o[e]!==t[e])return!1;return!0}function Ce(o,t){for(let e=0,n=t.length;e<n;e++)o[e]=t[e]}function sa(o,t){let e=wl[t];e===void 0&&(e=new Int32Array(t),wl[t]=e);for(let n=0;n!==t;++n)e[n]=o.allocateTextureUnit();return e}function R0(o,t){const e=this.cache;e[0]!==t&&(o.uniform1f(this.addr,t),e[0]=t)}function L0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ae(e,t))return;o.uniform2fv(this.addr,t),Ce(e,t)}}function P0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(o.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ae(e,t))return;o.uniform3fv(this.addr,t),Ce(e,t)}}function I0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ae(e,t))return;o.uniform4fv(this.addr,t),Ce(e,t)}}function D0(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(Ae(e,t))return;o.uniformMatrix2fv(this.addr,!1,t),Ce(e,t)}else{if(Ae(e,n))return;vl.set(n),o.uniformMatrix2fv(this.addr,!1,vl),Ce(e,n)}}function U0(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(Ae(e,t))return;o.uniformMatrix3fv(this.addr,!1,t),Ce(e,t)}else{if(Ae(e,n))return;xl.set(n),o.uniformMatrix3fv(this.addr,!1,xl),Ce(e,n)}}function N0(o,t){const e=this.cache,n=t.elements;if(n===void 0){if(Ae(e,t))return;o.uniformMatrix4fv(this.addr,!1,t),Ce(e,t)}else{if(Ae(e,n))return;yl.set(n),o.uniformMatrix4fv(this.addr,!1,yl),Ce(e,n)}}function B0(o,t){const e=this.cache;e[0]!==t&&(o.uniform1i(this.addr,t),e[0]=t)}function F0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ae(e,t))return;o.uniform2iv(this.addr,t),Ce(e,t)}}function O0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ae(e,t))return;o.uniform3iv(this.addr,t),Ce(e,t)}}function z0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ae(e,t))return;o.uniform4iv(this.addr,t),Ce(e,t)}}function k0(o,t){const e=this.cache;e[0]!==t&&(o.uniform1ui(this.addr,t),e[0]=t)}function G0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(o.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ae(e,t))return;o.uniform2uiv(this.addr,t),Ce(e,t)}}function H0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(o.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ae(e,t))return;o.uniform3uiv(this.addr,t),Ce(e,t)}}function V0(o,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(o.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ae(e,t))return;o.uniform4uiv(this.addr,t),Ce(e,t)}}function W0(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i);const s=this.type===o.SAMPLER_2D_SHADOW?Sh:Mh;e.setTexture2D(t||s,i)}function X0(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||Eh,i)}function q0(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||Th,i)}function Y0(o,t,e){const n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(o.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||bh,i)}function $0(o){switch(o){case 5126:return R0;case 35664:return L0;case 35665:return P0;case 35666:return I0;case 35674:return D0;case 35675:return U0;case 35676:return N0;case 5124:case 35670:return B0;case 35667:case 35671:return F0;case 35668:case 35672:return O0;case 35669:case 35673:return z0;case 5125:return k0;case 36294:return G0;case 36295:return H0;case 36296:return V0;case 35678:case 36198:case 36298:case 36306:case 35682:return W0;case 35679:case 36299:case 36307:return X0;case 35680:case 36300:case 36308:case 36293:return q0;case 36289:case 36303:case 36311:case 36292:return Y0}}function Z0(o,t){o.uniform1fv(this.addr,t)}function j0(o,t){const e=us(t,this.size,2);o.uniform2fv(this.addr,e)}function K0(o,t){const e=us(t,this.size,3);o.uniform3fv(this.addr,e)}function J0(o,t){const e=us(t,this.size,4);o.uniform4fv(this.addr,e)}function Q0(o,t){const e=us(t,this.size,4);o.uniformMatrix2fv(this.addr,!1,e)}function tm(o,t){const e=us(t,this.size,9);o.uniformMatrix3fv(this.addr,!1,e)}function em(o,t){const e=us(t,this.size,16);o.uniformMatrix4fv(this.addr,!1,e)}function nm(o,t){o.uniform1iv(this.addr,t)}function im(o,t){o.uniform2iv(this.addr,t)}function sm(o,t){o.uniform3iv(this.addr,t)}function om(o,t){o.uniform4iv(this.addr,t)}function am(o,t){o.uniform1uiv(this.addr,t)}function rm(o,t){o.uniform2uiv(this.addr,t)}function cm(o,t){o.uniform3uiv(this.addr,t)}function lm(o,t){o.uniform4uiv(this.addr,t)}function hm(o,t,e){const n=this.cache,i=t.length,s=sa(e,i);Ae(n,s)||(o.uniform1iv(this.addr,s),Ce(n,s));for(let a=0;a!==i;++a)e.setTexture2D(t[a]||Mh,s[a])}function dm(o,t,e){const n=this.cache,i=t.length,s=sa(e,i);Ae(n,s)||(o.uniform1iv(this.addr,s),Ce(n,s));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||Eh,s[a])}function um(o,t,e){const n=this.cache,i=t.length,s=sa(e,i);Ae(n,s)||(o.uniform1iv(this.addr,s),Ce(n,s));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||Th,s[a])}function pm(o,t,e){const n=this.cache,i=t.length,s=sa(e,i);Ae(n,s)||(o.uniform1iv(this.addr,s),Ce(n,s));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||bh,s[a])}function fm(o){switch(o){case 5126:return Z0;case 35664:return j0;case 35665:return K0;case 35666:return J0;case 35674:return Q0;case 35675:return tm;case 35676:return em;case 5124:case 35670:return nm;case 35667:case 35671:return im;case 35668:case 35672:return sm;case 35669:case 35673:return om;case 5125:return am;case 36294:return rm;case 36295:return cm;case 36296:return lm;case 35678:case 36198:case 36298:case 36306:case 35682:return hm;case 35679:case 36299:case 36307:return dm;case 35680:case 36300:case 36308:case 36293:return um;case 36289:case 36303:case 36311:case 36292:return pm}}class mm{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=$0(e.type)}}class gm{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=fm(e.type)}}class wm{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const i=this.seq;for(let s=0,a=i.length;s!==a;++s){const r=i[s];r.setValue(t,e[r.id],n)}}}const nr=/(\w+)(\])?(\[|\.)?/g;function _l(o,t){o.seq.push(t),o.map[t.id]=t}function ym(o,t,e){const n=o.name,i=n.length;for(nr.lastIndex=0;;){const s=nr.exec(n),a=nr.lastIndex;let r=s[1];const c=s[2]==="]",l=s[3];if(c&&(r=r|0),l===void 0||l==="["&&a+2===i){_l(e,l===void 0?new mm(r,o,t):new gm(r,o,t));break}else{let d=e.map[r];d===void 0&&(d=new wm(r),_l(e,d)),e=d}}}class Ho{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const s=t.getActiveUniform(e,i),a=t.getUniformLocation(e,s.name);ym(s,a,this)}}setValue(t,e,n,i){const s=this.map[e];s!==void 0&&s.setValue(t,n,i)}setOptional(t,e,n){const i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let s=0,a=e.length;s!==a;++s){const r=e[s],c=n[r.id];c.needsUpdate!==!1&&r.setValue(t,c.value,i)}}static seqWithValue(t,e){const n=[];for(let i=0,s=t.length;i!==s;++i){const a=t[i];a.id in e&&n.push(a)}return n}}function Ml(o,t,e){const n=o.createShader(t);return o.shaderSource(n,e),o.compileShader(n),n}const xm=37297;let vm=0;function _m(o,t){const e=o.split(`
`),n=[],i=Math.max(t-6,0),s=Math.min(t+6,e.length);for(let a=i;a<s;a++){const r=a+1;n.push(`${r===t?">":" "} ${r}: ${e[a]}`)}return n.join(`
`)}function Mm(o){const t=re.getPrimaries(re.workingColorSpace),e=re.getPrimaries(o);let n;switch(t===e?n="":t===Yo&&e===qo?n="LinearDisplayP3ToLinearSRGB":t===qo&&e===Yo&&(n="LinearSRGBToLinearDisplayP3"),o){case Un:case ea:return[n,"LinearTransferOETF"];case Pe:case Rr:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",o),[n,"LinearTransferOETF"]}}function Sl(o,t,e){const n=o.getShaderParameter(t,o.COMPILE_STATUS),i=o.getShaderInfoLog(t).trim();if(n&&i==="")return"";const s=/ERROR: 0:(\d+)/.exec(i);if(s){const a=parseInt(s[1]);return e.toUpperCase()+`

`+i+`

`+_m(o.getShaderSource(t),a)}else return i}function Sm(o,t){const e=Mm(t);return`vec4 ${o}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function bm(o,t){let e;switch(t){case Kl:e="Linear";break;case Nd:e="Reinhard";break;case Bd:e="OptimizedCineon";break;case Fd:e="ACESFilmic";break;case zd:e="AgX";break;case Od:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+o+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}function Em(o){return[o.extensionDerivatives||o.envMapCubeUVHeight||o.bumpMap||o.normalMapTangentSpace||o.clearcoatNormalMap||o.flatShading||o.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(o.extensionFragDepth||o.logarithmicDepthBuffer)&&o.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",o.extensionDrawBuffers&&o.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(o.extensionShaderTextureLOD||o.envMap||o.transmission)&&o.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(is).join(`
`)}function Tm(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(is).join(`
`)}function Am(o){const t=[];for(const e in o){const n=o[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function Cm(o,t){const e={},n=o.getProgramParameter(t,o.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const s=o.getActiveAttrib(t,i),a=s.name;let r=1;s.type===o.FLOAT_MAT2&&(r=2),s.type===o.FLOAT_MAT3&&(r=3),s.type===o.FLOAT_MAT4&&(r=4),e[a]={type:s.type,location:o.getAttribLocation(t,a),locationSize:r}}return e}function is(o){return o!==""}function bl(o,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function El(o,t){return o.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const Rm=/^[ \t]*#include +<([\w\d./]+)>/gm;function vr(o){return o.replace(Rm,Pm)}const Lm=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function Pm(o,t){let e=Kt[t];if(e===void 0){const n=Lm.get(t);if(n!==void 0)e=Kt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return vr(e)}const Im=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Tl(o){return o.replace(Im,Dm)}function Dm(o,t,e,n){let i="";for(let s=parseInt(t);s<parseInt(e);s++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return i}function Al(o){let t="precision "+o.precision+` float;
precision `+o.precision+" int;";return o.precision==="highp"?t+=`
#define HIGH_PRECISION`:o.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function Um(o){let t="SHADOWMAP_TYPE_BASIC";return o.shadowMapType===Tr?t="SHADOWMAP_TYPE_PCF":o.shadowMapType===jl?t="SHADOWMAP_TYPE_PCF_SOFT":o.shadowMapType===Rn&&(t="SHADOWMAP_TYPE_VSM"),t}function Nm(o){let t="ENVMAP_TYPE_CUBE";if(o.envMap)switch(o.envMapMode){case rs:case cs:t="ENVMAP_TYPE_CUBE";break;case ta:t="ENVMAP_TYPE_CUBE_UV";break}return t}function Bm(o){let t="ENVMAP_MODE_REFLECTION";if(o.envMap)switch(o.envMapMode){case cs:t="ENVMAP_MODE_REFRACTION";break}return t}function Fm(o){let t="ENVMAP_BLENDING_NONE";if(o.envMap)switch(o.combine){case Ar:t="ENVMAP_BLENDING_MULTIPLY";break;case Dd:t="ENVMAP_BLENDING_MIX";break;case Ud:t="ENVMAP_BLENDING_ADD";break}return t}function Om(o){const t=o.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function zm(o,t,e,n){const i=o.getContext(),s=e.defines;let a=e.vertexShader,r=e.fragmentShader;const c=Um(e),l=Nm(e),h=Bm(e),d=Fm(e),u=Om(e),p=e.isWebGL2?"":Em(e),g=Tm(e),y=Am(s),m=i.createProgram();let f,_,x=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(f=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(is).join(`
`),f.length>0&&(f+=`
`),_=[p,"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y].filter(is).join(`
`),_.length>0&&(_+=`
`)):(f=[Al(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors&&e.isWebGL2?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0&&e.isWebGL2?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(is).join(`
`),_=[p,Al(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,y,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+l:"",e.envMap?"#define "+h:"",e.envMap?"#define "+d:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+c:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.useLegacyLights?"#define LEGACY_LIGHTS":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.logarithmicDepthBuffer&&e.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Xn?"#define TONE_MAPPING":"",e.toneMapping!==Xn?Kt.tonemapping_pars_fragment:"",e.toneMapping!==Xn?bm("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Kt.colorspace_pars_fragment,Sm("linearToOutputTexel",e.outputColorSpace),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(is).join(`
`)),a=vr(a),a=bl(a,e),a=El(a,e),r=vr(r),r=bl(r,e),r=El(r,e),a=Tl(a),r=Tl(r),e.isWebGL2&&e.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,f=[g,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,_=["precision mediump sampler2DArray;","#define varying in",e.glslVersion===Xc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Xc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+_);const M=x+f+a,R=x+_+r,A=Ml(i,i.VERTEX_SHADER,M),E=Ml(i,i.FRAGMENT_SHADER,R);i.attachShader(m,A),i.attachShader(m,E),e.index0AttributeName!==void 0?i.bindAttribLocation(m,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(m,0,"position"),i.linkProgram(m);function I(O){if(o.debug.checkShaderErrors){const j=i.getProgramInfoLog(m).trim(),D=i.getShaderInfoLog(A).trim(),F=i.getShaderInfoLog(E).trim();let z=!0,Z=!0;if(i.getProgramParameter(m,i.LINK_STATUS)===!1)if(z=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(i,m,A,E);else{const Y=Sl(i,A,"vertex"),q=Sl(i,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(m,i.VALIDATE_STATUS)+`

Program Info Log: `+j+`
`+Y+`
`+q)}else j!==""?console.warn("THREE.WebGLProgram: Program Info Log:",j):(D===""||F==="")&&(Z=!1);Z&&(O.diagnostics={runnable:z,programLog:j,vertexShader:{log:D,prefix:f},fragmentShader:{log:F,prefix:_}})}i.deleteShader(A),i.deleteShader(E),v=new Ho(i,m),S=Cm(i,m)}let v;this.getUniforms=function(){return v===void 0&&I(this),v};let S;this.getAttributes=function(){return S===void 0&&I(this),S};let P=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return P===!1&&(P=i.getProgramParameter(m,xm)),P},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(m),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=vm++,this.cacheKey=t,this.usedTimes=1,this.program=m,this.vertexShader=A,this.fragmentShader=E,this}let km=0;class Gm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),s=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new Hm(t),e.set(t,n)),n}}class Hm{constructor(t){this.id=km++,this.code=t,this.usedTimes=0}}function Vm(o,t,e,n,i,s,a){const r=new Lr,c=new Gm,l=[],h=i.isWebGL2,d=i.logarithmicDepthBuffer,u=i.vertexTextures;let p=i.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function y(v){return v===0?"uv":`uv${v}`}function m(v,S,P,O,j){const D=O.fog,F=j.geometry,z=v.isMeshStandardMaterial?O.environment:null,Z=(v.isMeshStandardMaterial?e:t).get(v.envMap||z),Y=Z&&Z.mapping===ta?Z.image.height:null,q=g[v.type];v.precision!==null&&(p=i.getMaxPrecision(v.precision),p!==v.precision&&console.warn("THREE.WebGLProgram.getParameters:",v.precision,"not supported, using",p,"instead."));const J=F.morphAttributes.position||F.morphAttributes.normal||F.morphAttributes.color,nt=J!==void 0?J.length:0;let ct=0;F.morphAttributes.position!==void 0&&(ct=1),F.morphAttributes.normal!==void 0&&(ct=2),F.morphAttributes.color!==void 0&&(ct=3);let X,et,pt,bt;if(q){const Se=gn[q];X=Se.vertexShader,et=Se.fragmentShader}else X=v.vertexShader,et=v.fragmentShader,c.update(v),pt=c.getVertexShaderID(v),bt=c.getFragmentShaderID(v);const xt=o.getRenderTarget(),It=j.isInstancedMesh===!0,Gt=j.isBatchedMesh===!0,At=!!v.map,Et=!!v.matcap,N=!!Z,ht=!!v.aoMap,tt=!!v.lightMap,lt=!!v.bumpMap,Q=!!v.normalMap,Lt=!!v.displacementMap,ft=!!v.emissiveMap,T=!!v.metalnessMap,b=!!v.roughnessMap,k=v.anisotropy>0,it=v.clearcoat>0,at=v.iridescence>0,st=v.sheen>0,St=v.transmission>0,wt=k&&!!v.anisotropyMap,Mt=it&&!!v.clearcoatMap,Pt=it&&!!v.clearcoatNormalMap,Ut=it&&!!v.clearcoatRoughnessMap,rt=at&&!!v.iridescenceMap,Jt=at&&!!v.iridescenceThicknessMap,qt=st&&!!v.sheenColorMap,Ht=st&&!!v.sheenRoughnessMap,Dt=!!v.specularMap,Tt=!!v.specularColorMap,Yt=!!v.specularIntensityMap,ee=St&&!!v.transmissionMap,pe=St&&!!v.thicknessMap,jt=!!v.gradientMap,ut=!!v.alphaMap,B=v.alphaTest>0,mt=!!v.alphaHash,yt=!!v.extensions,Ft=!!F.attributes.uv1,Bt=!!F.attributes.uv2,ne=!!F.attributes.uv3;let ie=Xn;return v.toneMapped&&(xt===null||xt.isXRRenderTarget===!0)&&(ie=o.toneMapping),{isWebGL2:h,shaderID:q,shaderType:v.type,shaderName:v.name,vertexShader:X,fragmentShader:et,defines:v.defines,customVertexShaderID:pt,customFragmentShaderID:bt,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:p,batching:Gt,instancing:It,instancingColor:It&&j.instanceColor!==null,supportsVertexTextures:u,outputColorSpace:xt===null?o.outputColorSpace:xt.isXRRenderTarget===!0?xt.texture.colorSpace:Un,map:At,matcap:Et,envMap:N,envMapMode:N&&Z.mapping,envMapCubeUVHeight:Y,aoMap:ht,lightMap:tt,bumpMap:lt,normalMap:Q,displacementMap:u&&Lt,emissiveMap:ft,normalMapObjectSpace:Q&&v.normalMapType===Kd,normalMapTangentSpace:Q&&v.normalMapType===rh,metalnessMap:T,roughnessMap:b,anisotropy:k,anisotropyMap:wt,clearcoat:it,clearcoatMap:Mt,clearcoatNormalMap:Pt,clearcoatRoughnessMap:Ut,iridescence:at,iridescenceMap:rt,iridescenceThicknessMap:Jt,sheen:st,sheenColorMap:qt,sheenRoughnessMap:Ht,specularMap:Dt,specularColorMap:Tt,specularIntensityMap:Yt,transmission:St,transmissionMap:ee,thicknessMap:pe,gradientMap:jt,opaque:v.transparent===!1&&v.blending===os,alphaMap:ut,alphaTest:B,alphaHash:mt,combine:v.combine,mapUv:At&&y(v.map.channel),aoMapUv:ht&&y(v.aoMap.channel),lightMapUv:tt&&y(v.lightMap.channel),bumpMapUv:lt&&y(v.bumpMap.channel),normalMapUv:Q&&y(v.normalMap.channel),displacementMapUv:Lt&&y(v.displacementMap.channel),emissiveMapUv:ft&&y(v.emissiveMap.channel),metalnessMapUv:T&&y(v.metalnessMap.channel),roughnessMapUv:b&&y(v.roughnessMap.channel),anisotropyMapUv:wt&&y(v.anisotropyMap.channel),clearcoatMapUv:Mt&&y(v.clearcoatMap.channel),clearcoatNormalMapUv:Pt&&y(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ut&&y(v.clearcoatRoughnessMap.channel),iridescenceMapUv:rt&&y(v.iridescenceMap.channel),iridescenceThicknessMapUv:Jt&&y(v.iridescenceThicknessMap.channel),sheenColorMapUv:qt&&y(v.sheenColorMap.channel),sheenRoughnessMapUv:Ht&&y(v.sheenRoughnessMap.channel),specularMapUv:Dt&&y(v.specularMap.channel),specularColorMapUv:Tt&&y(v.specularColorMap.channel),specularIntensityMapUv:Yt&&y(v.specularIntensityMap.channel),transmissionMapUv:ee&&y(v.transmissionMap.channel),thicknessMapUv:pe&&y(v.thicknessMap.channel),alphaMapUv:ut&&y(v.alphaMap.channel),vertexTangents:!!F.attributes.tangent&&(Q||k),vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!F.attributes.color&&F.attributes.color.itemSize===4,vertexUv1s:Ft,vertexUv2s:Bt,vertexUv3s:ne,pointsUvs:j.isPoints===!0&&!!F.attributes.uv&&(At||ut),fog:!!D,useFog:v.fog===!0,fogExp2:D&&D.isFogExp2,flatShading:v.flatShading===!0,sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:d,skinning:j.isSkinnedMesh===!0,morphTargets:F.morphAttributes.position!==void 0,morphNormals:F.morphAttributes.normal!==void 0,morphColors:F.morphAttributes.color!==void 0,morphTargetsCount:nt,morphTextureStride:ct,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:v.dithering,shadowMapEnabled:o.shadowMap.enabled&&P.length>0,shadowMapType:o.shadowMap.type,toneMapping:ie,useLegacyLights:o._useLegacyLights,decodeVideoTexture:At&&v.map.isVideoTexture===!0&&re.getTransfer(v.map.colorSpace)===ue,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===me,flipSided:v.side===He,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionDerivatives:yt&&v.extensions.derivatives===!0,extensionFragDepth:yt&&v.extensions.fragDepth===!0,extensionDrawBuffers:yt&&v.extensions.drawBuffers===!0,extensionShaderTextureLOD:yt&&v.extensions.shaderTextureLOD===!0,extensionClipCullDistance:yt&&v.extensions.clipCullDistance&&n.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:h||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:h||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:h||n.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()}}function f(v){const S=[];if(v.shaderID?S.push(v.shaderID):(S.push(v.customVertexShaderID),S.push(v.customFragmentShaderID)),v.defines!==void 0)for(const P in v.defines)S.push(P),S.push(v.defines[P]);return v.isRawShaderMaterial===!1&&(_(S,v),x(S,v),S.push(o.outputColorSpace)),S.push(v.customProgramCacheKey),S.join()}function _(v,S){v.push(S.precision),v.push(S.outputColorSpace),v.push(S.envMapMode),v.push(S.envMapCubeUVHeight),v.push(S.mapUv),v.push(S.alphaMapUv),v.push(S.lightMapUv),v.push(S.aoMapUv),v.push(S.bumpMapUv),v.push(S.normalMapUv),v.push(S.displacementMapUv),v.push(S.emissiveMapUv),v.push(S.metalnessMapUv),v.push(S.roughnessMapUv),v.push(S.anisotropyMapUv),v.push(S.clearcoatMapUv),v.push(S.clearcoatNormalMapUv),v.push(S.clearcoatRoughnessMapUv),v.push(S.iridescenceMapUv),v.push(S.iridescenceThicknessMapUv),v.push(S.sheenColorMapUv),v.push(S.sheenRoughnessMapUv),v.push(S.specularMapUv),v.push(S.specularColorMapUv),v.push(S.specularIntensityMapUv),v.push(S.transmissionMapUv),v.push(S.thicknessMapUv),v.push(S.combine),v.push(S.fogExp2),v.push(S.sizeAttenuation),v.push(S.morphTargetsCount),v.push(S.morphAttributeCount),v.push(S.numDirLights),v.push(S.numPointLights),v.push(S.numSpotLights),v.push(S.numSpotLightMaps),v.push(S.numHemiLights),v.push(S.numRectAreaLights),v.push(S.numDirLightShadows),v.push(S.numPointLightShadows),v.push(S.numSpotLightShadows),v.push(S.numSpotLightShadowsWithMaps),v.push(S.numLightProbes),v.push(S.shadowMapType),v.push(S.toneMapping),v.push(S.numClippingPlanes),v.push(S.numClipIntersection),v.push(S.depthPacking)}function x(v,S){r.disableAll(),S.isWebGL2&&r.enable(0),S.supportsVertexTextures&&r.enable(1),S.instancing&&r.enable(2),S.instancingColor&&r.enable(3),S.matcap&&r.enable(4),S.envMap&&r.enable(5),S.normalMapObjectSpace&&r.enable(6),S.normalMapTangentSpace&&r.enable(7),S.clearcoat&&r.enable(8),S.iridescence&&r.enable(9),S.alphaTest&&r.enable(10),S.vertexColors&&r.enable(11),S.vertexAlphas&&r.enable(12),S.vertexUv1s&&r.enable(13),S.vertexUv2s&&r.enable(14),S.vertexUv3s&&r.enable(15),S.vertexTangents&&r.enable(16),S.anisotropy&&r.enable(17),S.alphaHash&&r.enable(18),S.batching&&r.enable(19),v.push(r.mask),r.disableAll(),S.fog&&r.enable(0),S.useFog&&r.enable(1),S.flatShading&&r.enable(2),S.logarithmicDepthBuffer&&r.enable(3),S.skinning&&r.enable(4),S.morphTargets&&r.enable(5),S.morphNormals&&r.enable(6),S.morphColors&&r.enable(7),S.premultipliedAlpha&&r.enable(8),S.shadowMapEnabled&&r.enable(9),S.useLegacyLights&&r.enable(10),S.doubleSided&&r.enable(11),S.flipSided&&r.enable(12),S.useDepthPacking&&r.enable(13),S.dithering&&r.enable(14),S.transmission&&r.enable(15),S.sheen&&r.enable(16),S.opaque&&r.enable(17),S.pointsUvs&&r.enable(18),S.decodeVideoTexture&&r.enable(19),v.push(r.mask)}function M(v){const S=g[v.type];let P;if(S){const O=gn[S];P=bu.clone(O.uniforms)}else P=v.uniforms;return P}function R(v,S){let P;for(let O=0,j=l.length;O<j;O++){const D=l[O];if(D.cacheKey===S){P=D,++P.usedTimes;break}}return P===void 0&&(P=new zm(o,S,v,s),l.push(P)),P}function A(v){if(--v.usedTimes===0){const S=l.indexOf(v);l[S]=l[l.length-1],l.pop(),v.destroy()}}function E(v){c.remove(v)}function I(){c.dispose()}return{getParameters:m,getProgramCacheKey:f,getUniforms:M,acquireProgram:R,releaseProgram:A,releaseShaderCache:E,programs:l,dispose:I}}function Wm(){let o=new WeakMap;function t(s){let a=o.get(s);return a===void 0&&(a={},o.set(s,a)),a}function e(s){o.delete(s)}function n(s,a,r){o.get(s)[a]=r}function i(){o=new WeakMap}return{get:t,remove:e,update:n,dispose:i}}function Xm(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.material.id!==t.material.id?o.material.id-t.material.id:o.z!==t.z?o.z-t.z:o.id-t.id}function Cl(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.z!==t.z?t.z-o.z:o.id-t.id}function Rl(){const o=[];let t=0;const e=[],n=[],i=[];function s(){t=0,e.length=0,n.length=0,i.length=0}function a(d,u,p,g,y,m){let f=o[t];return f===void 0?(f={id:d.id,object:d,geometry:u,material:p,groupOrder:g,renderOrder:d.renderOrder,z:y,group:m},o[t]=f):(f.id=d.id,f.object=d,f.geometry=u,f.material=p,f.groupOrder=g,f.renderOrder=d.renderOrder,f.z=y,f.group=m),t++,f}function r(d,u,p,g,y,m){const f=a(d,u,p,g,y,m);p.transmission>0?n.push(f):p.transparent===!0?i.push(f):e.push(f)}function c(d,u,p,g,y,m){const f=a(d,u,p,g,y,m);p.transmission>0?n.unshift(f):p.transparent===!0?i.unshift(f):e.unshift(f)}function l(d,u){e.length>1&&e.sort(d||Xm),n.length>1&&n.sort(u||Cl),i.length>1&&i.sort(u||Cl)}function h(){for(let d=t,u=o.length;d<u;d++){const p=o[d];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:e,transmissive:n,transparent:i,init:s,push:r,unshift:c,finish:h,sort:l}}function qm(){let o=new WeakMap;function t(n,i){const s=o.get(n);let a;return s===void 0?(a=new Rl,o.set(n,[a])):i>=s.length?(a=new Rl,s.push(a)):a=s[i],a}function e(){o=new WeakMap}return{get:t,dispose:e}}function Ym(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new L,color:new Vt};break;case"SpotLight":e={position:new L,direction:new L,color:new Vt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new L,color:new Vt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new L,skyColor:new Vt,groundColor:new Vt};break;case"RectAreaLight":e={color:new Vt,position:new L,halfWidth:new L,halfHeight:new L};break}return o[t.id]=e,e}}}function $m(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt};break;case"SpotLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt};break;case"PointLight":e={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new dt,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[t.id]=e,e}}}let Zm=0;function jm(o,t){return(t.castShadow?2:0)-(o.castShadow?2:0)+(t.map?1:0)-(o.map?1:0)}function Km(o,t){const e=new Ym,n=$m(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)i.probe.push(new L);const s=new L,a=new we,r=new we;function c(h,d){let u=0,p=0,g=0;for(let O=0;O<9;O++)i.probe[O].set(0,0,0);let y=0,m=0,f=0,_=0,x=0,M=0,R=0,A=0,E=0,I=0,v=0;h.sort(jm);const S=d===!0?Math.PI:1;for(let O=0,j=h.length;O<j;O++){const D=h[O],F=D.color,z=D.intensity,Z=D.distance,Y=D.shadow&&D.shadow.map?D.shadow.map.texture:null;if(D.isAmbientLight)u+=F.r*z*S,p+=F.g*z*S,g+=F.b*z*S;else if(D.isLightProbe){for(let q=0;q<9;q++)i.probe[q].addScaledVector(D.sh.coefficients[q],z);v++}else if(D.isDirectionalLight){const q=e.get(D);if(q.color.copy(D.color).multiplyScalar(D.intensity*S),D.castShadow){const J=D.shadow,nt=n.get(D);nt.shadowBias=J.bias,nt.shadowNormalBias=J.normalBias,nt.shadowRadius=J.radius,nt.shadowMapSize=J.mapSize,i.directionalShadow[y]=nt,i.directionalShadowMap[y]=Y,i.directionalShadowMatrix[y]=D.shadow.matrix,M++}i.directional[y]=q,y++}else if(D.isSpotLight){const q=e.get(D);q.position.setFromMatrixPosition(D.matrixWorld),q.color.copy(F).multiplyScalar(z*S),q.distance=Z,q.coneCos=Math.cos(D.angle),q.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),q.decay=D.decay,i.spot[f]=q;const J=D.shadow;if(D.map&&(i.spotLightMap[E]=D.map,E++,J.updateMatrices(D),D.castShadow&&I++),i.spotLightMatrix[f]=J.matrix,D.castShadow){const nt=n.get(D);nt.shadowBias=J.bias,nt.shadowNormalBias=J.normalBias,nt.shadowRadius=J.radius,nt.shadowMapSize=J.mapSize,i.spotShadow[f]=nt,i.spotShadowMap[f]=Y,A++}f++}else if(D.isRectAreaLight){const q=e.get(D);q.color.copy(F).multiplyScalar(z),q.halfWidth.set(D.width*.5,0,0),q.halfHeight.set(0,D.height*.5,0),i.rectArea[_]=q,_++}else if(D.isPointLight){const q=e.get(D);if(q.color.copy(D.color).multiplyScalar(D.intensity*S),q.distance=D.distance,q.decay=D.decay,D.castShadow){const J=D.shadow,nt=n.get(D);nt.shadowBias=J.bias,nt.shadowNormalBias=J.normalBias,nt.shadowRadius=J.radius,nt.shadowMapSize=J.mapSize,nt.shadowCameraNear=J.camera.near,nt.shadowCameraFar=J.camera.far,i.pointShadow[m]=nt,i.pointShadowMap[m]=Y,i.pointShadowMatrix[m]=D.shadow.matrix,R++}i.point[m]=q,m++}else if(D.isHemisphereLight){const q=e.get(D);q.skyColor.copy(D.color).multiplyScalar(z*S),q.groundColor.copy(D.groundColor).multiplyScalar(z*S),i.hemi[x]=q,x++}}_>0&&(t.isWebGL2?o.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=gt.LTC_FLOAT_1,i.rectAreaLTC2=gt.LTC_FLOAT_2):(i.rectAreaLTC1=gt.LTC_HALF_1,i.rectAreaLTC2=gt.LTC_HALF_2):o.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=gt.LTC_FLOAT_1,i.rectAreaLTC2=gt.LTC_FLOAT_2):o.has("OES_texture_half_float_linear")===!0?(i.rectAreaLTC1=gt.LTC_HALF_1,i.rectAreaLTC2=gt.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),i.ambient[0]=u,i.ambient[1]=p,i.ambient[2]=g;const P=i.hash;(P.directionalLength!==y||P.pointLength!==m||P.spotLength!==f||P.rectAreaLength!==_||P.hemiLength!==x||P.numDirectionalShadows!==M||P.numPointShadows!==R||P.numSpotShadows!==A||P.numSpotMaps!==E||P.numLightProbes!==v)&&(i.directional.length=y,i.spot.length=f,i.rectArea.length=_,i.point.length=m,i.hemi.length=x,i.directionalShadow.length=M,i.directionalShadowMap.length=M,i.pointShadow.length=R,i.pointShadowMap.length=R,i.spotShadow.length=A,i.spotShadowMap.length=A,i.directionalShadowMatrix.length=M,i.pointShadowMatrix.length=R,i.spotLightMatrix.length=A+E-I,i.spotLightMap.length=E,i.numSpotLightShadowsWithMaps=I,i.numLightProbes=v,P.directionalLength=y,P.pointLength=m,P.spotLength=f,P.rectAreaLength=_,P.hemiLength=x,P.numDirectionalShadows=M,P.numPointShadows=R,P.numSpotShadows=A,P.numSpotMaps=E,P.numLightProbes=v,i.version=Zm++)}function l(h,d){let u=0,p=0,g=0,y=0,m=0;const f=d.matrixWorldInverse;for(let _=0,x=h.length;_<x;_++){const M=h[_];if(M.isDirectionalLight){const R=i.directional[u];R.direction.setFromMatrixPosition(M.matrixWorld),s.setFromMatrixPosition(M.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(f),u++}else if(M.isSpotLight){const R=i.spot[g];R.position.setFromMatrixPosition(M.matrixWorld),R.position.applyMatrix4(f),R.direction.setFromMatrixPosition(M.matrixWorld),s.setFromMatrixPosition(M.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(f),g++}else if(M.isRectAreaLight){const R=i.rectArea[y];R.position.setFromMatrixPosition(M.matrixWorld),R.position.applyMatrix4(f),r.identity(),a.copy(M.matrixWorld),a.premultiply(f),r.extractRotation(a),R.halfWidth.set(M.width*.5,0,0),R.halfHeight.set(0,M.height*.5,0),R.halfWidth.applyMatrix4(r),R.halfHeight.applyMatrix4(r),y++}else if(M.isPointLight){const R=i.point[p];R.position.setFromMatrixPosition(M.matrixWorld),R.position.applyMatrix4(f),p++}else if(M.isHemisphereLight){const R=i.hemi[m];R.direction.setFromMatrixPosition(M.matrixWorld),R.direction.transformDirection(f),m++}}}return{setup:c,setupView:l,state:i}}function Ll(o,t){const e=new Km(o,t),n=[],i=[];function s(){n.length=0,i.length=0}function a(d){n.push(d)}function r(d){i.push(d)}function c(d){e.setup(n,d)}function l(d){e.setupView(n,d)}return{init:s,state:{lightsArray:n,shadowsArray:i,lights:e},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:r}}function Jm(o,t){let e=new WeakMap;function n(s,a=0){const r=e.get(s);let c;return r===void 0?(c=new Ll(o,t),e.set(s,[c])):a>=r.length?(c=new Ll(o,t),r.push(c)):c=r[a],c}function i(){e=new WeakMap}return{get:n,dispose:i}}class Qm extends $n{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Zd,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class tg extends $n{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const eg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,ng=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function ig(o,t,e){let n=new Pr;const i=new dt,s=new dt,a=new ge,r=new Qm({depthPacking:jd}),c=new tg,l={},h=e.maxTextureSize,d={[Yn]:He,[He]:Yn,[me]:me},u=new gi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new dt},radius:{value:4}},vertexShader:eg,fragmentShader:ng}),p=u.clone();p.defines.HORIZONTAL_PASS=1;const g=new Te;g.setAttribute("position",new sn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const y=new w(g,u),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Tr;let f=this.type;this.render=function(A,E,I){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||A.length===0)return;const v=o.getRenderTarget(),S=o.getActiveCubeFace(),P=o.getActiveMipmapLevel(),O=o.state;O.setBlending(Wn),O.buffers.color.setClear(1,1,1,1),O.buffers.depth.setTest(!0),O.setScissorTest(!1);const j=f!==Rn&&this.type===Rn,D=f===Rn&&this.type!==Rn;for(let F=0,z=A.length;F<z;F++){const Z=A[F],Y=Z.shadow;if(Y===void 0){console.warn("THREE.WebGLShadowMap:",Z,"has no shadow.");continue}if(Y.autoUpdate===!1&&Y.needsUpdate===!1)continue;i.copy(Y.mapSize);const q=Y.getFrameExtents();if(i.multiply(q),s.copy(Y.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(s.x=Math.floor(h/q.x),i.x=s.x*q.x,Y.mapSize.x=s.x),i.y>h&&(s.y=Math.floor(h/q.y),i.y=s.y*q.y,Y.mapSize.y=s.y)),Y.map===null||j===!0||D===!0){const nt=this.type!==Rn?{minFilter:ze,magFilter:ze}:{};Y.map!==null&&Y.map.dispose(),Y.map=new mi(i.x,i.y,nt),Y.map.texture.name=Z.name+".shadowMap",Y.camera.updateProjectionMatrix()}o.setRenderTarget(Y.map),o.clear();const J=Y.getViewportCount();for(let nt=0;nt<J;nt++){const ct=Y.getViewport(nt);a.set(s.x*ct.x,s.y*ct.y,s.x*ct.z,s.y*ct.w),O.viewport(a),Y.updateMatrices(Z,nt),n=Y.getFrustum(),M(E,I,Y.camera,Z,this.type)}Y.isPointLightShadow!==!0&&this.type===Rn&&_(Y,I),Y.needsUpdate=!1}f=this.type,m.needsUpdate=!1,o.setRenderTarget(v,S,P)};function _(A,E){const I=t.update(y);u.defines.VSM_SAMPLES!==A.blurSamples&&(u.defines.VSM_SAMPLES=A.blurSamples,p.defines.VSM_SAMPLES=A.blurSamples,u.needsUpdate=!0,p.needsUpdate=!0),A.mapPass===null&&(A.mapPass=new mi(i.x,i.y)),u.uniforms.shadow_pass.value=A.map.texture,u.uniforms.resolution.value=A.mapSize,u.uniforms.radius.value=A.radius,o.setRenderTarget(A.mapPass),o.clear(),o.renderBufferDirect(E,null,I,u,y,null),p.uniforms.shadow_pass.value=A.mapPass.texture,p.uniforms.resolution.value=A.mapSize,p.uniforms.radius.value=A.radius,o.setRenderTarget(A.map),o.clear(),o.renderBufferDirect(E,null,I,p,y,null)}function x(A,E,I,v){let S=null;const P=I.isPointLight===!0?A.customDistanceMaterial:A.customDepthMaterial;if(P!==void 0)S=P;else if(S=I.isPointLight===!0?c:r,o.localClippingEnabled&&E.clipShadows===!0&&Array.isArray(E.clippingPlanes)&&E.clippingPlanes.length!==0||E.displacementMap&&E.displacementScale!==0||E.alphaMap&&E.alphaTest>0||E.map&&E.alphaTest>0){const O=S.uuid,j=E.uuid;let D=l[O];D===void 0&&(D={},l[O]=D);let F=D[j];F===void 0&&(F=S.clone(),D[j]=F,E.addEventListener("dispose",R)),S=F}if(S.visible=E.visible,S.wireframe=E.wireframe,v===Rn?S.side=E.shadowSide!==null?E.shadowSide:E.side:S.side=E.shadowSide!==null?E.shadowSide:d[E.side],S.alphaMap=E.alphaMap,S.alphaTest=E.alphaTest,S.map=E.map,S.clipShadows=E.clipShadows,S.clippingPlanes=E.clippingPlanes,S.clipIntersection=E.clipIntersection,S.displacementMap=E.displacementMap,S.displacementScale=E.displacementScale,S.displacementBias=E.displacementBias,S.wireframeLinewidth=E.wireframeLinewidth,S.linewidth=E.linewidth,I.isPointLight===!0&&S.isMeshDistanceMaterial===!0){const O=o.properties.get(S);O.light=I}return S}function M(A,E,I,v,S){if(A.visible===!1)return;if(A.layers.test(E.layers)&&(A.isMesh||A.isLine||A.isPoints)&&(A.castShadow||A.receiveShadow&&S===Rn)&&(!A.frustumCulled||n.intersectsObject(A))){A.modelViewMatrix.multiplyMatrices(I.matrixWorldInverse,A.matrixWorld);const j=t.update(A),D=A.material;if(Array.isArray(D)){const F=j.groups;for(let z=0,Z=F.length;z<Z;z++){const Y=F[z],q=D[Y.materialIndex];if(q&&q.visible){const J=x(A,q,v,S);A.onBeforeShadow(o,A,E,I,j,J,Y),o.renderBufferDirect(I,null,j,J,A,Y),A.onAfterShadow(o,A,E,I,j,J,Y)}}}else if(D.visible){const F=x(A,D,v,S);A.onBeforeShadow(o,A,E,I,j,F,null),o.renderBufferDirect(I,null,j,F,A,null),A.onAfterShadow(o,A,E,I,j,F,null)}}const O=A.children;for(let j=0,D=O.length;j<D;j++)M(O[j],E,I,v,S)}function R(A){A.target.removeEventListener("dispose",R);for(const I in l){const v=l[I],S=A.target.uuid;S in v&&(v[S].dispose(),delete v[S])}}}function sg(o,t,e){const n=e.isWebGL2;function i(){let B=!1;const mt=new ge;let yt=null;const Ft=new ge(0,0,0,0);return{setMask:function(Bt){yt!==Bt&&!B&&(o.colorMask(Bt,Bt,Bt,Bt),yt=Bt)},setLocked:function(Bt){B=Bt},setClear:function(Bt,ne,ie,Me,Se){Se===!0&&(Bt*=Me,ne*=Me,ie*=Me),mt.set(Bt,ne,ie,Me),Ft.equals(mt)===!1&&(o.clearColor(Bt,ne,ie,Me),Ft.copy(mt))},reset:function(){B=!1,yt=null,Ft.set(-1,0,0,0)}}}function s(){let B=!1,mt=null,yt=null,Ft=null;return{setTest:function(Bt){Bt?Gt(o.DEPTH_TEST):At(o.DEPTH_TEST)},setMask:function(Bt){mt!==Bt&&!B&&(o.depthMask(Bt),mt=Bt)},setFunc:function(Bt){if(yt!==Bt){switch(Bt){case Td:o.depthFunc(o.NEVER);break;case Ad:o.depthFunc(o.ALWAYS);break;case Cd:o.depthFunc(o.LESS);break;case Wo:o.depthFunc(o.LEQUAL);break;case Rd:o.depthFunc(o.EQUAL);break;case Ld:o.depthFunc(o.GEQUAL);break;case Pd:o.depthFunc(o.GREATER);break;case Id:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}yt=Bt}},setLocked:function(Bt){B=Bt},setClear:function(Bt){Ft!==Bt&&(o.clearDepth(Bt),Ft=Bt)},reset:function(){B=!1,mt=null,yt=null,Ft=null}}}function a(){let B=!1,mt=null,yt=null,Ft=null,Bt=null,ne=null,ie=null,Me=null,Se=null;return{setTest:function(se){B||(se?Gt(o.STENCIL_TEST):At(o.STENCIL_TEST))},setMask:function(se){mt!==se&&!B&&(o.stencilMask(se),mt=se)},setFunc:function(se,Re,We){(yt!==se||Ft!==Re||Bt!==We)&&(o.stencilFunc(se,Re,We),yt=se,Ft=Re,Bt=We)},setOp:function(se,Re,We){(ne!==se||ie!==Re||Me!==We)&&(o.stencilOp(se,Re,We),ne=se,ie=Re,Me=We)},setLocked:function(se){B=se},setClear:function(se){Se!==se&&(o.clearStencil(se),Se=se)},reset:function(){B=!1,mt=null,yt=null,Ft=null,Bt=null,ne=null,ie=null,Me=null,Se=null}}}const r=new i,c=new s,l=new a,h=new WeakMap,d=new WeakMap;let u={},p={},g=new WeakMap,y=[],m=null,f=!1,_=null,x=null,M=null,R=null,A=null,E=null,I=null,v=new Vt(0,0,0),S=0,P=!1,O=null,j=null,D=null,F=null,z=null;const Z=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Y=!1,q=0;const J=o.getParameter(o.VERSION);J.indexOf("WebGL")!==-1?(q=parseFloat(/^WebGL (\d)/.exec(J)[1]),Y=q>=1):J.indexOf("OpenGL ES")!==-1&&(q=parseFloat(/^OpenGL ES (\d)/.exec(J)[1]),Y=q>=2);let nt=null,ct={};const X=o.getParameter(o.SCISSOR_BOX),et=o.getParameter(o.VIEWPORT),pt=new ge().fromArray(X),bt=new ge().fromArray(et);function xt(B,mt,yt,Ft){const Bt=new Uint8Array(4),ne=o.createTexture();o.bindTexture(B,ne),o.texParameteri(B,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(B,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let ie=0;ie<yt;ie++)n&&(B===o.TEXTURE_3D||B===o.TEXTURE_2D_ARRAY)?o.texImage3D(mt,0,o.RGBA,1,1,Ft,0,o.RGBA,o.UNSIGNED_BYTE,Bt):o.texImage2D(mt+ie,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,Bt);return ne}const It={};It[o.TEXTURE_2D]=xt(o.TEXTURE_2D,o.TEXTURE_2D,1),It[o.TEXTURE_CUBE_MAP]=xt(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),n&&(It[o.TEXTURE_2D_ARRAY]=xt(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),It[o.TEXTURE_3D]=xt(o.TEXTURE_3D,o.TEXTURE_3D,1,1)),r.setClear(0,0,0,1),c.setClear(1),l.setClear(0),Gt(o.DEPTH_TEST),c.setFunc(Wo),ft(!1),T(pc),Gt(o.CULL_FACE),Q(Wn);function Gt(B){u[B]!==!0&&(o.enable(B),u[B]=!0)}function At(B){u[B]!==!1&&(o.disable(B),u[B]=!1)}function Et(B,mt){return p[B]!==mt?(o.bindFramebuffer(B,mt),p[B]=mt,n&&(B===o.DRAW_FRAMEBUFFER&&(p[o.FRAMEBUFFER]=mt),B===o.FRAMEBUFFER&&(p[o.DRAW_FRAMEBUFFER]=mt)),!0):!1}function N(B,mt){let yt=y,Ft=!1;if(B)if(yt=g.get(mt),yt===void 0&&(yt=[],g.set(mt,yt)),B.isWebGLMultipleRenderTargets){const Bt=B.texture;if(yt.length!==Bt.length||yt[0]!==o.COLOR_ATTACHMENT0){for(let ne=0,ie=Bt.length;ne<ie;ne++)yt[ne]=o.COLOR_ATTACHMENT0+ne;yt.length=Bt.length,Ft=!0}}else yt[0]!==o.COLOR_ATTACHMENT0&&(yt[0]=o.COLOR_ATTACHMENT0,Ft=!0);else yt[0]!==o.BACK&&(yt[0]=o.BACK,Ft=!0);Ft&&(e.isWebGL2?o.drawBuffers(yt):t.get("WEBGL_draw_buffers").drawBuffersWEBGL(yt))}function ht(B){return m!==B?(o.useProgram(B),m=B,!0):!1}const tt={[hi]:o.FUNC_ADD,[dd]:o.FUNC_SUBTRACT,[ud]:o.FUNC_REVERSE_SUBTRACT};if(n)tt[gc]=o.MIN,tt[wc]=o.MAX;else{const B=t.get("EXT_blend_minmax");B!==null&&(tt[gc]=B.MIN_EXT,tt[wc]=B.MAX_EXT)}const lt={[pd]:o.ZERO,[fd]:o.ONE,[md]:o.SRC_COLOR,[dr]:o.SRC_ALPHA,[_d]:o.SRC_ALPHA_SATURATE,[xd]:o.DST_COLOR,[wd]:o.DST_ALPHA,[gd]:o.ONE_MINUS_SRC_COLOR,[ur]:o.ONE_MINUS_SRC_ALPHA,[vd]:o.ONE_MINUS_DST_COLOR,[yd]:o.ONE_MINUS_DST_ALPHA,[Md]:o.CONSTANT_COLOR,[Sd]:o.ONE_MINUS_CONSTANT_COLOR,[bd]:o.CONSTANT_ALPHA,[Ed]:o.ONE_MINUS_CONSTANT_ALPHA};function Q(B,mt,yt,Ft,Bt,ne,ie,Me,Se,se){if(B===Wn){f===!0&&(At(o.BLEND),f=!1);return}if(f===!1&&(Gt(o.BLEND),f=!0),B!==hd){if(B!==_||se!==P){if((x!==hi||A!==hi)&&(o.blendEquation(o.FUNC_ADD),x=hi,A=hi),se)switch(B){case os:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case Vo:o.blendFunc(o.ONE,o.ONE);break;case fc:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case mc:o.blendFuncSeparate(o.ZERO,o.SRC_COLOR,o.ZERO,o.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",B);break}else switch(B){case os:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case Vo:o.blendFunc(o.SRC_ALPHA,o.ONE);break;case fc:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case mc:o.blendFunc(o.ZERO,o.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",B);break}M=null,R=null,E=null,I=null,v.set(0,0,0),S=0,_=B,P=se}return}Bt=Bt||mt,ne=ne||yt,ie=ie||Ft,(mt!==x||Bt!==A)&&(o.blendEquationSeparate(tt[mt],tt[Bt]),x=mt,A=Bt),(yt!==M||Ft!==R||ne!==E||ie!==I)&&(o.blendFuncSeparate(lt[yt],lt[Ft],lt[ne],lt[ie]),M=yt,R=Ft,E=ne,I=ie),(Me.equals(v)===!1||Se!==S)&&(o.blendColor(Me.r,Me.g,Me.b,Se),v.copy(Me),S=Se),_=B,P=!1}function Lt(B,mt){B.side===me?At(o.CULL_FACE):Gt(o.CULL_FACE);let yt=B.side===He;mt&&(yt=!yt),ft(yt),B.blending===os&&B.transparent===!1?Q(Wn):Q(B.blending,B.blendEquation,B.blendSrc,B.blendDst,B.blendEquationAlpha,B.blendSrcAlpha,B.blendDstAlpha,B.blendColor,B.blendAlpha,B.premultipliedAlpha),c.setFunc(B.depthFunc),c.setTest(B.depthTest),c.setMask(B.depthWrite),r.setMask(B.colorWrite);const Ft=B.stencilWrite;l.setTest(Ft),Ft&&(l.setMask(B.stencilWriteMask),l.setFunc(B.stencilFunc,B.stencilRef,B.stencilFuncMask),l.setOp(B.stencilFail,B.stencilZFail,B.stencilZPass)),k(B.polygonOffset,B.polygonOffsetFactor,B.polygonOffsetUnits),B.alphaToCoverage===!0?Gt(o.SAMPLE_ALPHA_TO_COVERAGE):At(o.SAMPLE_ALPHA_TO_COVERAGE)}function ft(B){O!==B&&(B?o.frontFace(o.CW):o.frontFace(o.CCW),O=B)}function T(B){B!==cd?(Gt(o.CULL_FACE),B!==j&&(B===pc?o.cullFace(o.BACK):B===ld?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):At(o.CULL_FACE),j=B}function b(B){B!==D&&(Y&&o.lineWidth(B),D=B)}function k(B,mt,yt){B?(Gt(o.POLYGON_OFFSET_FILL),(F!==mt||z!==yt)&&(o.polygonOffset(mt,yt),F=mt,z=yt)):At(o.POLYGON_OFFSET_FILL)}function it(B){B?Gt(o.SCISSOR_TEST):At(o.SCISSOR_TEST)}function at(B){B===void 0&&(B=o.TEXTURE0+Z-1),nt!==B&&(o.activeTexture(B),nt=B)}function st(B,mt,yt){yt===void 0&&(nt===null?yt=o.TEXTURE0+Z-1:yt=nt);let Ft=ct[yt];Ft===void 0&&(Ft={type:void 0,texture:void 0},ct[yt]=Ft),(Ft.type!==B||Ft.texture!==mt)&&(nt!==yt&&(o.activeTexture(yt),nt=yt),o.bindTexture(B,mt||It[B]),Ft.type=B,Ft.texture=mt)}function St(){const B=ct[nt];B!==void 0&&B.type!==void 0&&(o.bindTexture(B.type,null),B.type=void 0,B.texture=void 0)}function wt(){try{o.compressedTexImage2D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Mt(){try{o.compressedTexImage3D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Pt(){try{o.texSubImage2D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Ut(){try{o.texSubImage3D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function rt(){try{o.compressedTexSubImage2D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Jt(){try{o.compressedTexSubImage3D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function qt(){try{o.texStorage2D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Ht(){try{o.texStorage3D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Dt(){try{o.texImage2D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Tt(){try{o.texImage3D.apply(o,arguments)}catch(B){console.error("THREE.WebGLState:",B)}}function Yt(B){pt.equals(B)===!1&&(o.scissor(B.x,B.y,B.z,B.w),pt.copy(B))}function ee(B){bt.equals(B)===!1&&(o.viewport(B.x,B.y,B.z,B.w),bt.copy(B))}function pe(B,mt){let yt=d.get(mt);yt===void 0&&(yt=new WeakMap,d.set(mt,yt));let Ft=yt.get(B);Ft===void 0&&(Ft=o.getUniformBlockIndex(mt,B.name),yt.set(B,Ft))}function jt(B,mt){const Ft=d.get(mt).get(B);h.get(mt)!==Ft&&(o.uniformBlockBinding(mt,Ft,B.__bindingPointIndex),h.set(mt,Ft))}function ut(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),n===!0&&(o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null)),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),u={},nt=null,ct={},p={},g=new WeakMap,y=[],m=null,f=!1,_=null,x=null,M=null,R=null,A=null,E=null,I=null,v=new Vt(0,0,0),S=0,P=!1,O=null,j=null,D=null,F=null,z=null,pt.set(0,0,o.canvas.width,o.canvas.height),bt.set(0,0,o.canvas.width,o.canvas.height),r.reset(),c.reset(),l.reset()}return{buffers:{color:r,depth:c,stencil:l},enable:Gt,disable:At,bindFramebuffer:Et,drawBuffers:N,useProgram:ht,setBlending:Q,setMaterial:Lt,setFlipSided:ft,setCullFace:T,setLineWidth:b,setPolygonOffset:k,setScissorTest:it,activeTexture:at,bindTexture:st,unbindTexture:St,compressedTexImage2D:wt,compressedTexImage3D:Mt,texImage2D:Dt,texImage3D:Tt,updateUBOMapping:pe,uniformBlockBinding:jt,texStorage2D:qt,texStorage3D:Ht,texSubImage2D:Pt,texSubImage3D:Ut,compressedTexSubImage2D:rt,compressedTexSubImage3D:Jt,scissor:Yt,viewport:ee,reset:ut}}function og(o,t,e,n,i,s,a){const r=i.isWebGL2,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new WeakMap;let d;const u=new WeakMap;let p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(T,b){return p?new OffscreenCanvas(T,b):jo("canvas")}function y(T,b,k,it){let at=1;if((T.width>it||T.height>it)&&(at=it/Math.max(T.width,T.height)),at<1||b===!0)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap){const st=b?xr:Math.floor,St=st(at*T.width),wt=st(at*T.height);d===void 0&&(d=g(St,wt));const Mt=k?g(St,wt):d;return Mt.width=St,Mt.height=wt,Mt.getContext("2d").drawImage(T,0,0,St,wt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+T.width+"x"+T.height+") to ("+St+"x"+wt+")."),Mt}else return"data"in T&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+T.width+"x"+T.height+")."),T;return T}function m(T){return qc(T.width)&&qc(T.height)}function f(T){return r?!1:T.wrapS!==ln||T.wrapT!==ln||T.minFilter!==ze&&T.minFilter!==tn}function _(T,b){return T.generateMipmaps&&b&&T.minFilter!==ze&&T.minFilter!==tn}function x(T){o.generateMipmap(T)}function M(T,b,k,it,at=!1){if(r===!1)return b;if(T!==null){if(o[T]!==void 0)return o[T];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let st=b;if(b===o.RED&&(k===o.FLOAT&&(st=o.R32F),k===o.HALF_FLOAT&&(st=o.R16F),k===o.UNSIGNED_BYTE&&(st=o.R8)),b===o.RED_INTEGER&&(k===o.UNSIGNED_BYTE&&(st=o.R8UI),k===o.UNSIGNED_SHORT&&(st=o.R16UI),k===o.UNSIGNED_INT&&(st=o.R32UI),k===o.BYTE&&(st=o.R8I),k===o.SHORT&&(st=o.R16I),k===o.INT&&(st=o.R32I)),b===o.RG&&(k===o.FLOAT&&(st=o.RG32F),k===o.HALF_FLOAT&&(st=o.RG16F),k===o.UNSIGNED_BYTE&&(st=o.RG8)),b===o.RGBA){const St=at?Xo:re.getTransfer(it);k===o.FLOAT&&(st=o.RGBA32F),k===o.HALF_FLOAT&&(st=o.RGBA16F),k===o.UNSIGNED_BYTE&&(st=St===ue?o.SRGB8_ALPHA8:o.RGBA8),k===o.UNSIGNED_SHORT_4_4_4_4&&(st=o.RGBA4),k===o.UNSIGNED_SHORT_5_5_5_1&&(st=o.RGB5_A1)}return(st===o.R16F||st===o.R32F||st===o.RG16F||st===o.RG32F||st===o.RGBA16F||st===o.RGBA32F)&&t.get("EXT_color_buffer_float"),st}function R(T,b,k){return _(T,k)===!0||T.isFramebufferTexture&&T.minFilter!==ze&&T.minFilter!==tn?Math.log2(Math.max(b.width,b.height))+1:T.mipmaps!==void 0&&T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?b.mipmaps.length:1}function A(T){return T===ze||T===yc||T===Aa?o.NEAREST:o.LINEAR}function E(T){const b=T.target;b.removeEventListener("dispose",E),v(b),b.isVideoTexture&&h.delete(b)}function I(T){const b=T.target;b.removeEventListener("dispose",I),P(b)}function v(T){const b=n.get(T);if(b.__webglInit===void 0)return;const k=T.source,it=u.get(k);if(it){const at=it[b.__cacheKey];at.usedTimes--,at.usedTimes===0&&S(T),Object.keys(it).length===0&&u.delete(k)}n.remove(T)}function S(T){const b=n.get(T);o.deleteTexture(b.__webglTexture);const k=T.source,it=u.get(k);delete it[b.__cacheKey],a.memory.textures--}function P(T){const b=T.texture,k=n.get(T),it=n.get(b);if(it.__webglTexture!==void 0&&(o.deleteTexture(it.__webglTexture),a.memory.textures--),T.depthTexture&&T.depthTexture.dispose(),T.isWebGLCubeRenderTarget)for(let at=0;at<6;at++){if(Array.isArray(k.__webglFramebuffer[at]))for(let st=0;st<k.__webglFramebuffer[at].length;st++)o.deleteFramebuffer(k.__webglFramebuffer[at][st]);else o.deleteFramebuffer(k.__webglFramebuffer[at]);k.__webglDepthbuffer&&o.deleteRenderbuffer(k.__webglDepthbuffer[at])}else{if(Array.isArray(k.__webglFramebuffer))for(let at=0;at<k.__webglFramebuffer.length;at++)o.deleteFramebuffer(k.__webglFramebuffer[at]);else o.deleteFramebuffer(k.__webglFramebuffer);if(k.__webglDepthbuffer&&o.deleteRenderbuffer(k.__webglDepthbuffer),k.__webglMultisampledFramebuffer&&o.deleteFramebuffer(k.__webglMultisampledFramebuffer),k.__webglColorRenderbuffer)for(let at=0;at<k.__webglColorRenderbuffer.length;at++)k.__webglColorRenderbuffer[at]&&o.deleteRenderbuffer(k.__webglColorRenderbuffer[at]);k.__webglDepthRenderbuffer&&o.deleteRenderbuffer(k.__webglDepthRenderbuffer)}if(T.isWebGLMultipleRenderTargets)for(let at=0,st=b.length;at<st;at++){const St=n.get(b[at]);St.__webglTexture&&(o.deleteTexture(St.__webglTexture),a.memory.textures--),n.remove(b[at])}n.remove(b),n.remove(T)}let O=0;function j(){O=0}function D(){const T=O;return T>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+T+" texture units while this GPU supports only "+i.maxTextures),O+=1,T}function F(T){const b=[];return b.push(T.wrapS),b.push(T.wrapT),b.push(T.wrapR||0),b.push(T.magFilter),b.push(T.minFilter),b.push(T.anisotropy),b.push(T.internalFormat),b.push(T.format),b.push(T.type),b.push(T.generateMipmaps),b.push(T.premultiplyAlpha),b.push(T.flipY),b.push(T.unpackAlignment),b.push(T.colorSpace),b.join()}function z(T,b){const k=n.get(T);if(T.isVideoTexture&&Lt(T),T.isRenderTargetTexture===!1&&T.version>0&&k.__version!==T.version){const it=T.image;if(it===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(it.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{pt(k,T,b);return}}e.bindTexture(o.TEXTURE_2D,k.__webglTexture,o.TEXTURE0+b)}function Z(T,b){const k=n.get(T);if(T.version>0&&k.__version!==T.version){pt(k,T,b);return}e.bindTexture(o.TEXTURE_2D_ARRAY,k.__webglTexture,o.TEXTURE0+b)}function Y(T,b){const k=n.get(T);if(T.version>0&&k.__version!==T.version){pt(k,T,b);return}e.bindTexture(o.TEXTURE_3D,k.__webglTexture,o.TEXTURE0+b)}function q(T,b){const k=n.get(T);if(T.version>0&&k.__version!==T.version){bt(k,T,b);return}e.bindTexture(o.TEXTURE_CUBE_MAP,k.__webglTexture,o.TEXTURE0+b)}const J={[mr]:o.REPEAT,[ln]:o.CLAMP_TO_EDGE,[gr]:o.MIRRORED_REPEAT},nt={[ze]:o.NEAREST,[yc]:o.NEAREST_MIPMAP_NEAREST,[Aa]:o.NEAREST_MIPMAP_LINEAR,[tn]:o.LINEAR,[kd]:o.LINEAR_MIPMAP_NEAREST,[Us]:o.LINEAR_MIPMAP_LINEAR},ct={[Jd]:o.NEVER,[su]:o.ALWAYS,[Qd]:o.LESS,[ch]:o.LEQUAL,[tu]:o.EQUAL,[iu]:o.GEQUAL,[eu]:o.GREATER,[nu]:o.NOTEQUAL};function X(T,b,k){if(k?(o.texParameteri(T,o.TEXTURE_WRAP_S,J[b.wrapS]),o.texParameteri(T,o.TEXTURE_WRAP_T,J[b.wrapT]),(T===o.TEXTURE_3D||T===o.TEXTURE_2D_ARRAY)&&o.texParameteri(T,o.TEXTURE_WRAP_R,J[b.wrapR]),o.texParameteri(T,o.TEXTURE_MAG_FILTER,nt[b.magFilter]),o.texParameteri(T,o.TEXTURE_MIN_FILTER,nt[b.minFilter])):(o.texParameteri(T,o.TEXTURE_WRAP_S,o.CLAMP_TO_EDGE),o.texParameteri(T,o.TEXTURE_WRAP_T,o.CLAMP_TO_EDGE),(T===o.TEXTURE_3D||T===o.TEXTURE_2D_ARRAY)&&o.texParameteri(T,o.TEXTURE_WRAP_R,o.CLAMP_TO_EDGE),(b.wrapS!==ln||b.wrapT!==ln)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),o.texParameteri(T,o.TEXTURE_MAG_FILTER,A(b.magFilter)),o.texParameteri(T,o.TEXTURE_MIN_FILTER,A(b.minFilter)),b.minFilter!==ze&&b.minFilter!==tn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),b.compareFunction&&(o.texParameteri(T,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(T,o.TEXTURE_COMPARE_FUNC,ct[b.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){const it=t.get("EXT_texture_filter_anisotropic");if(b.magFilter===ze||b.minFilter!==Aa&&b.minFilter!==Us||b.type===Hn&&t.has("OES_texture_float_linear")===!1||r===!1&&b.type===Ns&&t.has("OES_texture_half_float_linear")===!1)return;(b.anisotropy>1||n.get(b).__currentAnisotropy)&&(o.texParameterf(T,it.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,i.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy)}}function et(T,b){let k=!1;T.__webglInit===void 0&&(T.__webglInit=!0,b.addEventListener("dispose",E));const it=b.source;let at=u.get(it);at===void 0&&(at={},u.set(it,at));const st=F(b);if(st!==T.__cacheKey){at[st]===void 0&&(at[st]={texture:o.createTexture(),usedTimes:0},a.memory.textures++,k=!0),at[st].usedTimes++;const St=at[T.__cacheKey];St!==void 0&&(at[T.__cacheKey].usedTimes--,St.usedTimes===0&&S(b)),T.__cacheKey=st,T.__webglTexture=at[st].texture}return k}function pt(T,b,k){let it=o.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(it=o.TEXTURE_2D_ARRAY),b.isData3DTexture&&(it=o.TEXTURE_3D);const at=et(T,b),st=b.source;e.bindTexture(it,T.__webglTexture,o.TEXTURE0+k);const St=n.get(st);if(st.version!==St.__version||at===!0){e.activeTexture(o.TEXTURE0+k);const wt=re.getPrimaries(re.workingColorSpace),Mt=b.colorSpace===nn?null:re.getPrimaries(b.colorSpace),Pt=b.colorSpace===nn||wt===Mt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,b.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,b.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Pt);const Ut=f(b)&&m(b.image)===!1;let rt=y(b.image,Ut,!1,i.maxTextureSize);rt=ft(b,rt);const Jt=m(rt)||r,qt=s.convert(b.format,b.colorSpace);let Ht=s.convert(b.type),Dt=M(b.internalFormat,qt,Ht,b.colorSpace,b.isVideoTexture);X(it,b,Jt);let Tt;const Yt=b.mipmaps,ee=r&&b.isVideoTexture!==!0&&Dt!==oh,pe=St.__version===void 0||at===!0,jt=R(b,rt,Jt);if(b.isDepthTexture)Dt=o.DEPTH_COMPONENT,r?b.type===Hn?Dt=o.DEPTH_COMPONENT32F:b.type===Gn?Dt=o.DEPTH_COMPONENT24:b.type===ui?Dt=o.DEPTH24_STENCIL8:Dt=o.DEPTH_COMPONENT16:b.type===Hn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),b.format===pi&&Dt===o.DEPTH_COMPONENT&&b.type!==Cr&&b.type!==Gn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),b.type=Gn,Ht=s.convert(b.type)),b.format===ls&&Dt===o.DEPTH_COMPONENT&&(Dt=o.DEPTH_STENCIL,b.type!==ui&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),b.type=ui,Ht=s.convert(b.type))),pe&&(ee?e.texStorage2D(o.TEXTURE_2D,1,Dt,rt.width,rt.height):e.texImage2D(o.TEXTURE_2D,0,Dt,rt.width,rt.height,0,qt,Ht,null));else if(b.isDataTexture)if(Yt.length>0&&Jt){ee&&pe&&e.texStorage2D(o.TEXTURE_2D,jt,Dt,Yt[0].width,Yt[0].height);for(let ut=0,B=Yt.length;ut<B;ut++)Tt=Yt[ut],ee?e.texSubImage2D(o.TEXTURE_2D,ut,0,0,Tt.width,Tt.height,qt,Ht,Tt.data):e.texImage2D(o.TEXTURE_2D,ut,Dt,Tt.width,Tt.height,0,qt,Ht,Tt.data);b.generateMipmaps=!1}else ee?(pe&&e.texStorage2D(o.TEXTURE_2D,jt,Dt,rt.width,rt.height),e.texSubImage2D(o.TEXTURE_2D,0,0,0,rt.width,rt.height,qt,Ht,rt.data)):e.texImage2D(o.TEXTURE_2D,0,Dt,rt.width,rt.height,0,qt,Ht,rt.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){ee&&pe&&e.texStorage3D(o.TEXTURE_2D_ARRAY,jt,Dt,Yt[0].width,Yt[0].height,rt.depth);for(let ut=0,B=Yt.length;ut<B;ut++)Tt=Yt[ut],b.format!==hn?qt!==null?ee?e.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,ut,0,0,0,Tt.width,Tt.height,rt.depth,qt,Tt.data,0,0):e.compressedTexImage3D(o.TEXTURE_2D_ARRAY,ut,Dt,Tt.width,Tt.height,rt.depth,0,Tt.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ee?e.texSubImage3D(o.TEXTURE_2D_ARRAY,ut,0,0,0,Tt.width,Tt.height,rt.depth,qt,Ht,Tt.data):e.texImage3D(o.TEXTURE_2D_ARRAY,ut,Dt,Tt.width,Tt.height,rt.depth,0,qt,Ht,Tt.data)}else{ee&&pe&&e.texStorage2D(o.TEXTURE_2D,jt,Dt,Yt[0].width,Yt[0].height);for(let ut=0,B=Yt.length;ut<B;ut++)Tt=Yt[ut],b.format!==hn?qt!==null?ee?e.compressedTexSubImage2D(o.TEXTURE_2D,ut,0,0,Tt.width,Tt.height,qt,Tt.data):e.compressedTexImage2D(o.TEXTURE_2D,ut,Dt,Tt.width,Tt.height,0,Tt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ee?e.texSubImage2D(o.TEXTURE_2D,ut,0,0,Tt.width,Tt.height,qt,Ht,Tt.data):e.texImage2D(o.TEXTURE_2D,ut,Dt,Tt.width,Tt.height,0,qt,Ht,Tt.data)}else if(b.isDataArrayTexture)ee?(pe&&e.texStorage3D(o.TEXTURE_2D_ARRAY,jt,Dt,rt.width,rt.height,rt.depth),e.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,rt.width,rt.height,rt.depth,qt,Ht,rt.data)):e.texImage3D(o.TEXTURE_2D_ARRAY,0,Dt,rt.width,rt.height,rt.depth,0,qt,Ht,rt.data);else if(b.isData3DTexture)ee?(pe&&e.texStorage3D(o.TEXTURE_3D,jt,Dt,rt.width,rt.height,rt.depth),e.texSubImage3D(o.TEXTURE_3D,0,0,0,0,rt.width,rt.height,rt.depth,qt,Ht,rt.data)):e.texImage3D(o.TEXTURE_3D,0,Dt,rt.width,rt.height,rt.depth,0,qt,Ht,rt.data);else if(b.isFramebufferTexture){if(pe)if(ee)e.texStorage2D(o.TEXTURE_2D,jt,Dt,rt.width,rt.height);else{let ut=rt.width,B=rt.height;for(let mt=0;mt<jt;mt++)e.texImage2D(o.TEXTURE_2D,mt,Dt,ut,B,0,qt,Ht,null),ut>>=1,B>>=1}}else if(Yt.length>0&&Jt){ee&&pe&&e.texStorage2D(o.TEXTURE_2D,jt,Dt,Yt[0].width,Yt[0].height);for(let ut=0,B=Yt.length;ut<B;ut++)Tt=Yt[ut],ee?e.texSubImage2D(o.TEXTURE_2D,ut,0,0,qt,Ht,Tt):e.texImage2D(o.TEXTURE_2D,ut,Dt,qt,Ht,Tt);b.generateMipmaps=!1}else ee?(pe&&e.texStorage2D(o.TEXTURE_2D,jt,Dt,rt.width,rt.height),e.texSubImage2D(o.TEXTURE_2D,0,0,0,qt,Ht,rt)):e.texImage2D(o.TEXTURE_2D,0,Dt,qt,Ht,rt);_(b,Jt)&&x(it),St.__version=st.version,b.onUpdate&&b.onUpdate(b)}T.__version=b.version}function bt(T,b,k){if(b.image.length!==6)return;const it=et(T,b),at=b.source;e.bindTexture(o.TEXTURE_CUBE_MAP,T.__webglTexture,o.TEXTURE0+k);const st=n.get(at);if(at.version!==st.__version||it===!0){e.activeTexture(o.TEXTURE0+k);const St=re.getPrimaries(re.workingColorSpace),wt=b.colorSpace===nn?null:re.getPrimaries(b.colorSpace),Mt=b.colorSpace===nn||St===wt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,b.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,b.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Mt);const Pt=b.isCompressedTexture||b.image[0].isCompressedTexture,Ut=b.image[0]&&b.image[0].isDataTexture,rt=[];for(let ut=0;ut<6;ut++)!Pt&&!Ut?rt[ut]=y(b.image[ut],!1,!0,i.maxCubemapSize):rt[ut]=Ut?b.image[ut].image:b.image[ut],rt[ut]=ft(b,rt[ut]);const Jt=rt[0],qt=m(Jt)||r,Ht=s.convert(b.format,b.colorSpace),Dt=s.convert(b.type),Tt=M(b.internalFormat,Ht,Dt,b.colorSpace),Yt=r&&b.isVideoTexture!==!0,ee=st.__version===void 0||it===!0;let pe=R(b,Jt,qt);X(o.TEXTURE_CUBE_MAP,b,qt);let jt;if(Pt){Yt&&ee&&e.texStorage2D(o.TEXTURE_CUBE_MAP,pe,Tt,Jt.width,Jt.height);for(let ut=0;ut<6;ut++){jt=rt[ut].mipmaps;for(let B=0;B<jt.length;B++){const mt=jt[B];b.format!==hn?Ht!==null?Yt?e.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B,0,0,mt.width,mt.height,Ht,mt.data):e.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B,Tt,mt.width,mt.height,0,mt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Yt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B,0,0,mt.width,mt.height,Ht,Dt,mt.data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B,Tt,mt.width,mt.height,0,Ht,Dt,mt.data)}}}else{jt=b.mipmaps,Yt&&ee&&(jt.length>0&&pe++,e.texStorage2D(o.TEXTURE_CUBE_MAP,pe,Tt,rt[0].width,rt[0].height));for(let ut=0;ut<6;ut++)if(Ut){Yt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,0,0,0,rt[ut].width,rt[ut].height,Ht,Dt,rt[ut].data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,0,Tt,rt[ut].width,rt[ut].height,0,Ht,Dt,rt[ut].data);for(let B=0;B<jt.length;B++){const yt=jt[B].image[ut].image;Yt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B+1,0,0,yt.width,yt.height,Ht,Dt,yt.data):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B+1,Tt,yt.width,yt.height,0,Ht,Dt,yt.data)}}else{Yt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,0,0,0,Ht,Dt,rt[ut]):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,0,Tt,Ht,Dt,rt[ut]);for(let B=0;B<jt.length;B++){const mt=jt[B];Yt?e.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B+1,0,0,Ht,Dt,mt.image[ut]):e.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+ut,B+1,Tt,Ht,Dt,mt.image[ut])}}}_(b,qt)&&x(o.TEXTURE_CUBE_MAP),st.__version=at.version,b.onUpdate&&b.onUpdate(b)}T.__version=b.version}function xt(T,b,k,it,at,st){const St=s.convert(k.format,k.colorSpace),wt=s.convert(k.type),Mt=M(k.internalFormat,St,wt,k.colorSpace);if(!n.get(b).__hasExternalTextures){const Ut=Math.max(1,b.width>>st),rt=Math.max(1,b.height>>st);at===o.TEXTURE_3D||at===o.TEXTURE_2D_ARRAY?e.texImage3D(at,st,Mt,Ut,rt,b.depth,0,St,wt,null):e.texImage2D(at,st,Mt,Ut,rt,0,St,wt,null)}e.bindFramebuffer(o.FRAMEBUFFER,T),Q(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,it,at,n.get(k).__webglTexture,0,lt(b)):(at===o.TEXTURE_2D||at>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&at<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,it,at,n.get(k).__webglTexture,st),e.bindFramebuffer(o.FRAMEBUFFER,null)}function It(T,b,k){if(o.bindRenderbuffer(o.RENDERBUFFER,T),b.depthBuffer&&!b.stencilBuffer){let it=r===!0?o.DEPTH_COMPONENT24:o.DEPTH_COMPONENT16;if(k||Q(b)){const at=b.depthTexture;at&&at.isDepthTexture&&(at.type===Hn?it=o.DEPTH_COMPONENT32F:at.type===Gn&&(it=o.DEPTH_COMPONENT24));const st=lt(b);Q(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,st,it,b.width,b.height):o.renderbufferStorageMultisample(o.RENDERBUFFER,st,it,b.width,b.height)}else o.renderbufferStorage(o.RENDERBUFFER,it,b.width,b.height);o.framebufferRenderbuffer(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.RENDERBUFFER,T)}else if(b.depthBuffer&&b.stencilBuffer){const it=lt(b);k&&Q(b)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,it,o.DEPTH24_STENCIL8,b.width,b.height):Q(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,it,o.DEPTH24_STENCIL8,b.width,b.height):o.renderbufferStorage(o.RENDERBUFFER,o.DEPTH_STENCIL,b.width,b.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.RENDERBUFFER,T)}else{const it=b.isWebGLMultipleRenderTargets===!0?b.texture:[b.texture];for(let at=0;at<it.length;at++){const st=it[at],St=s.convert(st.format,st.colorSpace),wt=s.convert(st.type),Mt=M(st.internalFormat,St,wt,st.colorSpace),Pt=lt(b);k&&Q(b)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,Pt,Mt,b.width,b.height):Q(b)?c.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,Pt,Mt,b.width,b.height):o.renderbufferStorage(o.RENDERBUFFER,Mt,b.width,b.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function Gt(T,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(o.FRAMEBUFFER,T),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(b.depthTexture).__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),z(b.depthTexture,0);const it=n.get(b.depthTexture).__webglTexture,at=lt(b);if(b.depthTexture.format===pi)Q(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,it,0,at):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,it,0);else if(b.depthTexture.format===ls)Q(b)?c.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,it,0,at):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,it,0);else throw new Error("Unknown depthTexture format")}function At(T){const b=n.get(T),k=T.isWebGLCubeRenderTarget===!0;if(T.depthTexture&&!b.__autoAllocateDepthBuffer){if(k)throw new Error("target.depthTexture not supported in Cube render targets");Gt(b.__webglFramebuffer,T)}else if(k){b.__webglDepthbuffer=[];for(let it=0;it<6;it++)e.bindFramebuffer(o.FRAMEBUFFER,b.__webglFramebuffer[it]),b.__webglDepthbuffer[it]=o.createRenderbuffer(),It(b.__webglDepthbuffer[it],T,!1)}else e.bindFramebuffer(o.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer=o.createRenderbuffer(),It(b.__webglDepthbuffer,T,!1);e.bindFramebuffer(o.FRAMEBUFFER,null)}function Et(T,b,k){const it=n.get(T);b!==void 0&&xt(it.__webglFramebuffer,T,T.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),k!==void 0&&At(T)}function N(T){const b=T.texture,k=n.get(T),it=n.get(b);T.addEventListener("dispose",I),T.isWebGLMultipleRenderTargets!==!0&&(it.__webglTexture===void 0&&(it.__webglTexture=o.createTexture()),it.__version=b.version,a.memory.textures++);const at=T.isWebGLCubeRenderTarget===!0,st=T.isWebGLMultipleRenderTargets===!0,St=m(T)||r;if(at){k.__webglFramebuffer=[];for(let wt=0;wt<6;wt++)if(r&&b.mipmaps&&b.mipmaps.length>0){k.__webglFramebuffer[wt]=[];for(let Mt=0;Mt<b.mipmaps.length;Mt++)k.__webglFramebuffer[wt][Mt]=o.createFramebuffer()}else k.__webglFramebuffer[wt]=o.createFramebuffer()}else{if(r&&b.mipmaps&&b.mipmaps.length>0){k.__webglFramebuffer=[];for(let wt=0;wt<b.mipmaps.length;wt++)k.__webglFramebuffer[wt]=o.createFramebuffer()}else k.__webglFramebuffer=o.createFramebuffer();if(st)if(i.drawBuffers){const wt=T.texture;for(let Mt=0,Pt=wt.length;Mt<Pt;Mt++){const Ut=n.get(wt[Mt]);Ut.__webglTexture===void 0&&(Ut.__webglTexture=o.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(r&&T.samples>0&&Q(T)===!1){const wt=st?b:[b];k.__webglMultisampledFramebuffer=o.createFramebuffer(),k.__webglColorRenderbuffer=[],e.bindFramebuffer(o.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let Mt=0;Mt<wt.length;Mt++){const Pt=wt[Mt];k.__webglColorRenderbuffer[Mt]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,k.__webglColorRenderbuffer[Mt]);const Ut=s.convert(Pt.format,Pt.colorSpace),rt=s.convert(Pt.type),Jt=M(Pt.internalFormat,Ut,rt,Pt.colorSpace,T.isXRRenderTarget===!0),qt=lt(T);o.renderbufferStorageMultisample(o.RENDERBUFFER,qt,Jt,T.width,T.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Mt,o.RENDERBUFFER,k.__webglColorRenderbuffer[Mt])}o.bindRenderbuffer(o.RENDERBUFFER,null),T.depthBuffer&&(k.__webglDepthRenderbuffer=o.createRenderbuffer(),It(k.__webglDepthRenderbuffer,T,!0)),e.bindFramebuffer(o.FRAMEBUFFER,null)}}if(at){e.bindTexture(o.TEXTURE_CUBE_MAP,it.__webglTexture),X(o.TEXTURE_CUBE_MAP,b,St);for(let wt=0;wt<6;wt++)if(r&&b.mipmaps&&b.mipmaps.length>0)for(let Mt=0;Mt<b.mipmaps.length;Mt++)xt(k.__webglFramebuffer[wt][Mt],T,b,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+wt,Mt);else xt(k.__webglFramebuffer[wt],T,b,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+wt,0);_(b,St)&&x(o.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(st){const wt=T.texture;for(let Mt=0,Pt=wt.length;Mt<Pt;Mt++){const Ut=wt[Mt],rt=n.get(Ut);e.bindTexture(o.TEXTURE_2D,rt.__webglTexture),X(o.TEXTURE_2D,Ut,St),xt(k.__webglFramebuffer,T,Ut,o.COLOR_ATTACHMENT0+Mt,o.TEXTURE_2D,0),_(Ut,St)&&x(o.TEXTURE_2D)}e.unbindTexture()}else{let wt=o.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(r?wt=T.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),e.bindTexture(wt,it.__webglTexture),X(wt,b,St),r&&b.mipmaps&&b.mipmaps.length>0)for(let Mt=0;Mt<b.mipmaps.length;Mt++)xt(k.__webglFramebuffer[Mt],T,b,o.COLOR_ATTACHMENT0,wt,Mt);else xt(k.__webglFramebuffer,T,b,o.COLOR_ATTACHMENT0,wt,0);_(b,St)&&x(wt),e.unbindTexture()}T.depthBuffer&&At(T)}function ht(T){const b=m(T)||r,k=T.isWebGLMultipleRenderTargets===!0?T.texture:[T.texture];for(let it=0,at=k.length;it<at;it++){const st=k[it];if(_(st,b)){const St=T.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:o.TEXTURE_2D,wt=n.get(st).__webglTexture;e.bindTexture(St,wt),x(St),e.unbindTexture()}}}function tt(T){if(r&&T.samples>0&&Q(T)===!1){const b=T.isWebGLMultipleRenderTargets?T.texture:[T.texture],k=T.width,it=T.height;let at=o.COLOR_BUFFER_BIT;const st=[],St=T.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,wt=n.get(T),Mt=T.isWebGLMultipleRenderTargets===!0;if(Mt)for(let Pt=0;Pt<b.length;Pt++)e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Pt,o.RENDERBUFFER,null),e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Pt,o.TEXTURE_2D,null,0);e.bindFramebuffer(o.READ_FRAMEBUFFER,wt.__webglMultisampledFramebuffer),e.bindFramebuffer(o.DRAW_FRAMEBUFFER,wt.__webglFramebuffer);for(let Pt=0;Pt<b.length;Pt++){st.push(o.COLOR_ATTACHMENT0+Pt),T.depthBuffer&&st.push(St);const Ut=wt.__ignoreDepthValues!==void 0?wt.__ignoreDepthValues:!1;if(Ut===!1&&(T.depthBuffer&&(at|=o.DEPTH_BUFFER_BIT),T.stencilBuffer&&(at|=o.STENCIL_BUFFER_BIT)),Mt&&o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,wt.__webglColorRenderbuffer[Pt]),Ut===!0&&(o.invalidateFramebuffer(o.READ_FRAMEBUFFER,[St]),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[St])),Mt){const rt=n.get(b[Pt]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,rt,0)}o.blitFramebuffer(0,0,k,it,0,0,k,it,at,o.NEAREST),l&&o.invalidateFramebuffer(o.READ_FRAMEBUFFER,st)}if(e.bindFramebuffer(o.READ_FRAMEBUFFER,null),e.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),Mt)for(let Pt=0;Pt<b.length;Pt++){e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Pt,o.RENDERBUFFER,wt.__webglColorRenderbuffer[Pt]);const Ut=n.get(b[Pt]).__webglTexture;e.bindFramebuffer(o.FRAMEBUFFER,wt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Pt,o.TEXTURE_2D,Ut,0)}e.bindFramebuffer(o.DRAW_FRAMEBUFFER,wt.__webglMultisampledFramebuffer)}}function lt(T){return Math.min(i.maxSamples,T.samples)}function Q(T){const b=n.get(T);return r&&T.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function Lt(T){const b=a.render.frame;h.get(T)!==b&&(h.set(T,b),T.update())}function ft(T,b){const k=T.colorSpace,it=T.format,at=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||T.format===yr||k!==Un&&k!==nn&&(re.getTransfer(k)===ue?r===!1?t.has("EXT_sRGB")===!0&&it===hn?(T.format=yr,T.minFilter=tn,T.generateMipmaps=!1):b=hh.sRGBToLinear(b):(it!==hn||at!==qn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",k)),b}this.allocateTextureUnit=D,this.resetTextureUnits=j,this.setTexture2D=z,this.setTexture2DArray=Z,this.setTexture3D=Y,this.setTextureCube=q,this.rebindTextures=Et,this.setupRenderTarget=N,this.updateRenderTargetMipmap=ht,this.updateMultisampleRenderTarget=tt,this.setupDepthRenderbuffer=At,this.setupFrameBufferTexture=xt,this.useMultisampledRTT=Q}function ag(o,t,e){const n=e.isWebGL2;function i(s,a=nn){let r;const c=re.getTransfer(a);if(s===qn)return o.UNSIGNED_BYTE;if(s===th)return o.UNSIGNED_SHORT_4_4_4_4;if(s===eh)return o.UNSIGNED_SHORT_5_5_5_1;if(s===Gd)return o.BYTE;if(s===Hd)return o.SHORT;if(s===Cr)return o.UNSIGNED_SHORT;if(s===Ql)return o.INT;if(s===Gn)return o.UNSIGNED_INT;if(s===Hn)return o.FLOAT;if(s===Ns)return n?o.HALF_FLOAT:(r=t.get("OES_texture_half_float"),r!==null?r.HALF_FLOAT_OES:null);if(s===Vd)return o.ALPHA;if(s===hn)return o.RGBA;if(s===Wd)return o.LUMINANCE;if(s===Xd)return o.LUMINANCE_ALPHA;if(s===pi)return o.DEPTH_COMPONENT;if(s===ls)return o.DEPTH_STENCIL;if(s===yr)return r=t.get("EXT_sRGB"),r!==null?r.SRGB_ALPHA_EXT:null;if(s===qd)return o.RED;if(s===nh)return o.RED_INTEGER;if(s===Yd)return o.RG;if(s===ih)return o.RG_INTEGER;if(s===sh)return o.RGBA_INTEGER;if(s===Ca||s===Ra||s===La||s===Pa)if(c===ue)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(s===Ca)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Ra)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===La)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Pa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(s===Ca)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Ra)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===La)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Pa)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===xc||s===vc||s===_c||s===Mc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(s===xc)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===vc)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===_c)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===Mc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===oh)return r=t.get("WEBGL_compressed_texture_etc1"),r!==null?r.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===Sc||s===bc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(s===Sc)return c===ue?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(s===bc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===Ec||s===Tc||s===Ac||s===Cc||s===Rc||s===Lc||s===Pc||s===Ic||s===Dc||s===Uc||s===Nc||s===Bc||s===Fc||s===Oc)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(s===Ec)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Tc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Ac)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Cc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Rc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Lc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Pc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Ic)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===Dc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Uc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Nc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Bc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Fc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Oc)return c===ue?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Ia||s===zc||s===kc)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(s===Ia)return c===ue?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===zc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===kc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===$d||s===Gc||s===Hc||s===Vc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(s===Ia)return r.COMPRESSED_RED_RGTC1_EXT;if(s===Gc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===Hc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Vc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===ui?n?o.UNSIGNED_INT_24_8:(r=t.get("WEBGL_depth_texture"),r!==null?r.UNSIGNED_INT_24_8_WEBGL:null):o[s]!==void 0?o[s]:null}return{convert:i}}class rg extends Ge{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}}class ot extends _e{constructor(){super(),this.isGroup=!0,this.type="Group"}}const cg={type:"move"};class ir{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new ot,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new ot,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new ot,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,s=null,a=null;const r=this._targetRay,c=this._grip,l=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(l&&t.hand){a=!0;for(const y of t.hand.values()){const m=e.getJointPose(y,n),f=this._getHandJoint(l,y);m!==null&&(f.matrix.fromArray(m.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=m.radius),f.visible=m!==null}const h=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],u=h.position.distanceTo(d.position),p=.02,g=.005;l.inputState.pinching&&u>p+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!l.inputState.pinching&&u<=p-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else c!==null&&t.gripSpace&&(s=e.getPose(t.gripSpace,n),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));r!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&s!==null&&(i=s),i!==null&&(r.matrix.fromArray(i.transform.matrix),r.matrix.decompose(r.position,r.rotation,r.scale),r.matrixWorldNeedsUpdate=!0,i.linearVelocity?(r.hasLinearVelocity=!0,r.linearVelocity.copy(i.linearVelocity)):r.hasLinearVelocity=!1,i.angularVelocity?(r.hasAngularVelocity=!0,r.angularVelocity.copy(i.angularVelocity)):r.hasAngularVelocity=!1,this.dispatchEvent(cg)))}return r!==null&&(r.visible=i!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new ot;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}class lg extends ds{constructor(t,e){super();const n=this;let i=null,s=1,a=null,r="local-floor",c=1,l=null,h=null,d=null,u=null,p=null,g=null;const y=e.getContextAttributes();let m=null,f=null;const _=[],x=[],M=new dt;let R=null;const A=new Ge;A.layers.enable(1),A.viewport=new ge;const E=new Ge;E.layers.enable(2),E.viewport=new ge;const I=[A,E],v=new rg;v.layers.enable(1),v.layers.enable(2);let S=null,P=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(X){let et=_[X];return et===void 0&&(et=new ir,_[X]=et),et.getTargetRaySpace()},this.getControllerGrip=function(X){let et=_[X];return et===void 0&&(et=new ir,_[X]=et),et.getGripSpace()},this.getHand=function(X){let et=_[X];return et===void 0&&(et=new ir,_[X]=et),et.getHandSpace()};function O(X){const et=x.indexOf(X.inputSource);if(et===-1)return;const pt=_[et];pt!==void 0&&(pt.update(X.inputSource,X.frame,l||a),pt.dispatchEvent({type:X.type,data:X.inputSource}))}function j(){i.removeEventListener("select",O),i.removeEventListener("selectstart",O),i.removeEventListener("selectend",O),i.removeEventListener("squeeze",O),i.removeEventListener("squeezestart",O),i.removeEventListener("squeezeend",O),i.removeEventListener("end",j),i.removeEventListener("inputsourceschange",D);for(let X=0;X<_.length;X++){const et=x[X];et!==null&&(x[X]=null,_[X].disconnect(et))}S=null,P=null,t.setRenderTarget(m),p=null,u=null,d=null,i=null,f=null,ct.stop(),n.isPresenting=!1,t.setPixelRatio(R),t.setSize(M.width,M.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(X){s=X,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(X){r=X,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(X){l=X},this.getBaseLayer=function(){return u!==null?u:p},this.getBinding=function(){return d},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(X){if(i=X,i!==null){if(m=t.getRenderTarget(),i.addEventListener("select",O),i.addEventListener("selectstart",O),i.addEventListener("selectend",O),i.addEventListener("squeeze",O),i.addEventListener("squeezestart",O),i.addEventListener("squeezeend",O),i.addEventListener("end",j),i.addEventListener("inputsourceschange",D),y.xrCompatible!==!0&&await e.makeXRCompatible(),R=t.getPixelRatio(),t.getSize(M),i.renderState.layers===void 0||t.capabilities.isWebGL2===!1){const et={antialias:i.renderState.layers===void 0?y.antialias:!0,alpha:!0,depth:y.depth,stencil:y.stencil,framebufferScaleFactor:s};p=new XRWebGLLayer(i,e,et),i.updateRenderState({baseLayer:p}),t.setPixelRatio(1),t.setSize(p.framebufferWidth,p.framebufferHeight,!1),f=new mi(p.framebufferWidth,p.framebufferHeight,{format:hn,type:qn,colorSpace:t.outputColorSpace,stencilBuffer:y.stencil})}else{let et=null,pt=null,bt=null;y.depth&&(bt=y.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,et=y.stencil?ls:pi,pt=y.stencil?ui:Gn);const xt={colorFormat:e.RGBA8,depthFormat:bt,scaleFactor:s};d=new XRWebGLBinding(i,e),u=d.createProjectionLayer(xt),i.updateRenderState({layers:[u]}),t.setPixelRatio(1),t.setSize(u.textureWidth,u.textureHeight,!1),f=new mi(u.textureWidth,u.textureHeight,{format:hn,type:qn,depthTexture:new _h(u.textureWidth,u.textureHeight,pt,void 0,void 0,void 0,void 0,void 0,void 0,et),stencilBuffer:y.stencil,colorSpace:t.outputColorSpace,samples:y.antialias?4:0});const It=t.properties.get(f);It.__ignoreDepthValues=u.ignoreDepthValues}f.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await i.requestReferenceSpace(r),ct.setContext(i),ct.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode};function D(X){for(let et=0;et<X.removed.length;et++){const pt=X.removed[et],bt=x.indexOf(pt);bt>=0&&(x[bt]=null,_[bt].disconnect(pt))}for(let et=0;et<X.added.length;et++){const pt=X.added[et];let bt=x.indexOf(pt);if(bt===-1){for(let It=0;It<_.length;It++)if(It>=x.length){x.push(pt),bt=It;break}else if(x[It]===null){x[It]=pt,bt=It;break}if(bt===-1)break}const xt=_[bt];xt&&xt.connect(pt)}}const F=new L,z=new L;function Z(X,et,pt){F.setFromMatrixPosition(et.matrixWorld),z.setFromMatrixPosition(pt.matrixWorld);const bt=F.distanceTo(z),xt=et.projectionMatrix.elements,It=pt.projectionMatrix.elements,Gt=xt[14]/(xt[10]-1),At=xt[14]/(xt[10]+1),Et=(xt[9]+1)/xt[5],N=(xt[9]-1)/xt[5],ht=(xt[8]-1)/xt[0],tt=(It[8]+1)/It[0],lt=Gt*ht,Q=Gt*tt,Lt=bt/(-ht+tt),ft=Lt*-ht;et.matrixWorld.decompose(X.position,X.quaternion,X.scale),X.translateX(ft),X.translateZ(Lt),X.matrixWorld.compose(X.position,X.quaternion,X.scale),X.matrixWorldInverse.copy(X.matrixWorld).invert();const T=Gt+Lt,b=At+Lt,k=lt-ft,it=Q+(bt-ft),at=Et*At/b*T,st=N*At/b*T;X.projectionMatrix.makePerspective(k,it,at,st,T,b),X.projectionMatrixInverse.copy(X.projectionMatrix).invert()}function Y(X,et){et===null?X.matrixWorld.copy(X.matrix):X.matrixWorld.multiplyMatrices(et.matrixWorld,X.matrix),X.matrixWorldInverse.copy(X.matrixWorld).invert()}this.updateCamera=function(X){if(i===null)return;v.near=E.near=A.near=X.near,v.far=E.far=A.far=X.far,(S!==v.near||P!==v.far)&&(i.updateRenderState({depthNear:v.near,depthFar:v.far}),S=v.near,P=v.far);const et=X.parent,pt=v.cameras;Y(v,et);for(let bt=0;bt<pt.length;bt++)Y(pt[bt],et);pt.length===2?Z(v,A,E):v.projectionMatrix.copy(A.projectionMatrix),q(X,v,et)};function q(X,et,pt){pt===null?X.matrix.copy(et.matrixWorld):(X.matrix.copy(pt.matrixWorld),X.matrix.invert(),X.matrix.multiply(et.matrixWorld)),X.matrix.decompose(X.position,X.quaternion,X.scale),X.updateMatrixWorld(!0),X.projectionMatrix.copy(et.projectionMatrix),X.projectionMatrixInverse.copy(et.projectionMatrixInverse),X.isPerspectiveCamera&&(X.fov=Zo*2*Math.atan(1/X.projectionMatrix.elements[5]),X.zoom=1)}this.getCamera=function(){return v},this.getFoveation=function(){if(!(u===null&&p===null))return c},this.setFoveation=function(X){c=X,u!==null&&(u.fixedFoveation=X),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=X)};let J=null;function nt(X,et){if(h=et.getViewerPose(l||a),g=et,h!==null){const pt=h.views;p!==null&&(t.setRenderTargetFramebuffer(f,p.framebuffer),t.setRenderTarget(f));let bt=!1;pt.length!==v.cameras.length&&(v.cameras.length=0,bt=!0);for(let xt=0;xt<pt.length;xt++){const It=pt[xt];let Gt=null;if(p!==null)Gt=p.getViewport(It);else{const Et=d.getViewSubImage(u,It);Gt=Et.viewport,xt===0&&(t.setRenderTargetTextures(f,Et.colorTexture,u.ignoreDepthValues?void 0:Et.depthStencilTexture),t.setRenderTarget(f))}let At=I[xt];At===void 0&&(At=new Ge,At.layers.enable(xt),At.viewport=new ge,I[xt]=At),At.matrix.fromArray(It.transform.matrix),At.matrix.decompose(At.position,At.quaternion,At.scale),At.projectionMatrix.fromArray(It.projectionMatrix),At.projectionMatrixInverse.copy(At.projectionMatrix).invert(),At.viewport.set(Gt.x,Gt.y,Gt.width,Gt.height),xt===0&&(v.matrix.copy(At.matrix),v.matrix.decompose(v.position,v.quaternion,v.scale)),bt===!0&&v.cameras.push(At)}}for(let pt=0;pt<_.length;pt++){const bt=x[pt],xt=_[pt];bt!==null&&xt!==void 0&&xt.update(bt,et,l||a)}J&&J(X,et),et.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:et}),g=null}const ct=new xh;ct.setAnimationLoop(nt),this.setAnimationLoop=function(X){J=X},this.dispose=function(){}}}function hg(o,t){function e(m,f){m.matrixAutoUpdate===!0&&m.updateMatrix(),f.value.copy(m.matrix)}function n(m,f){f.color.getRGB(m.fogColor.value,gh(o)),f.isFog?(m.fogNear.value=f.near,m.fogFar.value=f.far):f.isFogExp2&&(m.fogDensity.value=f.density)}function i(m,f,_,x,M){f.isMeshBasicMaterial||f.isMeshLambertMaterial?s(m,f):f.isMeshToonMaterial?(s(m,f),d(m,f)):f.isMeshPhongMaterial?(s(m,f),h(m,f)):f.isMeshStandardMaterial?(s(m,f),u(m,f),f.isMeshPhysicalMaterial&&p(m,f,M)):f.isMeshMatcapMaterial?(s(m,f),g(m,f)):f.isMeshDepthMaterial?s(m,f):f.isMeshDistanceMaterial?(s(m,f),y(m,f)):f.isMeshNormalMaterial?s(m,f):f.isLineBasicMaterial?(a(m,f),f.isLineDashedMaterial&&r(m,f)):f.isPointsMaterial?c(m,f,_,x):f.isSpriteMaterial?l(m,f):f.isShadowMaterial?(m.color.value.copy(f.color),m.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(m,f){m.opacity.value=f.opacity,f.color&&m.diffuse.value.copy(f.color),f.emissive&&m.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(m.map.value=f.map,e(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.bumpMap&&(m.bumpMap.value=f.bumpMap,e(f.bumpMap,m.bumpMapTransform),m.bumpScale.value=f.bumpScale,f.side===He&&(m.bumpScale.value*=-1)),f.normalMap&&(m.normalMap.value=f.normalMap,e(f.normalMap,m.normalMapTransform),m.normalScale.value.copy(f.normalScale),f.side===He&&m.normalScale.value.negate()),f.displacementMap&&(m.displacementMap.value=f.displacementMap,e(f.displacementMap,m.displacementMapTransform),m.displacementScale.value=f.displacementScale,m.displacementBias.value=f.displacementBias),f.emissiveMap&&(m.emissiveMap.value=f.emissiveMap,e(f.emissiveMap,m.emissiveMapTransform)),f.specularMap&&(m.specularMap.value=f.specularMap,e(f.specularMap,m.specularMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest);const _=t.get(f).envMap;if(_&&(m.envMap.value=_,m.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=f.reflectivity,m.ior.value=f.ior,m.refractionRatio.value=f.refractionRatio),f.lightMap){m.lightMap.value=f.lightMap;const x=o._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=f.lightMapIntensity*x,e(f.lightMap,m.lightMapTransform)}f.aoMap&&(m.aoMap.value=f.aoMap,m.aoMapIntensity.value=f.aoMapIntensity,e(f.aoMap,m.aoMapTransform))}function a(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,f.map&&(m.map.value=f.map,e(f.map,m.mapTransform))}function r(m,f){m.dashSize.value=f.dashSize,m.totalSize.value=f.dashSize+f.gapSize,m.scale.value=f.scale}function c(m,f,_,x){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.size.value=f.size*_,m.scale.value=x*.5,f.map&&(m.map.value=f.map,e(f.map,m.uvTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function l(m,f){m.diffuse.value.copy(f.color),m.opacity.value=f.opacity,m.rotation.value=f.rotation,f.map&&(m.map.value=f.map,e(f.map,m.mapTransform)),f.alphaMap&&(m.alphaMap.value=f.alphaMap,e(f.alphaMap,m.alphaMapTransform)),f.alphaTest>0&&(m.alphaTest.value=f.alphaTest)}function h(m,f){m.specular.value.copy(f.specular),m.shininess.value=Math.max(f.shininess,1e-4)}function d(m,f){f.gradientMap&&(m.gradientMap.value=f.gradientMap)}function u(m,f){m.metalness.value=f.metalness,f.metalnessMap&&(m.metalnessMap.value=f.metalnessMap,e(f.metalnessMap,m.metalnessMapTransform)),m.roughness.value=f.roughness,f.roughnessMap&&(m.roughnessMap.value=f.roughnessMap,e(f.roughnessMap,m.roughnessMapTransform)),t.get(f).envMap&&(m.envMapIntensity.value=f.envMapIntensity)}function p(m,f,_){m.ior.value=f.ior,f.sheen>0&&(m.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),m.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(m.sheenColorMap.value=f.sheenColorMap,e(f.sheenColorMap,m.sheenColorMapTransform)),f.sheenRoughnessMap&&(m.sheenRoughnessMap.value=f.sheenRoughnessMap,e(f.sheenRoughnessMap,m.sheenRoughnessMapTransform))),f.clearcoat>0&&(m.clearcoat.value=f.clearcoat,m.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(m.clearcoatMap.value=f.clearcoatMap,e(f.clearcoatMap,m.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,e(f.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(m.clearcoatNormalMap.value=f.clearcoatNormalMap,e(f.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===He&&m.clearcoatNormalScale.value.negate())),f.iridescence>0&&(m.iridescence.value=f.iridescence,m.iridescenceIOR.value=f.iridescenceIOR,m.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(m.iridescenceMap.value=f.iridescenceMap,e(f.iridescenceMap,m.iridescenceMapTransform)),f.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=f.iridescenceThicknessMap,e(f.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),f.transmission>0&&(m.transmission.value=f.transmission,m.transmissionSamplerMap.value=_.texture,m.transmissionSamplerSize.value.set(_.width,_.height),f.transmissionMap&&(m.transmissionMap.value=f.transmissionMap,e(f.transmissionMap,m.transmissionMapTransform)),m.thickness.value=f.thickness,f.thicknessMap&&(m.thicknessMap.value=f.thicknessMap,e(f.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=f.attenuationDistance,m.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(m.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(m.anisotropyMap.value=f.anisotropyMap,e(f.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=f.specularIntensity,m.specularColor.value.copy(f.specularColor),f.specularColorMap&&(m.specularColorMap.value=f.specularColorMap,e(f.specularColorMap,m.specularColorMapTransform)),f.specularIntensityMap&&(m.specularIntensityMap.value=f.specularIntensityMap,e(f.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,f){f.matcap&&(m.matcap.value=f.matcap)}function y(m,f){const _=t.get(f).light;m.referencePosition.value.setFromMatrixPosition(_.matrixWorld),m.nearDistance.value=_.shadow.camera.near,m.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function dg(o,t,e,n){let i={},s={},a=[];const r=e.isWebGL2?o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(_,x){const M=x.program;n.uniformBlockBinding(_,M)}function l(_,x){let M=i[_.id];M===void 0&&(g(_),M=h(_),i[_.id]=M,_.addEventListener("dispose",m));const R=x.program;n.updateUBOMapping(_,R);const A=t.render.frame;s[_.id]!==A&&(u(_),s[_.id]=A)}function h(_){const x=d();_.__bindingPointIndex=x;const M=o.createBuffer(),R=_.__size,A=_.usage;return o.bindBuffer(o.UNIFORM_BUFFER,M),o.bufferData(o.UNIFORM_BUFFER,R,A),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,x,M),M}function d(){for(let _=0;_<r;_++)if(a.indexOf(_)===-1)return a.push(_),_;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(_){const x=i[_.id],M=_.uniforms,R=_.__cache;o.bindBuffer(o.UNIFORM_BUFFER,x);for(let A=0,E=M.length;A<E;A++){const I=Array.isArray(M[A])?M[A]:[M[A]];for(let v=0,S=I.length;v<S;v++){const P=I[v];if(p(P,A,v,R)===!0){const O=P.__offset,j=Array.isArray(P.value)?P.value:[P.value];let D=0;for(let F=0;F<j.length;F++){const z=j[F],Z=y(z);typeof z=="number"||typeof z=="boolean"?(P.__data[0]=z,o.bufferSubData(o.UNIFORM_BUFFER,O+D,P.__data)):z.isMatrix3?(P.__data[0]=z.elements[0],P.__data[1]=z.elements[1],P.__data[2]=z.elements[2],P.__data[3]=0,P.__data[4]=z.elements[3],P.__data[5]=z.elements[4],P.__data[6]=z.elements[5],P.__data[7]=0,P.__data[8]=z.elements[6],P.__data[9]=z.elements[7],P.__data[10]=z.elements[8],P.__data[11]=0):(z.toArray(P.__data,D),D+=Z.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,O,P.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function p(_,x,M,R){const A=_.value,E=x+"_"+M;if(R[E]===void 0)return typeof A=="number"||typeof A=="boolean"?R[E]=A:R[E]=A.clone(),!0;{const I=R[E];if(typeof A=="number"||typeof A=="boolean"){if(I!==A)return R[E]=A,!0}else if(I.equals(A)===!1)return I.copy(A),!0}return!1}function g(_){const x=_.uniforms;let M=0;const R=16;for(let E=0,I=x.length;E<I;E++){const v=Array.isArray(x[E])?x[E]:[x[E]];for(let S=0,P=v.length;S<P;S++){const O=v[S],j=Array.isArray(O.value)?O.value:[O.value];for(let D=0,F=j.length;D<F;D++){const z=j[D],Z=y(z),Y=M%R;Y!==0&&R-Y<Z.boundary&&(M+=R-Y),O.__data=new Float32Array(Z.storage/Float32Array.BYTES_PER_ELEMENT),O.__offset=M,M+=Z.storage}}}const A=M%R;return A>0&&(M+=R-A),_.__size=M,_.__cache={},this}function y(_){const x={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(x.boundary=4,x.storage=4):_.isVector2?(x.boundary=8,x.storage=8):_.isVector3||_.isColor?(x.boundary=16,x.storage=12):_.isVector4?(x.boundary=16,x.storage=16):_.isMatrix3?(x.boundary=48,x.storage=48):_.isMatrix4?(x.boundary=64,x.storage=64):_.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",_),x}function m(_){const x=_.target;x.removeEventListener("dispose",m);const M=a.indexOf(x.__bindingPointIndex);a.splice(M,1),o.deleteBuffer(i[x.id]),delete i[x.id],delete s[x.id]}function f(){for(const _ in i)o.deleteBuffer(i[_]);a=[],i={},s={}}return{bind:c,update:l,dispose:f}}class Ah{constructor(t={}){const{canvas:e=au(),context:n=null,depth:i=!0,stencil:s=!0,alpha:a=!1,antialias:r=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1}=t;this.isWebGLRenderer=!0;let u;n!==null?u=n.getContextAttributes().alpha:u=a;const p=new Uint32Array(4),g=new Int32Array(4);let y=null,m=null;const f=[],_=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=Pe,this._useLegacyLights=!1,this.toneMapping=Xn,this.toneMappingExposure=1;const x=this;let M=!1,R=0,A=0,E=null,I=-1,v=null;const S=new ge,P=new ge;let O=null;const j=new Vt(0);let D=0,F=e.width,z=e.height,Z=1,Y=null,q=null;const J=new ge(0,0,F,z),nt=new ge(0,0,F,z);let ct=!1;const X=new Pr;let et=!1,pt=!1,bt=null;const xt=new we,It=new dt,Gt=new L,At={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function Et(){return E===null?Z:1}let N=n;function ht(C,G){for(let H=0;H<C.length;H++){const $=C[H],W=e.getContext($,G);if(W!==null)return W}return null}try{const C={alpha:!0,depth:i,stencil:s,antialias:r,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Er}`),e.addEventListener("webglcontextlost",ut,!1),e.addEventListener("webglcontextrestored",B,!1),e.addEventListener("webglcontextcreationerror",mt,!1),N===null){const G=["webgl2","webgl","experimental-webgl"];if(x.isWebGL1Renderer===!0&&G.shift(),N=ht(G,C),N===null)throw ht(G)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&N instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),N.getShaderPrecisionFormat===void 0&&(N.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(C){throw console.error("THREE.WebGLRenderer: "+C.message),C}let tt,lt,Q,Lt,ft,T,b,k,it,at,st,St,wt,Mt,Pt,Ut,rt,Jt,qt,Ht,Dt,Tt,Yt,ee;function pe(){tt=new _0(N),lt=new m0(N,tt,t),tt.init(lt),Tt=new ag(N,tt,lt),Q=new sg(N,tt,lt),Lt=new b0(N),ft=new Wm,T=new og(N,tt,Q,ft,lt,Tt,Lt),b=new w0(x),k=new v0(x),it=new Pu(N,lt),Yt=new p0(N,tt,it,lt),at=new M0(N,it,Lt,Yt),st=new C0(N,at,it,Lt),qt=new A0(N,lt,T),Ut=new g0(ft),St=new Vm(x,b,k,tt,lt,Yt,Ut),wt=new hg(x,ft),Mt=new qm,Pt=new Jm(tt,lt),Jt=new u0(x,b,k,Q,st,u,c),rt=new ig(x,st,lt),ee=new dg(N,Lt,lt,Q),Ht=new f0(N,tt,Lt,lt),Dt=new S0(N,tt,Lt,lt),Lt.programs=St.programs,x.capabilities=lt,x.extensions=tt,x.properties=ft,x.renderLists=Mt,x.shadowMap=rt,x.state=Q,x.info=Lt}pe();const jt=new lg(x,N);this.xr=jt,this.getContext=function(){return N},this.getContextAttributes=function(){return N.getContextAttributes()},this.forceContextLoss=function(){const C=tt.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=tt.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return Z},this.setPixelRatio=function(C){C!==void 0&&(Z=C,this.setSize(F,z,!1))},this.getSize=function(C){return C.set(F,z)},this.setSize=function(C,G,H=!0){if(jt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}F=C,z=G,e.width=Math.floor(C*Z),e.height=Math.floor(G*Z),H===!0&&(e.style.width=C+"px",e.style.height=G+"px"),this.setViewport(0,0,C,G)},this.getDrawingBufferSize=function(C){return C.set(F*Z,z*Z).floor()},this.setDrawingBufferSize=function(C,G,H){F=C,z=G,Z=H,e.width=Math.floor(C*H),e.height=Math.floor(G*H),this.setViewport(0,0,C,G)},this.getCurrentViewport=function(C){return C.copy(S)},this.getViewport=function(C){return C.copy(J)},this.setViewport=function(C,G,H,$){C.isVector4?J.set(C.x,C.y,C.z,C.w):J.set(C,G,H,$),Q.viewport(S.copy(J).multiplyScalar(Z).floor())},this.getScissor=function(C){return C.copy(nt)},this.setScissor=function(C,G,H,$){C.isVector4?nt.set(C.x,C.y,C.z,C.w):nt.set(C,G,H,$),Q.scissor(P.copy(nt).multiplyScalar(Z).floor())},this.getScissorTest=function(){return ct},this.setScissorTest=function(C){Q.setScissorTest(ct=C)},this.setOpaqueSort=function(C){Y=C},this.setTransparentSort=function(C){q=C},this.getClearColor=function(C){return C.copy(Jt.getClearColor())},this.setClearColor=function(){Jt.setClearColor.apply(Jt,arguments)},this.getClearAlpha=function(){return Jt.getClearAlpha()},this.setClearAlpha=function(){Jt.setClearAlpha.apply(Jt,arguments)},this.clear=function(C=!0,G=!0,H=!0){let $=0;if(C){let W=!1;if(E!==null){const vt=E.texture.format;W=vt===sh||vt===ih||vt===nh}if(W){const vt=E.texture.type,Ct=vt===qn||vt===Gn||vt===Cr||vt===ui||vt===th||vt===eh,Nt=Jt.getClearColor(),zt=Jt.getClearAlpha(),Xt=Nt.r,Ot=Nt.g,kt=Nt.b;Ct?(p[0]=Xt,p[1]=Ot,p[2]=kt,p[3]=zt,N.clearBufferuiv(N.COLOR,0,p)):(g[0]=Xt,g[1]=Ot,g[2]=kt,g[3]=zt,N.clearBufferiv(N.COLOR,0,g))}else $|=N.COLOR_BUFFER_BIT}G&&($|=N.DEPTH_BUFFER_BIT),H&&($|=N.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),N.clear($)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",ut,!1),e.removeEventListener("webglcontextrestored",B,!1),e.removeEventListener("webglcontextcreationerror",mt,!1),Mt.dispose(),Pt.dispose(),ft.dispose(),b.dispose(),k.dispose(),st.dispose(),Yt.dispose(),ee.dispose(),St.dispose(),jt.dispose(),jt.removeEventListener("sessionstart",Se),jt.removeEventListener("sessionend",se),bt&&(bt.dispose(),bt=null),Re.stop()};function ut(C){C.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),M=!0}function B(){console.log("THREE.WebGLRenderer: Context Restored."),M=!1;const C=Lt.autoReset,G=rt.enabled,H=rt.autoUpdate,$=rt.needsUpdate,W=rt.type;pe(),Lt.autoReset=C,rt.enabled=G,rt.autoUpdate=H,rt.needsUpdate=$,rt.type=W}function mt(C){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function yt(C){const G=C.target;G.removeEventListener("dispose",yt),Ft(G)}function Ft(C){Bt(C),ft.remove(C)}function Bt(C){const G=ft.get(C).programs;G!==void 0&&(G.forEach(function(H){St.releaseProgram(H)}),C.isShaderMaterial&&St.releaseShaderCache(C))}this.renderBufferDirect=function(C,G,H,$,W,vt){G===null&&(G=At);const Ct=W.isMesh&&W.matrixWorld.determinant()<0,Nt=fs(C,G,H,$,W);Q.setMaterial($,Ct);let zt=H.index,Xt=1;if($.wireframe===!0){if(zt=at.getWireframeAttribute(H),zt===void 0)return;Xt=2}const Ot=H.drawRange,kt=H.attributes.position;let fe=Ot.start*Xt,Ie=(Ot.start+Ot.count)*Xt;vt!==null&&(fe=Math.max(fe,vt.start*Xt),Ie=Math.min(Ie,(vt.start+vt.count)*Xt)),zt!==null?(fe=Math.max(fe,0),Ie=Math.min(Ie,zt.count)):kt!=null&&(fe=Math.max(fe,0),Ie=Math.min(Ie,kt.count));const ce=Ie-fe;if(ce<0||ce===1/0)return;Yt.setup(W,$,Nt,H,zt);let Xe,le=Ht;if(zt!==null&&(Xe=it.get(zt),le=Dt,le.setIndex(Xe)),W.isMesh)$.wireframe===!0?(Q.setLineWidth($.wireframeLinewidth*Et()),le.setMode(N.LINES)):le.setMode(N.TRIANGLES);else if(W.isLine){let $t=$.linewidth;$t===void 0&&($t=1),Q.setLineWidth($t*Et()),W.isLineSegments?le.setMode(N.LINES):W.isLineLoop?le.setMode(N.LINE_LOOP):le.setMode(N.LINE_STRIP)}else W.isPoints?le.setMode(N.POINTS):W.isSprite&&le.setMode(N.TRIANGLES);if(W.isBatchedMesh)le.renderMultiDraw(W._multiDrawStarts,W._multiDrawCounts,W._multiDrawCount);else if(W.isInstancedMesh)le.renderInstances(fe,ce,W.count);else if(H.isInstancedBufferGeometry){const $t=H._maxInstanceCount!==void 0?H._maxInstanceCount:1/0,jn=Math.min(H.instanceCount,$t);le.renderInstances(fe,ce,jn)}else le.render(fe,ce)};function ne(C,G,H){C.transparent===!0&&C.side===me&&C.forceSinglePass===!1?(C.side=He,C.needsUpdate=!0,xn(C,G,H),C.side=Yn,C.needsUpdate=!0,xn(C,G,H),C.side=me):xn(C,G,H)}this.compile=function(C,G,H=null){H===null&&(H=C),m=Pt.get(H),m.init(),_.push(m),H.traverseVisible(function(W){W.isLight&&W.layers.test(G.layers)&&(m.pushLight(W),W.castShadow&&m.pushShadow(W))}),C!==H&&C.traverseVisible(function(W){W.isLight&&W.layers.test(G.layers)&&(m.pushLight(W),W.castShadow&&m.pushShadow(W))}),m.setupLights(x._useLegacyLights);const $=new Set;return C.traverse(function(W){const vt=W.material;if(vt)if(Array.isArray(vt))for(let Ct=0;Ct<vt.length;Ct++){const Nt=vt[Ct];ne(Nt,H,W),$.add(Nt)}else ne(vt,H,W),$.add(vt)}),_.pop(),m=null,$},this.compileAsync=function(C,G,H=null){const $=this.compile(C,G,H);return new Promise(W=>{function vt(){if($.forEach(function(Ct){ft.get(Ct).currentProgram.isReady()&&$.delete(Ct)}),$.size===0){W(C);return}setTimeout(vt,10)}tt.get("KHR_parallel_shader_compile")!==null?vt():setTimeout(vt,10)})};let ie=null;function Me(C){ie&&ie(C)}function Se(){Re.stop()}function se(){Re.start()}const Re=new xh;Re.setAnimationLoop(Me),typeof self<"u"&&Re.setContext(self),this.setAnimationLoop=function(C){ie=C,jt.setAnimationLoop(C),C===null?Re.stop():Re.start()},jt.addEventListener("sessionstart",Se),jt.addEventListener("sessionend",se),this.render=function(C,G){if(G!==void 0&&G.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(M===!0)return;C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),G.parent===null&&G.matrixWorldAutoUpdate===!0&&G.updateMatrixWorld(),jt.enabled===!0&&jt.isPresenting===!0&&(jt.cameraAutoUpdate===!0&&jt.updateCamera(G),G=jt.getCamera()),C.isScene===!0&&C.onBeforeRender(x,C,G,E),m=Pt.get(C,_.length),m.init(),_.push(m),xt.multiplyMatrices(G.projectionMatrix,G.matrixWorldInverse),X.setFromProjectionMatrix(xt),pt=this.localClippingEnabled,et=Ut.init(this.clippingPlanes,pt),y=Mt.get(C,f.length),y.init(),f.push(y),We(C,G,0,x.sortObjects),y.finish(),x.sortObjects===!0&&y.sort(Y,q),this.info.render.frame++,et===!0&&Ut.beginShadows();const H=m.state.shadowsArray;if(rt.render(H,C,G),et===!0&&Ut.endShadows(),this.info.autoReset===!0&&this.info.reset(),Jt.render(y,C),m.setupLights(x._useLegacyLights),G.isArrayCamera){const $=G.cameras;for(let W=0,vt=$.length;W<vt;W++){const Ct=$[W];ps(y,C,Ct,Ct.viewport)}}else ps(y,C,G);E!==null&&(T.updateMultisampleRenderTarget(E),T.updateRenderTargetMipmap(E)),C.isScene===!0&&C.onAfterRender(x,C,G),Yt.resetDefaultState(),I=-1,v=null,_.pop(),_.length>0?m=_[_.length-1]:m=null,f.pop(),f.length>0?y=f[f.length-1]:y=null};function We(C,G,H,$){if(C.visible===!1)return;if(C.layers.test(G.layers)){if(C.isGroup)H=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(G);else if(C.isLight)m.pushLight(C),C.castShadow&&m.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||X.intersectsSprite(C)){$&&Gt.setFromMatrixPosition(C.matrixWorld).applyMatrix4(xt);const Ct=st.update(C),Nt=C.material;Nt.visible&&y.push(C,Ct,Nt,H,Gt.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||X.intersectsObject(C))){const Ct=st.update(C),Nt=C.material;if($&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),Gt.copy(C.boundingSphere.center)):(Ct.boundingSphere===null&&Ct.computeBoundingSphere(),Gt.copy(Ct.boundingSphere.center)),Gt.applyMatrix4(C.matrixWorld).applyMatrix4(xt)),Array.isArray(Nt)){const zt=Ct.groups;for(let Xt=0,Ot=zt.length;Xt<Ot;Xt++){const kt=zt[Xt],fe=Nt[kt.materialIndex];fe&&fe.visible&&y.push(C,Ct,fe,H,Gt.z,kt)}}else Nt.visible&&y.push(C,Ct,Nt,H,Gt.z,null)}}const vt=C.children;for(let Ct=0,Nt=vt.length;Ct<Nt;Ct++)We(vt[Ct],G,H,$)}function ps(C,G,H,$){const W=C.opaque,vt=C.transmissive,Ct=C.transparent;m.setupLightsView(H),et===!0&&Ut.setGlobalState(x.clippingPlanes,H),vt.length>0&&Zn(W,vt,G,H),$&&Q.viewport(S.copy($)),W.length>0&&dn(W,G,H),vt.length>0&&dn(vt,G,H),Ct.length>0&&dn(Ct,G,H),Q.buffers.depth.setTest(!0),Q.buffers.depth.setMask(!0),Q.buffers.color.setMask(!0),Q.setPolygonOffset(!1)}function Zn(C,G,H,$){if((H.isScene===!0?H.overrideMaterial:null)!==null)return;const vt=lt.isWebGL2;bt===null&&(bt=new mi(1,1,{generateMipmaps:!0,type:tt.has("EXT_color_buffer_half_float")?Ns:qn,minFilter:Us,samples:vt?4:0})),x.getDrawingBufferSize(It),vt?bt.setSize(It.x,It.y):bt.setSize(xr(It.x),xr(It.y));const Ct=x.getRenderTarget();x.setRenderTarget(bt),x.getClearColor(j),D=x.getClearAlpha(),D<1&&x.setClearColor(16777215,.5),x.clear();const Nt=x.toneMapping;x.toneMapping=Xn,dn(C,H,$),T.updateMultisampleRenderTarget(bt),T.updateRenderTargetMipmap(bt);let zt=!1;for(let Xt=0,Ot=G.length;Xt<Ot;Xt++){const kt=G[Xt],fe=kt.object,Ie=kt.geometry,ce=kt.material,Xe=kt.group;if(ce.side===me&&fe.layers.test($.layers)){const le=ce.side;ce.side=He,ce.needsUpdate=!0,un(fe,H,$,Ie,ce,Xe),ce.side=le,ce.needsUpdate=!0,zt=!0}}zt===!0&&(T.updateMultisampleRenderTarget(bt),T.updateRenderTargetMipmap(bt)),x.setRenderTarget(Ct),x.setClearColor(j,D),x.toneMapping=Nt}function dn(C,G,H){const $=G.isScene===!0?G.overrideMaterial:null;for(let W=0,vt=C.length;W<vt;W++){const Ct=C[W],Nt=Ct.object,zt=Ct.geometry,Xt=$===null?Ct.material:$,Ot=Ct.group;Nt.layers.test(H.layers)&&un(Nt,G,H,zt,Xt,Ot)}}function un(C,G,H,$,W,vt){C.onBeforeRender(x,G,H,$,W,vt),C.modelViewMatrix.multiplyMatrices(H.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),W.onBeforeRender(x,G,H,$,C,vt),W.transparent===!0&&W.side===me&&W.forceSinglePass===!1?(W.side=He,W.needsUpdate=!0,x.renderBufferDirect(H,G,$,W,C,vt),W.side=Yn,W.needsUpdate=!0,x.renderBufferDirect(H,G,$,W,C,vt),W.side=me):x.renderBufferDirect(H,G,$,W,C,vt),C.onAfterRender(x,G,H,$,W,vt)}function xn(C,G,H){G.isScene!==!0&&(G=At);const $=ft.get(C),W=m.state.lights,vt=m.state.shadowsArray,Ct=W.state.version,Nt=St.getParameters(C,W.state,vt,G,H),zt=St.getProgramCacheKey(Nt);let Xt=$.programs;$.environment=C.isMeshStandardMaterial?G.environment:null,$.fog=G.fog,$.envMap=(C.isMeshStandardMaterial?k:b).get(C.envMap||$.environment),Xt===void 0&&(C.addEventListener("dispose",yt),Xt=new Map,$.programs=Xt);let Ot=Xt.get(zt);if(Ot!==void 0){if($.currentProgram===Ot&&$.lightsStateVersion===Ct)return xi(C,Nt),Ot}else Nt.uniforms=St.getUniforms(C),C.onBuild(H,Nt,x),C.onBeforeCompile(Nt,x),Ot=St.acquireProgram(Nt,zt),Xt.set(zt,Ot),$.uniforms=Nt.uniforms;const kt=$.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(kt.clippingPlanes=Ut.uniform),xi(C,Nt),$.needsLights=ca(C),$.lightsStateVersion=Ct,$.needsLights&&(kt.ambientLightColor.value=W.state.ambient,kt.lightProbe.value=W.state.probe,kt.directionalLights.value=W.state.directional,kt.directionalLightShadows.value=W.state.directionalShadow,kt.spotLights.value=W.state.spot,kt.spotLightShadows.value=W.state.spotShadow,kt.rectAreaLights.value=W.state.rectArea,kt.ltc_1.value=W.state.rectAreaLTC1,kt.ltc_2.value=W.state.rectAreaLTC2,kt.pointLights.value=W.state.point,kt.pointLightShadows.value=W.state.pointShadow,kt.hemisphereLights.value=W.state.hemi,kt.directionalShadowMap.value=W.state.directionalShadowMap,kt.directionalShadowMatrix.value=W.state.directionalShadowMatrix,kt.spotShadowMap.value=W.state.spotShadowMap,kt.spotLightMatrix.value=W.state.spotLightMatrix,kt.spotLightMap.value=W.state.spotLightMap,kt.pointShadowMap.value=W.state.pointShadowMap,kt.pointShadowMatrix.value=W.state.pointShadowMatrix),$.currentProgram=Ot,$.uniformsList=null,Ot}function yi(C){if(C.uniformsList===null){const G=C.currentProgram.getUniforms();C.uniformsList=Ho.seqWithValue(G.seq,C.uniforms)}return C.uniformsList}function xi(C,G){const H=ft.get(C);H.outputColorSpace=G.outputColorSpace,H.batching=G.batching,H.instancing=G.instancing,H.instancingColor=G.instancingColor,H.skinning=G.skinning,H.morphTargets=G.morphTargets,H.morphNormals=G.morphNormals,H.morphColors=G.morphColors,H.morphTargetsCount=G.morphTargetsCount,H.numClippingPlanes=G.numClippingPlanes,H.numIntersection=G.numClipIntersection,H.vertexAlphas=G.vertexAlphas,H.vertexTangents=G.vertexTangents,H.toneMapping=G.toneMapping}function fs(C,G,H,$,W){G.isScene!==!0&&(G=At),T.resetTextureUnits();const vt=G.fog,Ct=$.isMeshStandardMaterial?G.environment:null,Nt=E===null?x.outputColorSpace:E.isXRRenderTarget===!0?E.texture.colorSpace:Un,zt=($.isMeshStandardMaterial?k:b).get($.envMap||Ct),Xt=$.vertexColors===!0&&!!H.attributes.color&&H.attributes.color.itemSize===4,Ot=!!H.attributes.tangent&&(!!$.normalMap||$.anisotropy>0),kt=!!H.morphAttributes.position,fe=!!H.morphAttributes.normal,Ie=!!H.morphAttributes.color;let ce=Xn;$.toneMapped&&(E===null||E.isXRRenderTarget===!0)&&(ce=x.toneMapping);const Xe=H.morphAttributes.position||H.morphAttributes.normal||H.morphAttributes.color,le=Xe!==void 0?Xe.length:0,$t=ft.get($),jn=m.state.lights;if(et===!0&&(pt===!0||C!==v)){const Be=C===v&&$.id===I;Ut.setState($,C,Be)}let ae=!1;$.version===$t.__version?($t.needsLights&&$t.lightsStateVersion!==jn.state.version||$t.outputColorSpace!==Nt||W.isBatchedMesh&&$t.batching===!1||!W.isBatchedMesh&&$t.batching===!0||W.isInstancedMesh&&$t.instancing===!1||!W.isInstancedMesh&&$t.instancing===!0||W.isSkinnedMesh&&$t.skinning===!1||!W.isSkinnedMesh&&$t.skinning===!0||W.isInstancedMesh&&$t.instancingColor===!0&&W.instanceColor===null||W.isInstancedMesh&&$t.instancingColor===!1&&W.instanceColor!==null||$t.envMap!==zt||$.fog===!0&&$t.fog!==vt||$t.numClippingPlanes!==void 0&&($t.numClippingPlanes!==Ut.numPlanes||$t.numIntersection!==Ut.numIntersection)||$t.vertexAlphas!==Xt||$t.vertexTangents!==Ot||$t.morphTargets!==kt||$t.morphNormals!==fe||$t.morphColors!==Ie||$t.toneMapping!==ce||lt.isWebGL2===!0&&$t.morphTargetsCount!==le)&&(ae=!0):(ae=!0,$t.__version=$.version);let je=$t.currentProgram;ae===!0&&(je=xn($,G,W));let Kn=!1,Nn=!1,pn=!1;const be=je.getUniforms(),on=$t.uniforms;if(Q.useProgram(je.program)&&(Kn=!0,Nn=!0,pn=!0),$.id!==I&&(I=$.id,Nn=!0),Kn||v!==C){be.setValue(N,"projectionMatrix",C.projectionMatrix),be.setValue(N,"viewMatrix",C.matrixWorldInverse);const Be=be.map.cameraPosition;Be!==void 0&&Be.setValue(N,Gt.setFromMatrixPosition(C.matrixWorld)),lt.logarithmicDepthBuffer&&be.setValue(N,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),($.isMeshPhongMaterial||$.isMeshToonMaterial||$.isMeshLambertMaterial||$.isMeshBasicMaterial||$.isMeshStandardMaterial||$.isShaderMaterial)&&be.setValue(N,"isOrthographic",C.isOrthographicCamera===!0),v!==C&&(v=C,Nn=!0,pn=!0)}if(W.isSkinnedMesh){be.setOptional(N,W,"bindMatrix"),be.setOptional(N,W,"bindMatrixInverse");const Be=W.skeleton;Be&&(lt.floatVertexTextures?(Be.boneTexture===null&&Be.computeBoneTexture(),be.setValue(N,"boneTexture",Be.boneTexture,T)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}W.isBatchedMesh&&(be.setOptional(N,W,"batchingTexture"),be.setValue(N,"batchingTexture",W._matricesTexture,T));const Jn=H.morphAttributes;if((Jn.position!==void 0||Jn.normal!==void 0||Jn.color!==void 0&&lt.isWebGL2===!0)&&qt.update(W,H,je),(Nn||$t.receiveShadow!==W.receiveShadow)&&($t.receiveShadow=W.receiveShadow,be.setValue(N,"receiveShadow",W.receiveShadow)),$.isMeshGouraudMaterial&&$.envMap!==null&&(on.envMap.value=zt,on.flipEnvMap.value=zt.isCubeTexture&&zt.isRenderTargetTexture===!1?-1:1),Nn&&(be.setValue(N,"toneMappingExposure",x.toneMappingExposure),$t.needsLights&&ra(on,pn),vt&&$.fog===!0&&wt.refreshFogUniforms(on,vt),wt.refreshMaterialUniforms(on,$,Z,z,bt),Ho.upload(N,yi($t),on,T)),$.isShaderMaterial&&$.uniformsNeedUpdate===!0&&(Ho.upload(N,yi($t),on,T),$.uniformsNeedUpdate=!1),$.isSpriteMaterial&&be.setValue(N,"center",W.center),be.setValue(N,"modelViewMatrix",W.modelViewMatrix),be.setValue(N,"normalMatrix",W.normalMatrix),be.setValue(N,"modelMatrix",W.matrixWorld),$.isShaderMaterial||$.isRawShaderMaterial){const Be=$.uniformsGroups;for(let ms=0,vi=Be.length;ms<vi;ms++)if(lt.isWebGL2){const _i=Be[ms];ee.update(_i,je),ee.bind(_i,je)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return je}function ra(C,G){C.ambientLightColor.needsUpdate=G,C.lightProbe.needsUpdate=G,C.directionalLights.needsUpdate=G,C.directionalLightShadows.needsUpdate=G,C.pointLights.needsUpdate=G,C.pointLightShadows.needsUpdate=G,C.spotLights.needsUpdate=G,C.spotLightShadows.needsUpdate=G,C.rectAreaLights.needsUpdate=G,C.hemisphereLights.needsUpdate=G}function ca(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return E},this.setRenderTargetTextures=function(C,G,H){ft.get(C.texture).__webglTexture=G,ft.get(C.depthTexture).__webglTexture=H;const $=ft.get(C);$.__hasExternalTextures=!0,$.__hasExternalTextures&&($.__autoAllocateDepthBuffer=H===void 0,$.__autoAllocateDepthBuffer||tt.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),$.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(C,G){const H=ft.get(C);H.__webglFramebuffer=G,H.__useDefaultFramebuffer=G===void 0},this.setRenderTarget=function(C,G=0,H=0){E=C,R=G,A=H;let $=!0,W=null,vt=!1,Ct=!1;if(C){const zt=ft.get(C);zt.__useDefaultFramebuffer!==void 0?(Q.bindFramebuffer(N.FRAMEBUFFER,null),$=!1):zt.__webglFramebuffer===void 0?T.setupRenderTarget(C):zt.__hasExternalTextures&&T.rebindTextures(C,ft.get(C.texture).__webglTexture,ft.get(C.depthTexture).__webglTexture);const Xt=C.texture;(Xt.isData3DTexture||Xt.isDataArrayTexture||Xt.isCompressedArrayTexture)&&(Ct=!0);const Ot=ft.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(Ot[G])?W=Ot[G][H]:W=Ot[G],vt=!0):lt.isWebGL2&&C.samples>0&&T.useMultisampledRTT(C)===!1?W=ft.get(C).__webglMultisampledFramebuffer:Array.isArray(Ot)?W=Ot[H]:W=Ot,S.copy(C.viewport),P.copy(C.scissor),O=C.scissorTest}else S.copy(J).multiplyScalar(Z).floor(),P.copy(nt).multiplyScalar(Z).floor(),O=ct;if(Q.bindFramebuffer(N.FRAMEBUFFER,W)&&lt.drawBuffers&&$&&Q.drawBuffers(C,W),Q.viewport(S),Q.scissor(P),Q.setScissorTest(O),vt){const zt=ft.get(C.texture);N.framebufferTexture2D(N.FRAMEBUFFER,N.COLOR_ATTACHMENT0,N.TEXTURE_CUBE_MAP_POSITIVE_X+G,zt.__webglTexture,H)}else if(Ct){const zt=ft.get(C.texture),Xt=G||0;N.framebufferTextureLayer(N.FRAMEBUFFER,N.COLOR_ATTACHMENT0,zt.__webglTexture,H||0,Xt)}I=-1},this.readRenderTargetPixels=function(C,G,H,$,W,vt,Ct){if(!(C&&C.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Nt=ft.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Ct!==void 0&&(Nt=Nt[Ct]),Nt){Q.bindFramebuffer(N.FRAMEBUFFER,Nt);try{const zt=C.texture,Xt=zt.format,Ot=zt.type;if(Xt!==hn&&Tt.convert(Xt)!==N.getParameter(N.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const kt=Ot===Ns&&(tt.has("EXT_color_buffer_half_float")||lt.isWebGL2&&tt.has("EXT_color_buffer_float"));if(Ot!==qn&&Tt.convert(Ot)!==N.getParameter(N.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Ot===Hn&&(lt.isWebGL2||tt.has("OES_texture_float")||tt.has("WEBGL_color_buffer_float")))&&!kt){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}G>=0&&G<=C.width-$&&H>=0&&H<=C.height-W&&N.readPixels(G,H,$,W,Tt.convert(Xt),Tt.convert(Ot),vt)}finally{const zt=E!==null?ft.get(E).__webglFramebuffer:null;Q.bindFramebuffer(N.FRAMEBUFFER,zt)}}},this.copyFramebufferToTexture=function(C,G,H=0){const $=Math.pow(2,-H),W=Math.floor(G.image.width*$),vt=Math.floor(G.image.height*$);T.setTexture2D(G,0),N.copyTexSubImage2D(N.TEXTURE_2D,H,0,0,C.x,C.y,W,vt),Q.unbindTexture()},this.copyTextureToTexture=function(C,G,H,$=0){const W=G.image.width,vt=G.image.height,Ct=Tt.convert(H.format),Nt=Tt.convert(H.type);T.setTexture2D(H,0),N.pixelStorei(N.UNPACK_FLIP_Y_WEBGL,H.flipY),N.pixelStorei(N.UNPACK_PREMULTIPLY_ALPHA_WEBGL,H.premultiplyAlpha),N.pixelStorei(N.UNPACK_ALIGNMENT,H.unpackAlignment),G.isDataTexture?N.texSubImage2D(N.TEXTURE_2D,$,C.x,C.y,W,vt,Ct,Nt,G.image.data):G.isCompressedTexture?N.compressedTexSubImage2D(N.TEXTURE_2D,$,C.x,C.y,G.mipmaps[0].width,G.mipmaps[0].height,Ct,G.mipmaps[0].data):N.texSubImage2D(N.TEXTURE_2D,$,C.x,C.y,Ct,Nt,G.image),$===0&&H.generateMipmaps&&N.generateMipmap(N.TEXTURE_2D),Q.unbindTexture()},this.copyTextureToTexture3D=function(C,G,H,$,W=0){if(x.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const vt=C.max.x-C.min.x+1,Ct=C.max.y-C.min.y+1,Nt=C.max.z-C.min.z+1,zt=Tt.convert($.format),Xt=Tt.convert($.type);let Ot;if($.isData3DTexture)T.setTexture3D($,0),Ot=N.TEXTURE_3D;else if($.isDataArrayTexture||$.isCompressedArrayTexture)T.setTexture2DArray($,0),Ot=N.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}N.pixelStorei(N.UNPACK_FLIP_Y_WEBGL,$.flipY),N.pixelStorei(N.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),N.pixelStorei(N.UNPACK_ALIGNMENT,$.unpackAlignment);const kt=N.getParameter(N.UNPACK_ROW_LENGTH),fe=N.getParameter(N.UNPACK_IMAGE_HEIGHT),Ie=N.getParameter(N.UNPACK_SKIP_PIXELS),ce=N.getParameter(N.UNPACK_SKIP_ROWS),Xe=N.getParameter(N.UNPACK_SKIP_IMAGES),le=H.isCompressedTexture?H.mipmaps[W]:H.image;N.pixelStorei(N.UNPACK_ROW_LENGTH,le.width),N.pixelStorei(N.UNPACK_IMAGE_HEIGHT,le.height),N.pixelStorei(N.UNPACK_SKIP_PIXELS,C.min.x),N.pixelStorei(N.UNPACK_SKIP_ROWS,C.min.y),N.pixelStorei(N.UNPACK_SKIP_IMAGES,C.min.z),H.isDataTexture||H.isData3DTexture?N.texSubImage3D(Ot,W,G.x,G.y,G.z,vt,Ct,Nt,zt,Xt,le.data):H.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),N.compressedTexSubImage3D(Ot,W,G.x,G.y,G.z,vt,Ct,Nt,zt,le.data)):N.texSubImage3D(Ot,W,G.x,G.y,G.z,vt,Ct,Nt,zt,Xt,le),N.pixelStorei(N.UNPACK_ROW_LENGTH,kt),N.pixelStorei(N.UNPACK_IMAGE_HEIGHT,fe),N.pixelStorei(N.UNPACK_SKIP_PIXELS,Ie),N.pixelStorei(N.UNPACK_SKIP_ROWS,ce),N.pixelStorei(N.UNPACK_SKIP_IMAGES,Xe),W===0&&$.generateMipmaps&&N.generateMipmap(Ot),Q.unbindTexture()},this.initTexture=function(C){C.isCubeTexture?T.setTextureCube(C,0):C.isData3DTexture?T.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?T.setTexture2DArray(C,0):T.setTexture2D(C,0),Q.unbindTexture()},this.resetState=function(){R=0,A=0,E=null,Q.reset(),Yt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return In}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=t===Rr?"display-p3":"srgb",e.unpackColorSpace=re.workingColorSpace===ea?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===Pe?fi:ah}set outputEncoding(t){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=t===fi?Pe:Un}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(t){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=t}}class ug extends Ah{}ug.prototype.isWebGL1Renderer=!0;class Dr{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new Vt(t),this.density=e}clone(){return new Dr(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class pg extends _e{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e}}class fg{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=wr,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=Dn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let i=0,s=this.stride;i<s;i++)this.array[t+i]=e.array[n+i];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Dn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Dn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Fe=new L;class Ko{constructor(t,e,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)Fe.fromBufferAttribute(this,e),Fe.applyMatrix4(t),this.setXYZ(e,Fe.x,Fe.y,Fe.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Fe.fromBufferAttribute(this,e),Fe.applyNormalMatrix(t),this.setXYZ(e,Fe.x,Fe.y,Fe.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Fe.fromBufferAttribute(this,e),Fe.transformDirection(t),this.setXYZ(e,Fe.x,Fe.y,Fe.z);return this}setX(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=he(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=Ln(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=Ln(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=Ln(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=Ln(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=he(e,this.array),n=he(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=he(e,this.array),n=he(n,this.array),i=he(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this}setXYZW(t,e,n,i,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=he(e,this.array),n=he(n,this.array),i=he(i,this.array),s=he(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this.data.array[t+3]=s,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[i+s])}return new sn(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new Ko(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)e.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Ch extends $n{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Vt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let ji;const Es=new L,Ki=new L,Ji=new L,Qi=new dt,Ts=new dt,Rh=new we,Do=new L,As=new L,Uo=new L,Pl=new dt,sr=new dt,Il=new dt;class mg extends _e{constructor(t=new Ch){if(super(),this.isSprite=!0,this.type="Sprite",ji===void 0){ji=new Te;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new fg(e,5);ji.setIndex([0,1,2,0,2,3]),ji.setAttribute("position",new Ko(n,3,0,!1)),ji.setAttribute("uv",new Ko(n,2,3,!1))}this.geometry=ji,this.material=t,this.center=new dt(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ki.setFromMatrixScale(this.matrixWorld),Rh.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),Ji.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ki.multiplyScalar(-Ji.z);const n=this.material.rotation;let i,s;n!==0&&(s=Math.cos(n),i=Math.sin(n));const a=this.center;No(Do.set(-.5,-.5,0),Ji,a,Ki,i,s),No(As.set(.5,-.5,0),Ji,a,Ki,i,s),No(Uo.set(.5,.5,0),Ji,a,Ki,i,s),Pl.set(0,0),sr.set(1,0),Il.set(1,1);let r=t.ray.intersectTriangle(Do,As,Uo,!1,Es);if(r===null&&(No(As.set(-.5,.5,0),Ji,a,Ki,i,s),sr.set(0,1),r=t.ray.intersectTriangle(Do,Uo,As,!1,Es),r===null))return;const c=t.ray.origin.distanceTo(Es);c<t.near||c>t.far||e.push({distance:c,point:Es.clone(),uv:en.getInterpolation(Es,Do,As,Uo,Pl,sr,Il,new dt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}}function No(o,t,e,n,i,s){Qi.subVectors(o,e).addScalar(.5).multiply(n),i!==void 0?(Ts.x=s*Qi.x-i*Qi.y,Ts.y=i*Qi.x+s*Qi.y):Ts.copy(Qi),o.copy(t),o.x+=Ts.x,o.y+=Ts.y,o.applyMatrix4(Rh)}class Lh extends $n{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Vt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const Dl=new L,Ul=new L,Nl=new we,or=new na,Bo=new Hs;class gg extends _e{constructor(t=new Te,e=new Lh){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let i=1,s=e.count;i<s;i++)Dl.fromBufferAttribute(e,i-1),Ul.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=Dl.distanceTo(Ul);t.setAttribute("lineDistance",new te(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Bo.copy(n.boundingSphere),Bo.applyMatrix4(i),Bo.radius+=s,t.ray.intersectsSphere(Bo)===!1)return;Nl.copy(i).invert(),or.copy(t.ray).applyMatrix4(Nl);const r=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=r*r,l=new L,h=new L,d=new L,u=new L,p=this.isLineSegments?2:1,g=n.index,m=n.attributes.position;if(g!==null){const f=Math.max(0,a.start),_=Math.min(g.count,a.start+a.count);for(let x=f,M=_-1;x<M;x+=p){const R=g.getX(x),A=g.getX(x+1);if(l.fromBufferAttribute(m,R),h.fromBufferAttribute(m,A),or.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);const I=t.ray.origin.distanceTo(u);I<t.near||I>t.far||e.push({distance:I,point:d.clone().applyMatrix4(this.matrixWorld),index:x,face:null,faceIndex:null,object:this})}}else{const f=Math.max(0,a.start),_=Math.min(m.count,a.start+a.count);for(let x=f,M=_-1;x<M;x+=p){if(l.fromBufferAttribute(m,x),h.fromBufferAttribute(m,x+1),or.distanceSqToSegment(l,h,u,d)>c)continue;u.applyMatrix4(this.matrixWorld);const A=t.ray.origin.distanceTo(u);A<t.near||A>t.far||e.push({distance:A,point:d.clone().applyMatrix4(this.matrixWorld),index:x,face:null,faceIndex:null,object:this})}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}}const Bl=new L,Fl=new L;class wg extends gg{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let i=0,s=e.count;i<s;i+=2)Bl.fromBufferAttribute(e,i),Fl.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+Bl.distanceTo(Fl);t.setAttribute("lineDistance",new te(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Ph extends $n{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Vt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const Ol=new we,_r=new na,Fo=new Hs,Oo=new L;class yg extends _e{constructor(t=new Te,e=new Ph){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,i=this.matrixWorld,s=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Fo.copy(n.boundingSphere),Fo.applyMatrix4(i),Fo.radius+=s,t.ray.intersectsSphere(Fo)===!1)return;Ol.copy(i).invert(),_r.copy(t.ray).applyMatrix4(Ol);const r=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=r*r,l=n.index,d=n.attributes.position;if(l!==null){const u=Math.max(0,a.start),p=Math.min(l.count,a.start+a.count);for(let g=u,y=p;g<y;g++){const m=l.getX(g);Oo.fromBufferAttribute(d,m),zl(Oo,m,c,i,t,e,this)}}else{const u=Math.max(0,a.start),p=Math.min(d.count,a.start+a.count);for(let g=u,y=p;g<y;g++)Oo.fromBufferAttribute(d,g),zl(Oo,g,c,i,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){const r=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[r]=s}}}}}function zl(o,t,e,n,i,s,a){const r=_r.distanceSqToPoint(o);if(r<e){const c=new L;_r.closestPointToPoint(o,c),c.applyMatrix4(n);const l=i.ray.origin.distanceTo(c);if(l<i.near||l>i.far)return;s.push({distance:l,distanceToRay:Math.sqrt(r),point:c,index:t,face:null,object:a})}}class Ih extends Ve{constructor(t,e,n,i,s,a,r,c,l){super(t,e,n,i,s,a,r,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class yn{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){const n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const e=[];let n,i=this.getPoint(0),s=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),s+=n.distanceTo(i),e.push(s),i=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){const n=this.getLengths();let i=0;const s=n.length;let a;e?a=e:a=t*n[s-1];let r=0,c=s-1,l;for(;r<=c;)if(i=Math.floor(r+(c-r)/2),l=n[i]-a,l<0)r=i+1;else if(l>0)c=i-1;else{c=i;break}if(i=c,n[i]===a)return i/(s-1);const h=n[i],u=n[i+1]-h,p=(a-h)/u;return(i+p)/(s-1)}getTangent(t,e){let i=t-1e-4,s=t+1e-4;i<0&&(i=0),s>1&&(s=1);const a=this.getPoint(i),r=this.getPoint(s),c=e||(a.isVector2?new dt:new L);return c.copy(r).sub(a).normalize(),c}getTangentAt(t,e){const n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){const n=new L,i=[],s=[],a=[],r=new L,c=new we;for(let p=0;p<=t;p++){const g=p/t;i[p]=this.getTangentAt(g,new L)}s[0]=new L,a[0]=new L;let l=Number.MAX_VALUE;const h=Math.abs(i[0].x),d=Math.abs(i[0].y),u=Math.abs(i[0].z);h<=l&&(l=h,n.set(1,0,0)),d<=l&&(l=d,n.set(0,1,0)),u<=l&&n.set(0,0,1),r.crossVectors(i[0],n).normalize(),s[0].crossVectors(i[0],r),a[0].crossVectors(i[0],s[0]);for(let p=1;p<=t;p++){if(s[p]=s[p-1].clone(),a[p]=a[p-1].clone(),r.crossVectors(i[p-1],i[p]),r.length()>Number.EPSILON){r.normalize();const g=Math.acos(Ne(i[p-1].dot(i[p]),-1,1));s[p].applyMatrix4(c.makeRotationAxis(r,g))}a[p].crossVectors(i[p],s[p])}if(e===!0){let p=Math.acos(Ne(s[0].dot(s[t]),-1,1));p/=t,i[0].dot(r.crossVectors(s[0],s[t]))>0&&(p=-p);for(let g=1;g<=t;g++)s[g].applyMatrix4(c.makeRotationAxis(i[g],p*g)),a[g].crossVectors(i[g],s[g])}return{tangents:i,normals:s,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){const t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}}class Ur extends yn{constructor(t=0,e=0,n=1,i=1,s=0,a=Math.PI*2,r=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=i,this.aStartAngle=s,this.aEndAngle=a,this.aClockwise=r,this.aRotation=c}getPoint(t,e){const n=e||new dt,i=Math.PI*2;let s=this.aEndAngle-this.aStartAngle;const a=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=i;for(;s>i;)s-=i;s<Number.EPSILON&&(a?s=0:s=i),this.aClockwise===!0&&!a&&(s===i?s=-i:s=s-i);const r=this.aStartAngle+t*s;let c=this.aX+this.xRadius*Math.cos(r),l=this.aY+this.yRadius*Math.sin(r);if(this.aRotation!==0){const h=Math.cos(this.aRotation),d=Math.sin(this.aRotation),u=c-this.aX,p=l-this.aY;c=u*h-p*d+this.aX,l=u*d+p*h+this.aY}return n.set(c,l)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){const t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}}class xg extends Ur{constructor(t,e,n,i,s,a){super(t,e,n,n,i,s,a),this.isArcCurve=!0,this.type="ArcCurve"}}function Nr(){let o=0,t=0,e=0,n=0;function i(s,a,r,c){o=s,t=r,e=-3*s+3*a-2*r-c,n=2*s-2*a+r+c}return{initCatmullRom:function(s,a,r,c,l){i(a,r,l*(r-s),l*(c-a))},initNonuniformCatmullRom:function(s,a,r,c,l,h,d){let u=(a-s)/l-(r-s)/(l+h)+(r-a)/h,p=(r-a)/h-(c-a)/(h+d)+(c-r)/d;u*=h,p*=h,i(a,r,u,p)},calc:function(s){const a=s*s,r=a*s;return o+t*s+e*a+n*r}}}const zo=new L,ar=new Nr,rr=new Nr,cr=new Nr;class Dh extends yn{constructor(t=[],e=!1,n="centripetal",i=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=i}getPoint(t,e=new L){const n=e,i=this.points,s=i.length,a=(s-(this.closed?0:1))*t;let r=Math.floor(a),c=a-r;this.closed?r+=r>0?0:(Math.floor(Math.abs(r)/s)+1)*s:c===0&&r===s-1&&(r=s-2,c=1);let l,h;this.closed||r>0?l=i[(r-1)%s]:(zo.subVectors(i[0],i[1]).add(i[0]),l=zo);const d=i[r%s],u=i[(r+1)%s];if(this.closed||r+2<s?h=i[(r+2)%s]:(zo.subVectors(i[s-1],i[s-2]).add(i[s-1]),h=zo),this.curveType==="centripetal"||this.curveType==="chordal"){const p=this.curveType==="chordal"?.5:.25;let g=Math.pow(l.distanceToSquared(d),p),y=Math.pow(d.distanceToSquared(u),p),m=Math.pow(u.distanceToSquared(h),p);y<1e-4&&(y=1),g<1e-4&&(g=y),m<1e-4&&(m=y),ar.initNonuniformCatmullRom(l.x,d.x,u.x,h.x,g,y,m),rr.initNonuniformCatmullRom(l.y,d.y,u.y,h.y,g,y,m),cr.initNonuniformCatmullRom(l.z,d.z,u.z,h.z,g,y,m)}else this.curveType==="catmullrom"&&(ar.initCatmullRom(l.x,d.x,u.x,h.x,this.tension),rr.initCatmullRom(l.y,d.y,u.y,h.y,this.tension),cr.initCatmullRom(l.z,d.z,u.z,h.z,this.tension));return n.set(ar.calc(c),rr.calc(c),cr.calc(c)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(i.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const i=this.points[e];t.points.push(i.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(new L().fromArray(i))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}function kl(o,t,e,n,i){const s=(n-t)*.5,a=(i-e)*.5,r=o*o,c=o*r;return(2*e-2*n+s+a)*c+(-3*e+3*n-2*s-a)*r+s*o+e}function vg(o,t){const e=1-o;return e*e*t}function _g(o,t){return 2*(1-o)*o*t}function Mg(o,t){return o*o*t}function Ls(o,t,e,n){return vg(o,t)+_g(o,e)+Mg(o,n)}function Sg(o,t){const e=1-o;return e*e*e*t}function bg(o,t){const e=1-o;return 3*e*e*o*t}function Eg(o,t){return 3*(1-o)*o*o*t}function Tg(o,t){return o*o*o*t}function Ps(o,t,e,n,i){return Sg(o,t)+bg(o,e)+Eg(o,n)+Tg(o,i)}class Uh extends yn{constructor(t=new dt,e=new dt,n=new dt,i=new dt){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new dt){const n=e,i=this.v0,s=this.v1,a=this.v2,r=this.v3;return n.set(Ps(t,i.x,s.x,a.x,r.x),Ps(t,i.y,s.y,a.y,r.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class Ag extends yn{constructor(t=new L,e=new L,n=new L,i=new L){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new L){const n=e,i=this.v0,s=this.v1,a=this.v2,r=this.v3;return n.set(Ps(t,i.x,s.x,a.x,r.x),Ps(t,i.y,s.y,a.y,r.y),Ps(t,i.z,s.z,a.z,r.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class Nh extends yn{constructor(t=new dt,e=new dt){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new dt){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new dt){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Cg extends yn{constructor(t=new L,e=new L){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new L){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new L){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Bh extends yn{constructor(t=new dt,e=new dt,n=new dt){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new dt){const n=e,i=this.v0,s=this.v1,a=this.v2;return n.set(Ls(t,i.x,s.x,a.x),Ls(t,i.y,s.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Fh extends yn{constructor(t=new L,e=new L,n=new L){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new L){const n=e,i=this.v0,s=this.v1,a=this.v2;return n.set(Ls(t,i.x,s.x,a.x),Ls(t,i.y,s.y,a.y),Ls(t,i.z,s.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class Oh extends yn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new dt){const n=e,i=this.points,s=(i.length-1)*t,a=Math.floor(s),r=s-a,c=i[a===0?a:a-1],l=i[a],h=i[a>i.length-2?i.length-1:a+1],d=i[a>i.length-3?i.length-1:a+2];return n.set(kl(r,c.x,l.x,h.x,d.x),kl(r,c.y,l.y,h.y,d.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(i.clone())}return this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const i=this.points[e];t.points.push(i.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const i=t.points[e];this.points.push(new dt().fromArray(i))}return this}}var Jo=Object.freeze({__proto__:null,ArcCurve:xg,CatmullRomCurve3:Dh,CubicBezierCurve:Uh,CubicBezierCurve3:Ag,EllipseCurve:Ur,LineCurve:Nh,LineCurve3:Cg,QuadraticBezierCurve:Bh,QuadraticBezierCurve3:Fh,SplineCurve:Oh});class Rg extends yn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){const t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){const n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Jo[n](e,t))}return this}getPoint(t,e){const n=t*this.getLength(),i=this.getCurveLengths();let s=0;for(;s<i.length;){if(i[s]>=n){const a=i[s]-n,r=this.curves[s],c=r.getLength(),l=c===0?0:1-a/c;return r.getPointAt(l,e)}s++}return null}getLength(){const t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;const t=[];let e=0;for(let n=0,i=this.curves.length;n<i;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){const e=[];let n;for(let i=0,s=this.curves;i<s.length;i++){const a=s[i],r=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,c=a.getPoints(r);for(let l=0;l<c.length;l++){const h=c[l];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){const i=t.curves[e];this.curves.push(i.clone())}return this.autoClose=t.autoClose,this}toJSON(){const t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){const i=this.curves[e];t.curves.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){const i=t.curves[e];this.curves.push(new Jo[i.type]().fromJSON(i))}return this}}class Gl extends Rg{constructor(t){super(),this.type="Path",this.currentPoint=new dt,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){const n=new Nh(this.currentPoint.clone(),new dt(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,i){const s=new Bh(this.currentPoint.clone(),new dt(t,e),new dt(n,i));return this.curves.push(s),this.currentPoint.set(n,i),this}bezierCurveTo(t,e,n,i,s,a){const r=new Uh(this.currentPoint.clone(),new dt(t,e),new dt(n,i),new dt(s,a));return this.curves.push(r),this.currentPoint.set(s,a),this}splineThru(t){const e=[this.currentPoint.clone()].concat(t),n=new Oh(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,i,s,a){const r=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(t+r,e+c,n,i,s,a),this}absarc(t,e,n,i,s,a){return this.absellipse(t,e,n,n,i,s,a),this}ellipse(t,e,n,i,s,a,r,c){const l=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+l,e+h,n,i,s,a,r,c),this}absellipse(t,e,n,i,s,a,r,c){const l=new Ur(t,e,n,i,s,a,r,c);if(this.curves.length>0){const d=l.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(l);const h=l.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){const t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}}class Pn extends Te{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);const s=[],a=[],r=[],c=[],l=new L,h=new dt;a.push(0,0,0),r.push(0,0,1),c.push(.5,.5);for(let d=0,u=3;d<=e;d++,u+=3){const p=n+d/e*i;l.x=t*Math.cos(p),l.y=t*Math.sin(p),a.push(l.x,l.y,l.z),r.push(0,0,1),h.x=(a[u]/t+1)/2,h.y=(a[u+1]/t+1)/2,c.push(h.x,h.y)}for(let d=1;d<=e;d++)s.push(d,d+1,0);this.setIndex(s),this.setAttribute("position",new te(a,3)),this.setAttribute("normal",new te(r,3)),this.setAttribute("uv",new te(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Pn(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class K extends Te{constructor(t=1,e=1,n=1,i=32,s=1,a=!1,r=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:s,openEnded:a,thetaStart:r,thetaLength:c};const l=this;i=Math.floor(i),s=Math.floor(s);const h=[],d=[],u=[],p=[];let g=0;const y=[],m=n/2;let f=0;_(),a===!1&&(t>0&&x(!0),e>0&&x(!1)),this.setIndex(h),this.setAttribute("position",new te(d,3)),this.setAttribute("normal",new te(u,3)),this.setAttribute("uv",new te(p,2));function _(){const M=new L,R=new L;let A=0;const E=(e-t)/n;for(let I=0;I<=s;I++){const v=[],S=I/s,P=S*(e-t)+t;for(let O=0;O<=i;O++){const j=O/i,D=j*c+r,F=Math.sin(D),z=Math.cos(D);R.x=P*F,R.y=-S*n+m,R.z=P*z,d.push(R.x,R.y,R.z),M.set(F,E,z).normalize(),u.push(M.x,M.y,M.z),p.push(j,1-S),v.push(g++)}y.push(v)}for(let I=0;I<i;I++)for(let v=0;v<s;v++){const S=y[v][I],P=y[v+1][I],O=y[v+1][I+1],j=y[v][I+1];h.push(S,P,j),h.push(P,O,j),A+=6}l.addGroup(f,A,0),f+=A}function x(M){const R=g,A=new dt,E=new L;let I=0;const v=M===!0?t:e,S=M===!0?1:-1;for(let O=1;O<=i;O++)d.push(0,m*S,0),u.push(0,S,0),p.push(.5,.5),g++;const P=g;for(let O=0;O<=i;O++){const D=O/i*c+r,F=Math.cos(D),z=Math.sin(D);E.x=v*z,E.y=m*S,E.z=v*F,d.push(E.x,E.y,E.z),u.push(0,S,0),A.x=F*.5+.5,A.y=z*.5*S+.5,p.push(A.x,A.y),g++}for(let O=0;O<i;O++){const j=R+O,D=P+O;M===!0?h.push(D,D+1,j):h.push(D+1,D,j),I+=3}l.addGroup(f,I,M===!0?1:2),f+=I}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new K(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class de extends K{constructor(t=1,e=1,n=32,i=1,s=!1,a=0,r=Math.PI*2){super(0,t,e,n,i,s,a,r),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:s,thetaStart:a,thetaLength:r}}static fromJSON(t){return new de(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class Vs extends Te{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};const s=[],a=[];r(i),l(n),h(),this.setAttribute("position",new te(s,3)),this.setAttribute("normal",new te(s.slice(),3)),this.setAttribute("uv",new te(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function r(_){const x=new L,M=new L,R=new L;for(let A=0;A<e.length;A+=3)p(e[A+0],x),p(e[A+1],M),p(e[A+2],R),c(x,M,R,_)}function c(_,x,M,R){const A=R+1,E=[];for(let I=0;I<=A;I++){E[I]=[];const v=_.clone().lerp(M,I/A),S=x.clone().lerp(M,I/A),P=A-I;for(let O=0;O<=P;O++)O===0&&I===A?E[I][O]=v:E[I][O]=v.clone().lerp(S,O/P)}for(let I=0;I<A;I++)for(let v=0;v<2*(A-I)-1;v++){const S=Math.floor(v/2);v%2===0?(u(E[I][S+1]),u(E[I+1][S]),u(E[I][S])):(u(E[I][S+1]),u(E[I+1][S+1]),u(E[I+1][S]))}}function l(_){const x=new L;for(let M=0;M<s.length;M+=3)x.x=s[M+0],x.y=s[M+1],x.z=s[M+2],x.normalize().multiplyScalar(_),s[M+0]=x.x,s[M+1]=x.y,s[M+2]=x.z}function h(){const _=new L;for(let x=0;x<s.length;x+=3){_.x=s[x+0],_.y=s[x+1],_.z=s[x+2];const M=m(_)/2/Math.PI+.5,R=f(_)/Math.PI+.5;a.push(M,1-R)}g(),d()}function d(){for(let _=0;_<a.length;_+=6){const x=a[_+0],M=a[_+2],R=a[_+4],A=Math.max(x,M,R),E=Math.min(x,M,R);A>.9&&E<.1&&(x<.2&&(a[_+0]+=1),M<.2&&(a[_+2]+=1),R<.2&&(a[_+4]+=1))}}function u(_){s.push(_.x,_.y,_.z)}function p(_,x){const M=_*3;x.x=t[M+0],x.y=t[M+1],x.z=t[M+2]}function g(){const _=new L,x=new L,M=new L,R=new L,A=new dt,E=new dt,I=new dt;for(let v=0,S=0;v<s.length;v+=9,S+=6){_.set(s[v+0],s[v+1],s[v+2]),x.set(s[v+3],s[v+4],s[v+5]),M.set(s[v+6],s[v+7],s[v+8]),A.set(a[S+0],a[S+1]),E.set(a[S+2],a[S+3]),I.set(a[S+4],a[S+5]),R.copy(_).add(x).add(M).divideScalar(3);const P=m(R);y(A,S+0,_,P),y(E,S+2,x,P),y(I,S+4,M,P)}}function y(_,x,M,R){R<0&&_.x===1&&(a[x]=_.x-1),M.x===0&&M.z===0&&(a[x]=R/2/Math.PI+.5)}function m(_){return Math.atan2(_.z,-_.x)}function f(_){return Math.atan2(-_.y,Math.sqrt(_.x*_.x+_.z*_.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Vs(t.vertices,t.indices,t.radius,t.details)}}class Is extends Vs{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,i=1/n,s=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-i,-n,0,-i,n,0,i,-n,0,i,n,-i,-n,0,-i,n,0,i,-n,0,i,n,0,-n,0,-i,n,0,-i,-n,0,i,n,0,i],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(s,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Is(t.radius,t.detail)}}class zh extends Gl{constructor(t){super(t),this.uuid=Dn(),this.type="Shape",this.holes=[]}getPointsHoles(t){const e=[];for(let n=0,i=this.holes.length;n<i;n++)e[n]=this.holes[n].getPoints(t);return e}extractPoints(t){return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}}copy(t){super.copy(t),this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){const i=t.holes[e];this.holes.push(i.clone())}return this}toJSON(){const t=super.toJSON();t.uuid=this.uuid,t.holes=[];for(let e=0,n=this.holes.length;e<n;e++){const i=this.holes[e];t.holes.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.uuid=t.uuid,this.holes=[];for(let e=0,n=t.holes.length;e<n;e++){const i=t.holes[e];this.holes.push(new Gl().fromJSON(i))}return this}}const Lg={triangulate:function(o,t,e=2){const n=t&&t.length,i=n?t[0]*e:o.length;let s=kh(o,0,i,e,!0);const a=[];if(!s||s.next===s.prev)return a;let r,c,l,h,d,u,p;if(n&&(s=Ng(o,t,s,e)),o.length>80*e){r=l=o[0],c=h=o[1];for(let g=e;g<i;g+=e)d=o[g],u=o[g+1],d<r&&(r=d),u<c&&(c=u),d>l&&(l=d),u>h&&(h=u);p=Math.max(l-r,h-c),p=p!==0?32767/p:0}return Bs(s,a,e,r,c,p,0),a}};function kh(o,t,e,n,i){let s,a;if(i===qg(o,t,e,n)>0)for(s=t;s<e;s+=n)a=Hl(s,o[s],o[s+1],a);else for(s=e-n;s>=t;s-=n)a=Hl(s,o[s],o[s+1],a);return a&&oa(a,a.next)&&(Os(a),a=a.next),a}function wi(o,t){if(!o)return o;t||(t=o);let e=o,n;do if(n=!1,!e.steiner&&(oa(e,e.next)||ve(e.prev,e,e.next)===0)){if(Os(e),e=t=e.prev,e===e.next)break;n=!0}else e=e.next;while(n||e!==t);return t}function Bs(o,t,e,n,i,s,a){if(!o)return;!a&&s&&kg(o,n,i,s);let r=o,c,l;for(;o.prev!==o.next;){if(c=o.prev,l=o.next,s?Ig(o,n,i,s):Pg(o)){t.push(c.i/e|0),t.push(o.i/e|0),t.push(l.i/e|0),Os(o),o=l.next,r=l.next;continue}if(o=l,o===r){a?a===1?(o=Dg(wi(o),t,e),Bs(o,t,e,n,i,s,2)):a===2&&Ug(o,t,e,n,i,s):Bs(wi(o),t,e,n,i,s,1);break}}}function Pg(o){const t=o.prev,e=o,n=o.next;if(ve(t,e,n)>=0)return!1;const i=t.x,s=e.x,a=n.x,r=t.y,c=e.y,l=n.y,h=i<s?i<a?i:a:s<a?s:a,d=r<c?r<l?r:l:c<l?c:l,u=i>s?i>a?i:a:s>a?s:a,p=r>c?r>l?r:l:c>l?c:l;let g=n.next;for(;g!==t;){if(g.x>=h&&g.x<=u&&g.y>=d&&g.y<=p&&ss(i,r,s,c,a,l,g.x,g.y)&&ve(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function Ig(o,t,e,n){const i=o.prev,s=o,a=o.next;if(ve(i,s,a)>=0)return!1;const r=i.x,c=s.x,l=a.x,h=i.y,d=s.y,u=a.y,p=r<c?r<l?r:l:c<l?c:l,g=h<d?h<u?h:u:d<u?d:u,y=r>c?r>l?r:l:c>l?c:l,m=h>d?h>u?h:u:d>u?d:u,f=Mr(p,g,t,e,n),_=Mr(y,m,t,e,n);let x=o.prevZ,M=o.nextZ;for(;x&&x.z>=f&&M&&M.z<=_;){if(x.x>=p&&x.x<=y&&x.y>=g&&x.y<=m&&x!==i&&x!==a&&ss(r,h,c,d,l,u,x.x,x.y)&&ve(x.prev,x,x.next)>=0||(x=x.prevZ,M.x>=p&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&ss(r,h,c,d,l,u,M.x,M.y)&&ve(M.prev,M,M.next)>=0))return!1;M=M.nextZ}for(;x&&x.z>=f;){if(x.x>=p&&x.x<=y&&x.y>=g&&x.y<=m&&x!==i&&x!==a&&ss(r,h,c,d,l,u,x.x,x.y)&&ve(x.prev,x,x.next)>=0)return!1;x=x.prevZ}for(;M&&M.z<=_;){if(M.x>=p&&M.x<=y&&M.y>=g&&M.y<=m&&M!==i&&M!==a&&ss(r,h,c,d,l,u,M.x,M.y)&&ve(M.prev,M,M.next)>=0)return!1;M=M.nextZ}return!0}function Dg(o,t,e){let n=o;do{const i=n.prev,s=n.next.next;!oa(i,s)&&Gh(i,n,n.next,s)&&Fs(i,s)&&Fs(s,i)&&(t.push(i.i/e|0),t.push(n.i/e|0),t.push(s.i/e|0),Os(n),Os(n.next),n=o=s),n=n.next}while(n!==o);return wi(n)}function Ug(o,t,e,n,i,s){let a=o;do{let r=a.next.next;for(;r!==a.prev;){if(a.i!==r.i&&Vg(a,r)){let c=Hh(a,r);a=wi(a,a.next),c=wi(c,c.next),Bs(a,t,e,n,i,s,0),Bs(c,t,e,n,i,s,0);return}r=r.next}a=a.next}while(a!==o)}function Ng(o,t,e,n){const i=[];let s,a,r,c,l;for(s=0,a=t.length;s<a;s++)r=t[s]*n,c=s<a-1?t[s+1]*n:o.length,l=kh(o,r,c,n,!1),l===l.next&&(l.steiner=!0),i.push(Hg(l));for(i.sort(Bg),s=0;s<i.length;s++)e=Fg(i[s],e);return e}function Bg(o,t){return o.x-t.x}function Fg(o,t){const e=Og(o,t);if(!e)return t;const n=Hh(e,o);return wi(n,n.next),wi(e,e.next)}function Og(o,t){let e=t,n=-1/0,i;const s=o.x,a=o.y;do{if(a<=e.y&&a>=e.next.y&&e.next.y!==e.y){const u=e.x+(a-e.y)*(e.next.x-e.x)/(e.next.y-e.y);if(u<=s&&u>n&&(n=u,i=e.x<e.next.x?e:e.next,u===s))return i}e=e.next}while(e!==t);if(!i)return null;const r=i,c=i.x,l=i.y;let h=1/0,d;e=i;do s>=e.x&&e.x>=c&&s!==e.x&&ss(a<l?s:n,a,c,l,a<l?n:s,a,e.x,e.y)&&(d=Math.abs(a-e.y)/(s-e.x),Fs(e,o)&&(d<h||d===h&&(e.x>i.x||e.x===i.x&&zg(i,e)))&&(i=e,h=d)),e=e.next;while(e!==r);return i}function zg(o,t){return ve(o.prev,o,t.prev)<0&&ve(t.next,o,o.next)<0}function kg(o,t,e,n){let i=o;do i.z===0&&(i.z=Mr(i.x,i.y,t,e,n)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==o);i.prevZ.nextZ=null,i.prevZ=null,Gg(i)}function Gg(o){let t,e,n,i,s,a,r,c,l=1;do{for(e=o,o=null,s=null,a=0;e;){for(a++,n=e,r=0,t=0;t<l&&(r++,n=n.nextZ,!!n);t++);for(c=l;r>0||c>0&&n;)r!==0&&(c===0||!n||e.z<=n.z)?(i=e,e=e.nextZ,r--):(i=n,n=n.nextZ,c--),s?s.nextZ=i:o=i,i.prevZ=s,s=i;e=n}s.nextZ=null,l*=2}while(a>1);return o}function Mr(o,t,e,n,i){return o=(o-e)*i|0,t=(t-n)*i|0,o=(o|o<<8)&16711935,o=(o|o<<4)&252645135,o=(o|o<<2)&858993459,o=(o|o<<1)&1431655765,t=(t|t<<8)&16711935,t=(t|t<<4)&252645135,t=(t|t<<2)&858993459,t=(t|t<<1)&1431655765,o|t<<1}function Hg(o){let t=o,e=o;do(t.x<e.x||t.x===e.x&&t.y<e.y)&&(e=t),t=t.next;while(t!==o);return e}function ss(o,t,e,n,i,s,a,r){return(i-a)*(t-r)>=(o-a)*(s-r)&&(o-a)*(n-r)>=(e-a)*(t-r)&&(e-a)*(s-r)>=(i-a)*(n-r)}function Vg(o,t){return o.next.i!==t.i&&o.prev.i!==t.i&&!Wg(o,t)&&(Fs(o,t)&&Fs(t,o)&&Xg(o,t)&&(ve(o.prev,o,t.prev)||ve(o,t.prev,t))||oa(o,t)&&ve(o.prev,o,o.next)>0&&ve(t.prev,t,t.next)>0)}function ve(o,t,e){return(t.y-o.y)*(e.x-t.x)-(t.x-o.x)*(e.y-t.y)}function oa(o,t){return o.x===t.x&&o.y===t.y}function Gh(o,t,e,n){const i=Go(ve(o,t,e)),s=Go(ve(o,t,n)),a=Go(ve(e,n,o)),r=Go(ve(e,n,t));return!!(i!==s&&a!==r||i===0&&ko(o,e,t)||s===0&&ko(o,n,t)||a===0&&ko(e,o,n)||r===0&&ko(e,t,n))}function ko(o,t,e){return t.x<=Math.max(o.x,e.x)&&t.x>=Math.min(o.x,e.x)&&t.y<=Math.max(o.y,e.y)&&t.y>=Math.min(o.y,e.y)}function Go(o){return o>0?1:o<0?-1:0}function Wg(o,t){let e=o;do{if(e.i!==o.i&&e.next.i!==o.i&&e.i!==t.i&&e.next.i!==t.i&&Gh(e,e.next,o,t))return!0;e=e.next}while(e!==o);return!1}function Fs(o,t){return ve(o.prev,o,o.next)<0?ve(o,t,o.next)>=0&&ve(o,o.prev,t)>=0:ve(o,t,o.prev)<0||ve(o,o.next,t)<0}function Xg(o,t){let e=o,n=!1;const i=(o.x+t.x)/2,s=(o.y+t.y)/2;do e.y>s!=e.next.y>s&&e.next.y!==e.y&&i<(e.next.x-e.x)*(s-e.y)/(e.next.y-e.y)+e.x&&(n=!n),e=e.next;while(e!==o);return n}function Hh(o,t){const e=new Sr(o.i,o.x,o.y),n=new Sr(t.i,t.x,t.y),i=o.next,s=t.prev;return o.next=t,t.prev=o,e.next=i,i.prev=e,n.next=e,e.prev=n,s.next=n,n.prev=s,n}function Hl(o,t,e,n){const i=new Sr(o,t,e);return n?(i.next=n.next,i.prev=n,n.next.prev=i,n.next=i):(i.prev=i,i.next=i),i}function Os(o){o.next.prev=o.prev,o.prev.next=o.next,o.prevZ&&(o.prevZ.nextZ=o.nextZ),o.nextZ&&(o.nextZ.prevZ=o.prevZ)}function Sr(o,t,e){this.i=o,this.x=t,this.y=e,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function qg(o,t,e,n){let i=0;for(let s=t,a=e-n;s<e;s+=n)i+=(o[a]-o[s])*(o[s+1]+o[a+1]),a=s;return i}class Ds{static area(t){const e=t.length;let n=0;for(let i=e-1,s=0;s<e;i=s++)n+=t[i].x*t[s].y-t[s].x*t[i].y;return n*.5}static isClockWise(t){return Ds.area(t)<0}static triangulateShape(t,e){const n=[],i=[],s=[];Vl(t),Wl(n,t);let a=t.length;e.forEach(Vl);for(let c=0;c<e.length;c++)i.push(a),a+=e[c].length,Wl(n,e[c]);const r=Lg.triangulate(n,i);for(let c=0;c<r.length;c+=3)s.push(r.slice(c,c+3));return s}}function Vl(o){const t=o.length;t>2&&o[t-1].equals(o[0])&&o.pop()}function Wl(o,t){for(let e=0;e<t.length;e++)o.push(t[e].x),o.push(t[e].y)}class Br extends Te{constructor(t=new zh([new dt(.5,.5),new dt(-.5,.5),new dt(-.5,-.5),new dt(.5,-.5)]),e={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];const n=this,i=[],s=[];for(let r=0,c=t.length;r<c;r++){const l=t[r];a(l)}this.setAttribute("position",new te(i,3)),this.setAttribute("uv",new te(s,2)),this.computeVertexNormals();function a(r){const c=[],l=e.curveSegments!==void 0?e.curveSegments:12,h=e.steps!==void 0?e.steps:1,d=e.depth!==void 0?e.depth:1;let u=e.bevelEnabled!==void 0?e.bevelEnabled:!0,p=e.bevelThickness!==void 0?e.bevelThickness:.2,g=e.bevelSize!==void 0?e.bevelSize:p-.1,y=e.bevelOffset!==void 0?e.bevelOffset:0,m=e.bevelSegments!==void 0?e.bevelSegments:3;const f=e.extrudePath,_=e.UVGenerator!==void 0?e.UVGenerator:Yg;let x,M=!1,R,A,E,I;f&&(x=f.getSpacedPoints(h),M=!0,u=!1,R=f.computeFrenetFrames(h,!1),A=new L,E=new L,I=new L),u||(m=0,p=0,g=0,y=0);const v=r.extractPoints(l);let S=v.shape;const P=v.holes;if(!Ds.isClockWise(S)){S=S.reverse();for(let N=0,ht=P.length;N<ht;N++){const tt=P[N];Ds.isClockWise(tt)&&(P[N]=tt.reverse())}}const j=Ds.triangulateShape(S,P),D=S;for(let N=0,ht=P.length;N<ht;N++){const tt=P[N];S=S.concat(tt)}function F(N,ht,tt){return ht||console.error("THREE.ExtrudeGeometry: vec does not exist"),N.clone().addScaledVector(ht,tt)}const z=S.length,Z=j.length;function Y(N,ht,tt){let lt,Q,Lt;const ft=N.x-ht.x,T=N.y-ht.y,b=tt.x-N.x,k=tt.y-N.y,it=ft*ft+T*T,at=ft*k-T*b;if(Math.abs(at)>Number.EPSILON){const st=Math.sqrt(it),St=Math.sqrt(b*b+k*k),wt=ht.x-T/st,Mt=ht.y+ft/st,Pt=tt.x-k/St,Ut=tt.y+b/St,rt=((Pt-wt)*k-(Ut-Mt)*b)/(ft*k-T*b);lt=wt+ft*rt-N.x,Q=Mt+T*rt-N.y;const Jt=lt*lt+Q*Q;if(Jt<=2)return new dt(lt,Q);Lt=Math.sqrt(Jt/2)}else{let st=!1;ft>Number.EPSILON?b>Number.EPSILON&&(st=!0):ft<-Number.EPSILON?b<-Number.EPSILON&&(st=!0):Math.sign(T)===Math.sign(k)&&(st=!0),st?(lt=-T,Q=ft,Lt=Math.sqrt(it)):(lt=ft,Q=T,Lt=Math.sqrt(it/2))}return new dt(lt/Lt,Q/Lt)}const q=[];for(let N=0,ht=D.length,tt=ht-1,lt=N+1;N<ht;N++,tt++,lt++)tt===ht&&(tt=0),lt===ht&&(lt=0),q[N]=Y(D[N],D[tt],D[lt]);const J=[];let nt,ct=q.concat();for(let N=0,ht=P.length;N<ht;N++){const tt=P[N];nt=[];for(let lt=0,Q=tt.length,Lt=Q-1,ft=lt+1;lt<Q;lt++,Lt++,ft++)Lt===Q&&(Lt=0),ft===Q&&(ft=0),nt[lt]=Y(tt[lt],tt[Lt],tt[ft]);J.push(nt),ct=ct.concat(nt)}for(let N=0;N<m;N++){const ht=N/m,tt=p*Math.cos(ht*Math.PI/2),lt=g*Math.sin(ht*Math.PI/2)+y;for(let Q=0,Lt=D.length;Q<Lt;Q++){const ft=F(D[Q],q[Q],lt);xt(ft.x,ft.y,-tt)}for(let Q=0,Lt=P.length;Q<Lt;Q++){const ft=P[Q];nt=J[Q];for(let T=0,b=ft.length;T<b;T++){const k=F(ft[T],nt[T],lt);xt(k.x,k.y,-tt)}}}const X=g+y;for(let N=0;N<z;N++){const ht=u?F(S[N],ct[N],X):S[N];M?(E.copy(R.normals[0]).multiplyScalar(ht.x),A.copy(R.binormals[0]).multiplyScalar(ht.y),I.copy(x[0]).add(E).add(A),xt(I.x,I.y,I.z)):xt(ht.x,ht.y,0)}for(let N=1;N<=h;N++)for(let ht=0;ht<z;ht++){const tt=u?F(S[ht],ct[ht],X):S[ht];M?(E.copy(R.normals[N]).multiplyScalar(tt.x),A.copy(R.binormals[N]).multiplyScalar(tt.y),I.copy(x[N]).add(E).add(A),xt(I.x,I.y,I.z)):xt(tt.x,tt.y,d/h*N)}for(let N=m-1;N>=0;N--){const ht=N/m,tt=p*Math.cos(ht*Math.PI/2),lt=g*Math.sin(ht*Math.PI/2)+y;for(let Q=0,Lt=D.length;Q<Lt;Q++){const ft=F(D[Q],q[Q],lt);xt(ft.x,ft.y,d+tt)}for(let Q=0,Lt=P.length;Q<Lt;Q++){const ft=P[Q];nt=J[Q];for(let T=0,b=ft.length;T<b;T++){const k=F(ft[T],nt[T],lt);M?xt(k.x,k.y+x[h-1].y,x[h-1].x+tt):xt(k.x,k.y,d+tt)}}}et(),pt();function et(){const N=i.length/3;if(u){let ht=0,tt=z*ht;for(let lt=0;lt<Z;lt++){const Q=j[lt];It(Q[2]+tt,Q[1]+tt,Q[0]+tt)}ht=h+m*2,tt=z*ht;for(let lt=0;lt<Z;lt++){const Q=j[lt];It(Q[0]+tt,Q[1]+tt,Q[2]+tt)}}else{for(let ht=0;ht<Z;ht++){const tt=j[ht];It(tt[2],tt[1],tt[0])}for(let ht=0;ht<Z;ht++){const tt=j[ht];It(tt[0]+z*h,tt[1]+z*h,tt[2]+z*h)}}n.addGroup(N,i.length/3-N,0)}function pt(){const N=i.length/3;let ht=0;bt(D,ht),ht+=D.length;for(let tt=0,lt=P.length;tt<lt;tt++){const Q=P[tt];bt(Q,ht),ht+=Q.length}n.addGroup(N,i.length/3-N,1)}function bt(N,ht){let tt=N.length;for(;--tt>=0;){const lt=tt;let Q=tt-1;Q<0&&(Q=N.length-1);for(let Lt=0,ft=h+m*2;Lt<ft;Lt++){const T=z*Lt,b=z*(Lt+1),k=ht+lt+T,it=ht+Q+T,at=ht+Q+b,st=ht+lt+b;Gt(k,it,at,st)}}}function xt(N,ht,tt){c.push(N),c.push(ht),c.push(tt)}function It(N,ht,tt){At(N),At(ht),At(tt);const lt=i.length/3,Q=_.generateTopUV(n,i,lt-3,lt-2,lt-1);Et(Q[0]),Et(Q[1]),Et(Q[2])}function Gt(N,ht,tt,lt){At(N),At(ht),At(lt),At(ht),At(tt),At(lt);const Q=i.length/3,Lt=_.generateSideWallUV(n,i,Q-6,Q-3,Q-2,Q-1);Et(Lt[0]),Et(Lt[1]),Et(Lt[3]),Et(Lt[1]),Et(Lt[2]),Et(Lt[3])}function At(N){i.push(c[N*3+0]),i.push(c[N*3+1]),i.push(c[N*3+2])}function Et(N){s.push(N.x),s.push(N.y)}}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON(),e=this.parameters.shapes,n=this.parameters.options;return $g(e,n,t)}static fromJSON(t,e){const n=[];for(let s=0,a=t.shapes.length;s<a;s++){const r=e[t.shapes[s]];n.push(r)}const i=t.options.extrudePath;return i!==void 0&&(t.options.extrudePath=new Jo[i.type]().fromJSON(i)),new Br(n,t.options)}}const Yg={generateTopUV:function(o,t,e,n,i){const s=t[e*3],a=t[e*3+1],r=t[n*3],c=t[n*3+1],l=t[i*3],h=t[i*3+1];return[new dt(s,a),new dt(r,c),new dt(l,h)]},generateSideWallUV:function(o,t,e,n,i,s){const a=t[e*3],r=t[e*3+1],c=t[e*3+2],l=t[n*3],h=t[n*3+1],d=t[n*3+2],u=t[i*3],p=t[i*3+1],g=t[i*3+2],y=t[s*3],m=t[s*3+1],f=t[s*3+2];return Math.abs(r-h)<Math.abs(a-l)?[new dt(a,1-c),new dt(l,1-d),new dt(u,1-g),new dt(y,1-f)]:[new dt(r,1-c),new dt(h,1-d),new dt(p,1-g),new dt(m,1-f)]}};function $g(o,t,e){if(e.shapes=[],Array.isArray(o))for(let n=0,i=o.length;n<i;n++){const s=o[n];e.shapes.push(s.uuid)}else e.shapes.push(o.uuid);return e.options=Object.assign({},t),t.extrudePath!==void 0&&(e.options.extrudePath=t.extrudePath.toJSON()),e}class Qo extends Vs{constructor(t=1,e=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],i=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,i,t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Qo(t.radius,t.detail)}}class zs extends Te{constructor(t=.5,e=1,n=32,i=1,s=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:i,thetaStart:s,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);const r=[],c=[],l=[],h=[];let d=t;const u=(e-t)/i,p=new L,g=new dt;for(let y=0;y<=i;y++){for(let m=0;m<=n;m++){const f=s+m/n*a;p.x=d*Math.cos(f),p.y=d*Math.sin(f),c.push(p.x,p.y,p.z),l.push(0,0,1),g.x=(p.x/e+1)/2,g.y=(p.y/e+1)/2,h.push(g.x,g.y)}d+=u}for(let y=0;y<i;y++){const m=y*(n+1);for(let f=0;f<n;f++){const _=f+m,x=_,M=_+n+1,R=_+n+2,A=_+1;r.push(x,M,A),r.push(M,R,A)}}this.setIndex(r),this.setAttribute("position",new te(c,3)),this.setAttribute("normal",new te(l,3)),this.setAttribute("uv",new te(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new zs(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Rt extends Te{constructor(t=1,e=32,n=16,i=0,s=Math.PI*2,a=0,r=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:s,thetaStart:a,thetaLength:r},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const c=Math.min(a+r,Math.PI);let l=0;const h=[],d=new L,u=new L,p=[],g=[],y=[],m=[];for(let f=0;f<=n;f++){const _=[],x=f/n;let M=0;f===0&&a===0?M=.5/e:f===n&&c===Math.PI&&(M=-.5/e);for(let R=0;R<=e;R++){const A=R/e;d.x=-t*Math.cos(i+A*s)*Math.sin(a+x*r),d.y=t*Math.cos(a+x*r),d.z=t*Math.sin(i+A*s)*Math.sin(a+x*r),g.push(d.x,d.y,d.z),u.copy(d).normalize(),y.push(u.x,u.y,u.z),m.push(A+M,1-x),_.push(l++)}h.push(_)}for(let f=0;f<n;f++)for(let _=0;_<e;_++){const x=h[f][_+1],M=h[f][_],R=h[f+1][_],A=h[f+1][_+1];(f!==0||a>0)&&p.push(x,M,A),(f!==n-1||c<Math.PI)&&p.push(M,R,A)}this.setIndex(p),this.setAttribute("position",new te(g,3)),this.setAttribute("normal",new te(y,3)),this.setAttribute("uv",new te(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Rt(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class Fr extends Vs{constructor(t=1,e=0){const n=[1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],i=[2,1,0,0,3,2,1,3,0,2,3,1];super(n,i,t,e),this.type="TetrahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Fr(t.radius,t.detail)}}class Vn extends Te{constructor(t=1,e=.4,n=12,i=48,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:i,arc:s},n=Math.floor(n),i=Math.floor(i);const a=[],r=[],c=[],l=[],h=new L,d=new L,u=new L;for(let p=0;p<=n;p++)for(let g=0;g<=i;g++){const y=g/i*s,m=p/n*Math.PI*2;d.x=(t+e*Math.cos(m))*Math.cos(y),d.y=(t+e*Math.cos(m))*Math.sin(y),d.z=e*Math.sin(m),r.push(d.x,d.y,d.z),h.x=t*Math.cos(y),h.y=t*Math.sin(y),u.subVectors(d,h).normalize(),c.push(u.x,u.y,u.z),l.push(g/i),l.push(p/n)}for(let p=1;p<=n;p++)for(let g=1;g<=i;g++){const y=(i+1)*p+g-1,m=(i+1)*(p-1)+g-1,f=(i+1)*(p-1)+g,_=(i+1)*p+g;a.push(y,m,_),a.push(m,f,_)}this.setIndex(a),this.setAttribute("position",new te(r,3)),this.setAttribute("normal",new te(c,3)),this.setAttribute("uv",new te(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Vn(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}class Or extends Te{constructor(t=new Fh(new L(-1,-1,0),new L(-1,1,0),new L(1,1,0)),e=64,n=1,i=8,s=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:n,radialSegments:i,closed:s};const a=t.computeFrenetFrames(e,s);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;const r=new L,c=new L,l=new dt;let h=new L;const d=[],u=[],p=[],g=[];y(),this.setIndex(g),this.setAttribute("position",new te(d,3)),this.setAttribute("normal",new te(u,3)),this.setAttribute("uv",new te(p,2));function y(){for(let x=0;x<e;x++)m(x);m(s===!1?e:0),_(),f()}function m(x){h=t.getPointAt(x/e,h);const M=a.normals[x],R=a.binormals[x];for(let A=0;A<=i;A++){const E=A/i*Math.PI*2,I=Math.sin(E),v=-Math.cos(E);c.x=v*M.x+I*R.x,c.y=v*M.y+I*R.y,c.z=v*M.z+I*R.z,c.normalize(),u.push(c.x,c.y,c.z),r.x=h.x+n*c.x,r.y=h.y+n*c.y,r.z=h.z+n*c.z,d.push(r.x,r.y,r.z)}}function f(){for(let x=1;x<=e;x++)for(let M=1;M<=i;M++){const R=(i+1)*(x-1)+(M-1),A=(i+1)*x+(M-1),E=(i+1)*x+M,I=(i+1)*(x-1)+M;g.push(R,A,I),g.push(A,E,I)}}function _(){for(let x=0;x<=e;x++)for(let M=0;M<=i;M++)l.x=x/e,l.y=M/i,p.push(l.x,l.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new Or(new Jo[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}}class V extends $n{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Vt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Vt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=rh,this.normalScale=new dt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Ar,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class aa extends _e{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Vt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),e}}class Zg extends aa{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(_e.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Vt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}}const lr=new we,Xl=new L,ql=new L;class zr{constructor(t){this.camera=t,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new dt(512,512),this.map=null,this.mapPass=null,this.matrix=new we,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Pr,this._frameExtents=new dt(1,1),this._viewportCount=1,this._viewports=[new ge(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera,n=this.matrix;Xl.setFromMatrixPosition(t.matrixWorld),e.position.copy(Xl),ql.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(ql),e.updateMatrixWorld(),lr.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(lr),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(lr)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}class jg extends zr{constructor(){super(new Ge(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(t){const e=this.camera,n=Zo*2*t.angle*this.focus,i=this.mapSize.width/this.mapSize.height,s=t.distance||e.far;(n!==e.fov||i!==e.aspect||s!==e.far)&&(e.fov=n,e.aspect=i,e.far=s,e.updateProjectionMatrix()),super.updateMatrices(t)}copy(t){return super.copy(t),this.focus=t.focus,this}}class Kg extends aa{constructor(t,e,n=0,i=Math.PI/3,s=0,a=2){super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(_e.DEFAULT_UP),this.updateMatrix(),this.target=new _e,this.distance=n,this.angle=i,this.penumbra=s,this.decay=a,this.map=null,this.shadow=new jg}get power(){return this.intensity*Math.PI}set power(t){this.intensity=t/Math.PI}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}const Yl=new we,Cs=new L,hr=new L;class Jg extends zr{constructor(){super(new Ge(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new dt(4,2),this._viewportCount=6,this._viewports=[new ge(2,1,1,1),new ge(0,1,1,1),new ge(3,1,1,1),new ge(1,1,1,1),new ge(3,0,1,1),new ge(1,0,1,1)],this._cubeDirections=[new L(1,0,0),new L(-1,0,0),new L(0,0,1),new L(0,0,-1),new L(0,1,0),new L(0,-1,0)],this._cubeUps=[new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,0,1),new L(0,0,-1)]}updateMatrices(t,e=0){const n=this.camera,i=this.matrix,s=t.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),Cs.setFromMatrixPosition(t.matrixWorld),n.position.copy(Cs),hr.copy(n.position),hr.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(hr),n.updateMatrixWorld(),i.makeTranslation(-Cs.x,-Cs.y,-Cs.z),Yl.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Yl)}}class Ze extends aa{constructor(t,e,n=0,i=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new Jg}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}}class Qg extends zr{constructor(){super(new vh(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class tw extends aa{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(_e.DEFAULT_UP),this.updateMatrix(),this.target=new _e,this.shadow=new Qg}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class ew{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=$l(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const e=$l();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}}function $l(){return(typeof performance>"u"?Date:performance).now()}class nw{constructor(t,e,n=0,i=1/0){this.ray=new na(t,e),this.near=n,this.far=i,this.camera=null,this.layers=new Lr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}intersectObject(t,e=!0,n=[]){return br(t,this,n,e),n.sort(Zl),n}intersectObjects(t,e=!0,n=[]){for(let i=0,s=t.length;i<s;i++)br(t[i],this,n,e);return n.sort(Zl),n}}function Zl(o,t){return o.distance-t.distance}function br(o,t,e,n){if(o.layers.test(t.layers)&&o.raycast(t,e),n===!0){const i=o.children;for(let s=0,a=i.length;s<a;s++)br(i[s],t,e,!0)}}class iw extends wg{constructor(t=10,e=10,n=4473924,i=8947848){n=new Vt(n),i=new Vt(i);const s=e/2,a=t/e,r=t/2,c=[],l=[];for(let u=0,p=0,g=-r;u<=e;u++,g+=a){c.push(-r,0,g,r,0,g),c.push(g,0,-r,g,0,r);const y=u===s?n:i;y.toArray(l,p),p+=3,y.toArray(l,p),p+=3,y.toArray(l,p),p+=3,y.toArray(l,p),p+=3}const h=new Te;h.setAttribute("position",new te(c,3)),h.setAttribute("color",new te(l,3));const d=new Lh({vertexColors:!0,toneMapped:!1});super(h,d),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Er}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Er);class sw{constructor(){this.modals={about:document.getElementById("modal-about"),skills:document.getElementById("modal-skills"),projects:document.getElementById("modal-projects"),arcade:document.getElementById("modal-arcade"),easel:document.getElementById("modal-easel"),wardrobe:document.getElementById("modal-wardrobe"),leaderboard:document.getElementById("modal-leaderboard"),tasks:document.getElementById("modal-tasks"),farm:document.getElementById("modal-farm"),pk:document.getElementById("modal-pk"),bag:document.getElementById("modal-bag"),home:document.getElementById("modal-home"),exit:document.getElementById("modal-exit"),map:document.getElementById("modal-map"),shop:document.getElementById("modal-shop"),piano:document.getElementById("modal-piano")},this.iframe=document.getElementById("arcade-iframe"),this.arcadeLobby=document.getElementById("arcade-lobby"),this.arcadeTitle=document.getElementById("arcade-title"),this.arcadeBackBtn=document.getElementById("btn-arcade-back"),this.closeButtons=document.querySelectorAll(".modal-close"),this.overlayList=document.querySelectorAll(".modal-overlay"),this.isAnyModalOpen=!1,this.init(),this.hydrateFromConfig()}init(){this.closeButtons.forEach(t=>{t.addEventListener("click",e=>{let n=t.getAttribute("data-close");n&&n.startsWith("modal-")&&(n=n.replace("modal-","")),this.closeModal(n)})}),this.overlayList.forEach(t=>{t.addEventListener("click",e=>{if(e.target===t){const n=t.id.replace("modal-","");this.closeModal(n)}})}),window.addEventListener("keydown",t=>{t.key==="Escape"&&this.isAnyModalOpen&&this.closeAllModals()})}async hydrateFromConfig(){try{const e=(await rd(()=>import("./site-config-CqbHk6xq.js"),[],import.meta.url)).siteConfig;if(e.developer){const s=e.developer,a=document.querySelector("#modal-about .avatar-placeholder");a&&(a.textContent=s.avatar||"🌻");const r=document.querySelector("#modal-about .profile-info");r&&(r.innerHTML=`
            <h3>${s.name}</h3>
            <p class="tagline">${s.tagline}</p>
          `);const c=document.querySelector("#modal-about .bio-text");c&&(c.innerHTML=`
            <p>${s.bio}</p>
            <p><strong>联系邮箱:</strong> ${s.email}</p>
            <div style="margin-top: 20px; display: flex; gap: 12px; pointer-events: auto;">
              <a href="../../class.html" class="hud-btn" style="padding: 8px 16px; font-size: 0.8rem; text-decoration: none;">我的课表</a>
              <a href="../../album.html" class="hud-btn" style="padding: 8px 16px; font-size: 0.8rem; text-decoration: none;">我的相册</a>
            </div>
          `)}const n=document.querySelector("#modal-projects .projects-grid");n&&e.games&&(n.innerHTML="",e.games.forEach(s=>{const a=document.createElement("div");a.className="project-item",a.innerHTML=`
            <div class="project-img">${s.emoji||"🎮"}</div>
            <div class="project-detail">
              <h3>${s.name}</h3>
              <p>运行于网页主页“韭菜盒子”工具箱板块下的经典互动小游戏，适配桌面端与移动端。</p>
              <button class="tag play-btn" style="margin-top: 6px; display: inline-block; text-decoration: none; cursor: pointer; border: none; background: none; color: inherit; padding: 0; font-family: inherit; text-align: left;">直接游玩</button>
            </div>
          `;const r=a.querySelector(".play-btn");r&&r.addEventListener("click",c=>{c.preventDefault(),this.launchGame(s)}),n.appendChild(a)}));const i=document.querySelector(".arcade-games-grid");i&&e.games&&(i.innerHTML="",e.games.forEach(s=>{const a=document.createElement("div");a.className="arcade-game-card",a.innerHTML=`
            <div class="arcade-game-icon">${s.emoji||"🕹️"}</div>
            <div class="arcade-game-title">${s.name}</div>
          `,a.addEventListener("click",()=>{this.launchGame(s)}),i.appendChild(a)})),this.arcadeBackBtn&&this.arcadeBackBtn.addEventListener("click",()=>{this.showLobby()})}catch(t){console.error("Failed to dynamically import site config:",t)}}launchGame(t){let e=t.path;const n=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1";t.id==="21dian"&&(e=n?`http://${window.location.hostname}:8080/games/21dian/index.html`:t.path);let i;e.startsWith("http://")||e.startsWith("https://")?i=e:i="../../"+e.replace(/^\.\//,"");const s=localStorage.getItem("sso_access_token"),a=localStorage.getItem("sso_user");if(s&&a)try{const r=new URL(i,window.location.href);r.searchParams.set("sso_access_token",s),r.searchParams.set("sso_user",a),i=r.toString()}catch{i.includes("?")?i+=`&sso_access_token=${s}&sso_user=${encodeURIComponent(a)}`:i+=`?sso_access_token=${s}&sso_user=${encodeURIComponent(a)}`}window.open(i,"_blank")}showLobby(){this.iframe&&(this.iframe.src="",this.iframe.style.display="none"),this.arcadeLobby&&(this.arcadeLobby.style.display="block"),this.arcadeTitle&&(this.arcadeTitle.textContent="复古街机 · 游戏大厅"),this.arcadeBackBtn&&(this.arcadeBackBtn.style.display="none")}openModal(t){const e=this.modals[t];if(e){if(t==="arcade"&&this.showLobby(),t==="easel"){const n=document.getElementById("easel-iframe");n&&(n.src="./paint.html")}e.classList.add("open"),this.isAnyModalOpen=!0,window.dispatchEvent(new CustomEvent("modal-opened",{detail:{modalId:t}})),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalOpened=="function"&&window.parent.appShell.onModalOpened(t)}}closeModal(t){const e=this.modals[t];if(e){if(e.classList.remove("open"),t==="arcade"&&this.iframe&&(this.iframe.src=""),t==="easel"){const n=document.getElementById("easel-iframe");n&&(n.src="")}this.isAnyModalOpen=Array.from(this.overlayList).some(n=>n.classList.contains("open")),this.isAnyModalOpen||(window.dispatchEvent(new CustomEvent("modal-closed",{detail:{modalId:t}})),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed(t))}}closeAllModals(){Object.keys(this.modals).forEach(t=>this.closeModal(t))}}class ow{constructor(t,e){this.scene=t,this.themeConfig=e,this.particles=null,this.particleCount=150,this.particleGeometry=null,this.particleMaterial=null,this.isNight=!1,this.isIndoor=!1,this.initLights(),this.initFog(),this.initParticles()}setIndoorMode(t){this.isIndoor=t,this.particles&&(this.particles.visible=!t)}initLights(){const t=this.themeConfig.colors.sky===330776,e=t?14544639:16777215,n=t?4128:58879,i=t?.75:1.1,s=new Zg(e,n,i);s.position.set(0,50,0),this.scene.add(s),this.hemiLight=s;const a=t?14280949:16776679,r=t?.95:1.75,c=new tw(a,r);c.position.set(20,40,20),c.castShadow=!0;const l="ontouchstart"in window||navigator.maxTouchPoints>0;c.shadow.mapSize.width=l?1024:2048,c.shadow.mapSize.height=l?1024:2048,c.shadow.camera.near=.5,c.shadow.camera.far=100;const h=30;c.shadow.camera.left=-h,c.shadow.camera.right=h,c.shadow.camera.top=h,c.shadow.camera.bottom=-h,c.shadow.bias=-5e-4,this.scene.add(c),this.sun=c}initFog(){const t=this.themeConfig.colors.fog||14743546,n=this.themeConfig.colors.sky===330776?.012:.009;this.scene.fog=new Dr(t,n)}initParticles(){const t=this.themeConfig.colors.sky===330776;this.particleGeometry=new Te;const e=new Float32Array(this.particleCount*3),n=[];for(let c=0;c<this.particleCount;c++)e[c*3]=(Math.random()-.5)*60,e[c*3+1]=Math.random()*(t?30:22),e[c*3+2]=(Math.random()-.5)*60,n.push({y:t?.08+Math.random()*.08:.05+Math.random()*.05,x:(Math.random()-.5)*.04,z:(Math.random()-.5)*.04});this.particleGeometry.setAttribute("position",new sn(e,3)),this.particleSpeeds=n;const i=document.createElement("canvas");i.width=16,i.height=16;const s=i.getContext("2d"),a=s.createRadialGradient(8,8,0,8,8,8);t?(a.addColorStop(0,"rgba(255, 255, 255, 0.95)"),a.addColorStop(.4,"rgba(255, 255, 255, 0.7)"),a.addColorStop(1,"rgba(255, 255, 255, 0)")):(a.addColorStop(0,"rgba(128, 222, 234, 0.85)"),a.addColorStop(1,"rgba(128, 222, 234, 0)")),s.fillStyle=a,s.fillRect(0,0,16,16);const r=new Ih(i);this.particleMaterial=new Ph({size:t?.45:.6,map:r,transparent:!0,blending:Vo,depthWrite:!1}),this.particles=new yg(this.particleGeometry,this.particleMaterial),this.scene.add(this.particles)}update(t){if(!this.particles)return;const e=this.particleGeometry.attributes.position.array,n=this.themeConfig.colors.sky===330776;for(let l=0;l<this.particleCount;l++){const h=l*3,d=this.particleSpeeds[l];n?(e[h]+=d.x+Math.sin(t*5e-4+l)*.01,e[h+1]-=d.y*.5,e[h+2]+=d.z+Math.cos(t*5e-4+l)*.01,e[h+1]<.5&&(e[h]=(Math.random()-.5)*60,e[h+1]=25,e[h+2]=(Math.random()-.5)*60)):(e[h]+=d.x+Math.sin(t*.001+l)*.015,e[h+1]+=d.y*.4,e[h+2]+=d.z,e[h+1]>22&&(e[h]=(Math.random()-.5)*60,e[h+1]=-1,e[h+2]=(Math.random()-.5)*60))}this.particleGeometry.attributes.position.needsUpdate=!0;let i,s,a,r,c;this.isIndoor?(i=.75,s=.05,a=new Vt(16765312),r=new Vt(790036),c=new Vt(790036)):(i=this.isNight?.18:n?.75:1.1,s=this.isNight?.22:n?.95:1.75,a=new Vt(this.isNight?9479342:n?14280949:16776679),r=new Vt(this.isNight?461586:this.themeConfig.colors.sky),c=new Vt(this.isNight?461586:this.themeConfig.colors.fog)),this.hemiLight&&(this.hemiLight.intensity+=(i-this.hemiLight.intensity)*.04),this.sun&&(this.sun.intensity+=(s-this.sun.intensity)*.04,this.sun.color.lerp(a,.04)),this.scene.background.lerp(r,.04),this.scene.fog&&this.scene.fog.color.lerp(c,.04)}}class aw{constructor(t,e){this.scene=t,this.themeConfig=e,this.colliders=[],this.interactables=[],this.streetlights=[],this.group=new ot;const n=this.themeConfig.colors,i=n.sky===330776;this.materials={sand:new V({color:n.sand,flatShading:!0}),dirt:new V({color:n.dirt,flatShading:!0}),stone:new V({color:i?9479342:13619151,flatShading:!0}),wood:new V({color:i?5125166:10586239,flatShading:!0}),leaves:new V({color:i?1793568:5025616,flatShading:!0}),coconut:new V({color:6111287,flatShading:!0}),umbrellaRed:new V({color:i?13959168:16732754,flatShading:!0}),umbrellaWhite:new V({color:16777215,flatShading:!0}),seaWater:new _t({color:n.seaWater,transparent:!0,opacity:i?.72:.58,side:me}),arcadeBody:new V({color:i?4073251:2503224,flatShading:!0}),arcadeScreen:new _t({color:i?2733814:58998}),neonRed:new _t({color:16732754}),neonBlue:new _t({color:4244735})};const s=this.scene.add;this.scene.add=a=>{a.isLight?s.call(this.scene,a):this.group.add(a)},this.buildWorld(),this.scene.add=s,s.call(this.scene,this.group)}buildWorld(){this.themeConfig.colors.sky,this.createMainGround(0,0,0,22),this.createVastOcean(),this.createOuterBoundaries(),this.decorateAboutZone(),this.decorateSkillsZone(),this.decorateProjectsZone(),this.decorateArcadeZone(),this.createBeachDecorations(),this.createSwing(4.5,.6,6),this.createBallVendor(-5,.6,6),this.createSummerDecorations(),this.createCozyHouse(-10,.6,-9),this.createStreetlamps(),this.createPaimon(2.5,2.5),this.createLakePortal(-6.5,.6,-1.5),this.createCastlePortal(-7.5,.6,7.5)}createFarmField(t,e,n){this.farmGroup=new ot,this.farmGroup.position.set(t,e,n);const i=1.8,s=1.8;this.farmPlots3D=[];for(let a=0;a<2;a++)for(let r=0;r<3;r++){const c=(r-1)*i,l=(a-.5)*s,h=new U(1.4,.12,1.4),d=new w(h,this.materials.dirt);d.position.set(c,.06,l),d.receiveShadow=!0,d.castShadow=!0,this.farmGroup.add(d);const u=new U(1.5,.08,.08),p=this.materials.stone,g=new w(u,p);g.position.set(c,.12,l-.7),this.farmGroup.add(g);const y=new w(u,p);y.position.set(c,.12,l+.7),this.farmGroup.add(y);const m=new w(new U(.08,.08,1.4),p);m.position.set(c-.7,.12,l),this.farmGroup.add(m);const f=new w(new U(.08,.08,1.4),p);f.position.set(c+.7,.12,l),this.farmGroup.add(f);const _=new ot;_.position.set(c,.12,l),this.farmGroup.add(_),this.farmPlots3D.push({row:a,col:r,index:a*3+r,mesh:d,plantGroup:_,x:t+c,z:n+l}),this.interactables.push({id:`farm_plot_${a*3+r}`,name:"农田格子",x:t+c,y:e,z:n+l,triggerRadius:1.2})}this.scene.add(this.farmGroup)}createMainGround(t,e,n,i){const s=new ot;s.position.set(t,e,n);const a=new K(i,i-.2,.6,12),r=new w(a,this.materials.sand);r.position.y=.3,r.receiveShadow=!0,r.castShadow=!0,s.add(r);const c=new K(i-.2,i-1.5,1.8,12),l=new w(c,this.materials.dirt);l.position.y=-.9,l.castShadow=!0,s.add(l),this.scene.add(s),this.colliders.push({mesh:r,radius:i,worldX:t,worldZ:n,worldY:.6,type:"floor"})}createVastOcean(){const t=new wn(160,160),e=new w(t,this.materials.seaWater);e.rotation.x=-Math.PI/2,e.position.y=.18,e.receiveShadow=!0,this.scene.add(e)}createOuterBoundaries(){const n=this.themeConfig.colors.sky===330776;for(let i=0;i<20;i++){const s=i/20*Math.PI*2;if(Math.abs(s)<.2||Math.abs(s-Math.PI)<.2||Math.abs(s-Math.PI/2)<.2)continue;const a=Math.sin(s)*21.2,r=Math.cos(s)*21.2;n?this.createPineTree(a,.6,r,1.1+Math.random()*.3):this.createPalmTree(a,.6,r,1.2+Math.random()*.4)}}createPalmTree(t,e,n,i){const s=new ot;s.position.set(t,e,n),s.scale.set(i,i,i);const a=new ot,r=5;let c=0,l=0;const h=new K(.08,.12,.4,5);for(let g=0;g<r;g++){const y=new w(h,this.materials.wood);y.position.set(l,c+.2,0);const m=.08*g;y.rotation.z=m,y.castShadow=!0,a.add(y),c+=.36*Math.cos(m),l-=.36*Math.sin(m)}s.add(a);const d=new ot;d.position.set(l,c,0);const u=new U(.8,.02,.25);u.translate(.4,0,0);const p=6;for(let g=0;g<p;g++){const y=new w(u,this.materials.leaves);y.rotation.y=g/p*Math.PI*2,y.rotation.z=-.22,y.castShadow=!0,d.add(y)}s.add(d),this.scene.add(s)}createPineTree(t,e,n,i){const s=new ot;s.position.set(t,e,n),s.scale.set(i,i,i);const a=new K(.12,.18,.6,5),r=new w(a,this.materials.wood);r.position.y=.3,r.castShadow=!0,s.add(r);for(let d=0;d<3;d++){const u=new de(.55-d*.12,.6,6),p=new w(u,this.materials.leaves);p.position.y=.7+d*.4,p.castShadow=!0,s.add(p)}const c=new Rt(.06,5,5),l=new _t({color:16776679}),h=new w(c,l);h.position.y=1.7,s.add(h),this.scene.add(s)}decorateAboutZone(){const t=this.themeConfig.colors.sky===330776,e=new ot;e.position.set(0,.6,0);const n=new K(.07,.07,.6,5);n.translate(0,-.3,0),n.rotateZ(.95);for(let d=0;d<3;d++){const u=new w(n,this.materials.wood);u.position.set(-1.8,.35,1.8),u.rotation.y=d*Math.PI*2/3,u.castShadow=!0,e.add(u)}const i=new ot;i.position.set(-1.8,.15,1.8);const s=new _t({color:16733986}),a=new de(.18,.45,5),r=new w(a,s);r.position.set(0,.2,0),i.add(r);const c=new w(a,new _t({color:16748800}));c.position.set(.08,.15,-.05),c.rotation.z=.2,c.scale.set(.8,.8,.8),i.add(c);const l=new w(a,new _t({color:16766464}));l.position.set(-.08,.12,.06),l.rotation.z=-.2,l.scale.set(.7,.7,.7),i.add(l),e.add(i);const h=new Ze(16733986,0,10,1.2);if(h.position.set(-1.8,.8,1.8),this.scene.add(h),this.streetlights.push(h),t){this.createSnowman(1.8,.6,-1.3);const d=new ot;d.position.set(1.5,.04,-2.2),d.rotation.y=-.45;const u=new w(new U(1.2,.08,.4),this.materials.wood);u.position.y=.25,u.castShadow=!0,d.add(u);const p=new w(new U(.08,.25,.35),this.materials.wood);p.position.set(-.5,.125,0),p.castShadow=!0,d.add(p);const g=new w(new U(.08,.25,.35),this.materials.wood);g.position.set(.5,.125,0),g.castShadow=!0,d.add(g),e.add(d)}else{const d=new w(new U(.5,.08,1.1),this.materials.umbrellaWhite);d.position.set(1.5,.04,-1.2),d.rotation.y=-.4,d.castShadow=!0,e.add(d);const u=new w(new U(.48,.1,.25),this.materials.umbrellaRed);u.position.set(1.5,.12,-1.6),u.rotation.y=-.4,e.add(u);const p=new ot;p.position.set(2.4,0,-2.4);const g=new w(new K(.04,.04,2.2,5),this.materials.wood);g.position.y=1.1,g.castShadow=!0,p.add(g);const y=new de(1.2,.5,8),m=new w(y,this.materials.umbrellaRed);m.position.y=2.1,m.castShadow=!0,p.add(m);const f=new w(new de(1.22,.48,8),this.materials.umbrellaWhite);f.position.y=2.1,f.rotation.y=Math.PI/8,p.add(f),e.add(p)}this.scene.add(e),this.interactables.push({id:"about",name:"关于我",x:0,y:.6,z:0,triggerRadius:3.5})}createSnowman(t,e,n){const i=new ot;i.position.set(t,e,n);const s=new w(new Rt(.4,8,8),this.materials.umbrellaWhite);s.position.y=.4,s.castShadow=!0,i.add(s);const a=new w(new Rt(.26,8,8),this.materials.umbrellaWhite);a.position.y=.9,a.castShadow=!0,i.add(a);const r=new de(.04,.12,4);r.rotateX(Math.PI/2);const c=new w(r,new V({color:16754470}));c.position.set(0,.9,.26),i.add(c);const l=new Rt(.03,4,4),h=new _t({color:1118481}),d=new w(l,h);d.position.set(-.08,.96,.23);const u=new w(l,h);u.position.set(.08,.96,.23),i.add(d),i.add(u);const p=new w(new K(.24,.24,.08,8),this.materials.umbrellaRed);p.position.y=.7,i.add(p);const g=new w(new K(.15,.18,.2,8),this.materials.arcadeBody);g.position.y=1.18,g.castShadow=!0,i.add(g),this.scene.add(i)}decorateSkillsZone(){const t=this.themeConfig.colors.sky===330776,e=-12,n=-3,i=.6;if(t){const s=new ot;s.position.set(e,i,n);const a=new w(new K(.3,.4,1.8,8),this.materials.wood);a.position.y=.9,a.castShadow=!0,s.add(a);for(let h=0;h<4;h++){const d=new w(new de(1.6-h*.35,1.6,8),this.materials.leaves);d.position.y=1.8+h*.9,d.castShadow=!0,s.add(d)}const r=new w(new Rt(.18,6,6),new _t({color:16771899}));r.position.y=5.2,s.add(r);const c=[16732754,4244735,16771899,14696699];for(let h=0;h<12;h++){const d=new w(new Rt(.12,5,5),new _t({color:c[h%c.length]})),u=1.8+Math.floor(h/3)*.9,p=1.3-Math.floor(h/3)*.3,g=h%3*(Math.PI*2/3)+u*.5;d.position.set(Math.cos(g)*p,u+.2,Math.sin(g)*p),s.add(d)}const l=[16732754,4244735,14696699];for(let h=0;h<3;h++){const d=new w(new U(.4,.4,.4),new V({color:l[h],flatShading:!0}));d.position.set(.6-h*.5,.2,.5+h*.2),d.rotation.y=h*.4,d.castShadow=!0,s.add(d)}this.scene.add(s)}else{const s=new ot;s.position.set(e,i,n);const a=new K(.24,.4,4.2,7),r=new w(a,this.materials.wood);r.position.y=2.1,r.rotation.z=-.1,r.castShadow=!0,s.add(r);const c=new ot;c.position.set(-.2,4.1,0);const l=new U(2,.02,.45);l.translate(1,0,0);const h=8;for(let u=0;u<h;u++){const p=new w(l,this.materials.leaves);p.rotation.y=u/h*Math.PI*2,p.rotation.z=-.25,p.castShadow=!0,c.add(p)}s.add(c);const d=new Rt(.24,5,5);for(let u=0;u<3;u++){const p=new w(d,this.materials.coconut),g=u/3*Math.PI*2;p.position.set(-.2+Math.cos(g)*.3,3.8,Math.sin(g)*.3),p.castShadow=!0,s.add(p)}this.scene.add(s)}this.interactables.push({id:"skills",name:"技术栈",x:-12,y:.6,z:-1,triggerRadius:3})}decorateProjectsZone(){const t=this.themeConfig.colors.sky===330776,e=12,n=-3,i=.6,s=new ot;s.position.set(e,i,n);const a=new K(.08,.08,2.5,5),r=new w(a,this.materials.wood);r.position.set(-1.8,1.25,0),r.castShadow=!0,s.add(r);const c=new w(a,this.materials.wood);c.position.set(1.8,1.25,0),c.castShadow=!0,s.add(c);const l=new w(new U(3.6,2,.15),this.materials.wood);l.position.y=2.25,l.castShadow=!0,s.add(l);const h=new w(new U(3.2,1.7,.08),this.materials.stone);h.position.set(0,2.25,.06),s.add(h);const d=new V({color:t?13959168:4244735,flatShading:!0}),u=new V({color:t?3046706:16754470,flatShading:!0}),p=new Rt(.32,8,8);p.scale(1,2.4,.12);const g=new w(p,d);g.position.set(-1.2,.6,.2),g.rotation.set(.1,.2,-.15),g.castShadow=!0,s.add(g);const y=new w(p,u);y.position.set(1.2,.6,.2),y.rotation.set(.1,-.2,.15),y.castShadow=!0,s.add(y);const m=new Rt(.08,5,5),f=new _t({color:16774557}),_=new w(m,f);_.position.set(-1.8,3.3,.1),s.add(_);const x=new w(m,f);x.position.set(1.8,3.3,.1),s.add(x);const M=new Ze(16774557,0,6,1.2);M.position.set(e-1.8,i+3.3,n+.1),this.scene.add(M),this.streetlights.push(M);const R=new Ze(16774557,0,6,1.2);R.position.set(e+1.8,i+3.3,n+.1),this.scene.add(R),this.streetlights.push(R),this.scene.add(s),this.interactables.push({id:"projects",name:"项目展示",x:12,y:.6,z:-1,triggerRadius:3})}decorateArcadeZone(){const t=this.themeConfig.colors.sky===330776,e=0,n=-12,i=.6,s=new ot;s.position.set(e,i,n);const a=new w(new U(1.2,1,1),this.materials.arcadeBody);a.position.y=.5,a.castShadow=!0,s.add(a);const r=new w(new U(1.2,1.2,.8),this.materials.arcadeBody);r.position.set(0,1.4,-.1),r.castShadow=!0,s.add(r);const c=new wn(.95,.72);c.rotateX(-.1);const l=new w(c,this.materials.arcadeScreen);l.position.set(0,1.4,.31),s.add(l);const h=new w(new U(1.3,.2,.5),this.materials.arcadeBody);h.position.set(0,.95,.3),h.rotation.x=.15,h.castShadow=!0,s.add(h);const d=new w(new K(.015,.015,.18,4),this.materials.stone);d.position.set(-.3,1.05,.4),d.rotation.x=.15,s.add(d);const u=new w(new Rt(.05,5,5),this.materials.neonRed);u.position.set(-.3,1.14,.42),s.add(u);const p=new K(.035,.035,.03,5);p.rotateX(.15);for(let P=0;P<3;P++){const O=new w(p,P%2===0?this.materials.neonRed:this.materials.neonBlue);O.position.set(.15+P*.12,1,.4),s.add(O)}const g=new w(new U(1.2,.25,.85),this.materials.arcadeBody);g.position.set(0,2.05,-.05),s.add(g);const y=new w(new wn(1,.18),new _t({color:t?2733814:16754470}));y.position.set(0,2.05,.38),s.add(y);const m=new K(.04,.04,1.5,5),f=new w(m,this.materials.wood);f.position.set(-.9,.75,.2),f.castShadow=!0,s.add(f);const _=new w(m,this.materials.wood);_.position.set(.9,.75,.2),_.castShadow=!0,s.add(_);const x=new de(.08,.22,5),M=new _t({color:16740419}),R=new w(x,M);R.position.set(-.9,1.62,.2),s.add(R);const A=new w(x,M);A.position.set(.9,1.62,.2),s.add(A);const E=new Ze(16733986,0,5,1.2);E.position.set(e-.9,i+1.62,n+.2),this.scene.add(E),this.streetlights.push(E);const I=new Ze(16733986,0,5,1.2);I.position.set(e+.9,i+1.62,n+.2),this.scene.add(I),this.streetlights.push(I),this.scene.add(s);const v=t?2733814:65280,S=new Kg(v,2,6,Math.PI/6,.5,1);S.position.set(0,4,-12),S.target=a,this.scene.add(S),this.interactables.push({id:"arcade",name:"复古街机",x:0,y:.6,z:-10.4,triggerRadius:2.2})}createBeachDecorations(){const t=this.themeConfig.colors.sky===330776,e=new zs(21.8,22.2,32);e.rotateX(-Math.PI/2);const n=new _t({color:16777215,transparent:!0,opacity:t?.95:.8,side:me}),i=new w(e,n);i.position.y=.22,this.scene.add(i),this.createBeachBall(.6,.6,-1.8,.24,t?16777215:16732754),this.createBeachBall(10,.6,-1.5,.26,t?16777215:4244735),t?(this.createSnowHeap(3.5,.61,2.5,.2),this.createSnowHeap(-10.5,.61,1.5,.28),this.createSnowHeap(-3.5,.61,-1.5,.18),this.createSnowHeap(8.5,.61,3.5,.24)):(this.createStarfish(3.5,.61,2.5,16740419),this.createStarfish(-10.5,.61,1.5,16740419),this.createShell(-3.5,.61,-1.5,16775620),this.createShell(8.5,.61,3.5,16775620),this.createExtraUmbrella(-5.8,.6,-5,4244735),this.createExtraUmbrella(8,.6,-7,16771899))}createBeachBall(t,e,n,i,s){const a=new ot;a.position.set(t,e+i,n);const r=new Rt(i,8,8),c=new V({color:s,flatShading:!0}),l=new w(r,c);l.castShadow=!0,a.add(l);const h=new K(i+.005,i+.005,i*.4,8,1,!0),d=s===16777215?13959168:16777215,u=new V({color:d,flatShading:!0}),p=new w(h,u);p.rotation.z=Math.PI/4,a.add(p),this.scene.add(a)}createStarfish(t,e,n,i){const s=new de(.18,.05,5),a=new V({color:i,flatShading:!0}),r=new w(s,a);r.position.set(t,e,n),r.rotation.x=Math.PI/2,r.rotation.z=Math.random()*Math.PI,r.castShadow=!0,this.scene.add(r)}createShell(t,e,n,i){const s=new Fr(.12,1);s.scale(1.2,.8,.8);const a=new V({color:i,flatShading:!0}),r=new w(s,a);r.position.set(t,e,n),r.rotation.set(Math.random()*.4,Math.random()*Math.PI,Math.random()*.4),r.castShadow=!0,this.scene.add(r)}createSnowHeap(t,e,n,i){const s=new Rt(i,5,4);s.scale(1.2,.5,1.2);const a=new w(s,this.materials.umbrellaWhite);a.position.set(t,e+i*.25,n),a.castShadow=!0,this.scene.add(a)}createExtraUmbrella(t,e,n,i){const s=new ot;s.position.set(t,e,n);const a=new w(new K(.03,.03,1.8,5),this.materials.wood);a.position.y=.9,a.castShadow=!0,s.add(a);const r=new V({color:i,flatShading:!0}),c=new V({color:16777215,flatShading:!0}),l=new w(new de(.9,.4,8),r);l.position.y=1.7,l.castShadow=!0,s.add(l);const h=new w(new de(.92,.38,8),c);h.position.y=1.7,h.rotation.y=Math.PI/8,s.add(h),this.scene.add(s)}createSwing(t,e,n){const i=new ot;i.position.set(t,e,n);const s=new K(.05,.05,2.1,6);s.translate(0,-1.05,0);const a=new w(s,this.materials.wood);a.position.set(-1,2.05,0),a.rotation.set(-.19,0,-.15),a.castShadow=!0,i.add(a);const r=new w(s,this.materials.wood);r.position.set(-1,2.05,0),r.rotation.set(.19,0,-.15),r.castShadow=!0,i.add(r);const c=new w(s,this.materials.wood);c.position.set(1,2.05,0),c.rotation.set(-.19,0,.15),c.castShadow=!0,i.add(c);const l=new w(s,this.materials.wood);l.position.set(1,2.05,0),l.rotation.set(.19,0,.15),l.castShadow=!0,i.add(l);const h=new w(new K(.05,.05,2.25,6),this.materials.wood);h.rotation.z=Math.PI/2,h.position.set(0,2.05,0),h.castShadow=!0,i.add(h),this.swingSeat=new ot,this.swingSeat.position.set(0,2.05,0);const d=new w(new U(.6,.03,.22),this.materials.wood);d.position.set(0,-1.1,0),d.castShadow=!0,this.swingSeat.add(d);const u=new w(new K(.01,.01,1.1),this.materials.stone);u.position.set(-.24,-.55,0),this.swingSeat.add(u);const p=new w(new K(.01,.01,1.1),this.materials.stone);p.position.set(.24,-.55,0),this.swingSeat.add(p),i.add(this.swingSeat),this.scene.add(i),this.interactables.push({id:"swing",name:"秋千",x:t,y:e,z:n+.6,triggerRadius:1.8})}createBallVendor(t,e,n){const i=this.themeConfig.colors.sky===330776,s=new ot;s.position.set(t,e,n);const a=new w(new U(1.6,.8,.8),this.materials.wood);a.position.y=.4,a.castShadow=!0,a.receiveShadow=!0,s.add(a);const r=new w(new U(1.7,.08,.9),this.materials.sand);r.position.y=.84,r.castShadow=!0,s.add(r);const c=new K(.03,.03,1.4,5),l=new w(c,this.materials.wood);l.position.set(-.7,1.4,-.3),l.castShadow=!0,s.add(l);const h=new w(c,this.materials.wood);h.position.set(.7,1.4,-.3),h.castShadow=!0,s.add(h);const d=new w(new U(1.8,.06,1.1),this.materials.umbrellaRed);d.position.set(0,2.15,.1),d.rotation.x=.28,d.castShadow=!0,s.add(d);const u=new w(new U(1.82,.05,.3),this.materials.umbrellaWhite);u.position.set(0,2.15,.1),u.rotation.x=.28,s.add(u);const p=new w(new U(.6,.25,.5),this.materials.coconut);p.position.set(-.35,.98,.05),p.castShadow=!0,s.add(p);const g=new Rt(.12,6,6),y=i?[16777215,16777215,16777215]:[16732754,4244735,16771899];for(let _=0;_<3;_++){const x=new w(g,new V({color:y[_],flatShading:!0}));x.position.set(-.42+_*.12,1.08,.05+_%2*.05),s.add(x)}const m=new w(new U(.6,.25,.05),this.materials.umbrellaWhite);m.position.set(.35,1.2,.15),m.rotation.y=-.15,m.castShadow=!0,s.add(m);const f=new w(new U(.4,.08,.06),new V({color:i?13959168:5025616}));f.position.set(.35,1.2,.16),f.rotation.y=-.15,s.add(f),this.scene.add(s),this.interactables.push({id:"ball_vendor",name:i?"领雪球":"领沙滩球",x:t,y:e,z:n+.8,triggerRadius:1.8})}createCozyHouse(t,e,n){const i=this.themeConfig.colors.sky===330776,s=new ot;s.position.set(t,e,n);const a=new U(4,.12,4),r=new w(a,this.materials.wood);r.position.y=.06,r.receiveShadow=!0,r.castShadow=!0,s.add(r),this.colliders.push({mesh:r,radius:2.2,worldX:t,worldZ:n,worldY:e+.12,type:"floor"});const c=new U(.2,3.2,.2);[{x:-1.9,z:-1.9},{x:1.9,z:-1.9},{x:-1.9,z:1.9},{x:1.9,z:1.9}].forEach(P=>{const O=new w(c,this.materials.wood);O.position.set(P.x,1.6,P.z),O.castShadow=!0,s.add(O)});const h=new V({color:i?6323595:14742257,flatShading:!0}),d=new w(new U(3.8,3.2,.08),h);d.position.set(0,1.6,-1.9),d.castShadow=!0,s.add(d);const u=new w(new U(.08,3.2,3.8),h);u.position.set(-1.9,1.6,0),u.castShadow=!0,s.add(u);const p=new w(new U(.08,3.2,3.8),h);p.position.set(1.9,1.6,0),p.castShadow=!0,s.add(p);const g=new w(new U(1.3,3.2,.08),h);g.position.set(-1.25,1.6,1.9),g.castShadow=!0,s.add(g);const y=new w(new U(1.3,3.2,.08),h);y.position.set(1.25,1.6,1.9),y.castShadow=!0,s.add(y);const m=new w(new U(1.2,1,.08),h);m.position.set(0,2.7,1.9),m.castShadow=!0,s.add(m);const f=new zh;f.moveTo(-1.9,3.2),f.lineTo(1.9,3.2),f.lineTo(0,4.15),f.closePath();const _=new Br(f,{depth:.08,bevelEnabled:!1}),x=new w(_,h);x.position.set(0,0,1.9-.08),x.castShadow=!0,s.add(x);const M=new w(_,h);M.position.set(0,0,-1.9),M.castShadow=!0,s.add(M);const R=i?13959168:16740419,A=new V({color:R,flatShading:!0}),E=new w(new U(2.5,.08,4),A);E.position.set(-1.05,3.68,0),E.rotation.z=.48,E.castShadow=!0,s.add(E);const I=new w(new U(2.5,.08,4),A);I.position.set(1.05,3.68,0),I.rotation.z=-.48,I.castShadow=!0,s.add(I);const v=new w(new U(.7,.22,.03),this.materials.wood);v.position.set(0,2.4,1.92),s.add(v);const S=new w(new U(.4,.08,.04),new V({color:5025616}));S.position.set(0,2.4,1.94),s.add(S),this.interactables.push({id:"enter_house",name:"进入房子",x:t,y:e+.12,z:n+1.9,triggerRadius:1.5}),this.scene.add(s)}createSummerDecorations(){const t=this.themeConfig.colors.sky===330776;if(this.swimRings=[],t){const a=new U(.8,.38,.8),r=new V({color:16119285,flatShading:!0}),c=new w(a,r);c.position.set(13,.18,13),c.castShadow=!0,this.scene.add(c),this.swimRings.push({mesh:c,baseX:13,baseZ:13,phase:0});const l=new w(a,r);l.position.set(-13,.18,12),l.castShadow=!0,this.scene.add(l),this.swimRings.push({mesh:l,baseX:-13,baseZ:12,phase:Math.PI})}else{const a=new Vn(.3,.08,6,12);a.rotateX(Math.PI/2);const r=new V({color:16728193,flatShading:!0}),c=new V({color:16771899,flatShading:!0}),l=new w(a,r);l.position.set(-2.2,.62,-2.5),l.rotation.set(.1,0,.15),l.castShadow=!0,this.scene.add(l);const h=new w(a,c);h.position.set(13,.18,13),this.scene.add(h),this.swimRings.push({mesh:h,baseX:13,baseZ:13,phase:0});const d=new w(a,r);d.position.set(-13,.18,12),this.scene.add(d),this.swimRings.push({mesh:d,baseX:-13,baseZ:12,phase:Math.PI})}const e=new ot;e.position.set(2.4,0,-2.4);const n=t?[16732754,5025616,16771899]:[16732754,4244735,16771899],i=new Rt(.18,6,6);i.scale(1,1.25,1);const s=new K(.005,.005,.8,4);for(let a=0;a<3;a++){const r=new V({color:n[a],flatShading:!0}),c=new w(i,r),l=a/3*Math.PI*2,h=Math.cos(l)*.22,d=Math.sin(l)*.22,u=1.3+Math.random()*.25;c.position.set(h,u,d),c.rotation.z=(Math.random()-.5)*.2,c.castShadow=!0,e.add(c);const p=new w(s,this.materials.stone);p.position.set(h/2,u-.4,d/2),p.lookAt(new L(h,u,d)),p.rotateX(Math.PI/2),e.add(p)}this.scene.add(e),this.balloons=e}update(t,e){if(this.swingSeat&&(this.swingSeat.rotation.x=Math.sin(t*.002)*.18),this.swimRings&&this.swimRings.forEach(n=>{n.mesh.position.y=.18+Math.sin(t*.0016+n.phase)*.04,n.mesh.rotation.y=t*3e-4+n.phase}),this.balloons&&(this.balloons.rotation.z=Math.sin(t*.0015)*.06,this.balloons.rotation.x=Math.cos(t*.001)*.04),this.streetlights){const n=e&&e.isNight?1.4:0;this.streetlights.forEach(i=>{let s=n;i.color.getHex()===16733986&&e&&e.isNight&&(s=1.4+Math.sin(t*.02)*.25+(Math.random()-.5)*.12),i.intensity+=(s-i.intensity)*.08})}this.paimon&&(this.paimon.position.y=1.25+Math.sin(t*.0025)*.08,this.paimon.rotation.y=t*6e-4)}createStreetlamps(){this.streetlights=[],this.createStreetlamp(-8,-4,16711807),this.createStreetlamp(-4,-11,62975),this.createStreetlamp(2,4,3800852),this.createFairyLightsDecoration()}createStreetlamp(t,e,n=16771899){const i=new ot;i.position.set(t,.6,e);const s=new K(.06,.08,2.2,4),a=new w(s,this.materials.wood);a.position.y=1.1,a.castShadow=!0,i.add(a);const r=new _t({color:n}),c=new w(new U(.4,.06,.06),r);c.position.set(.18,2.1,0),i.add(c);const l=new w(new K(.1,.16,.28,5),this.materials.arcadeBody);l.position.set(.36,1.9,0),l.castShadow=!0,i.add(l);const h=new _t({color:n}),d=new w(new Rt(.08,5,5),h);d.position.set(.36,1.76,0),i.add(d),this.scene.add(i);const u=new Ze(n,0,9,1.3);u.position.set(t+.36,2.3,e),this.scene.add(u),this.streetlights.push(u)}createFairyLightString(t,e,n=12,i=.4){const s=[16711765,62975,3800852,16771899,12386559,16748800],a=[],r=20;for(let p=0;p<=r;p++){const g=p/r,y=t.x+(e.x-t.x)*g,m=t.z+(e.z-t.z)*g,f=t.y+(e.y-t.y)*g-i*Math.sin(g*Math.PI);a.push(new L(y,f,m))}const c=new Dh(a),l=new Or(c,20,.012,4,!1),h=new V({color:2236962}),d=new w(l,h);this.scene.add(d);const u=new Rt(.06,5,5);for(let p=0;p<n;p++){const g=(p+.5)/n,y=c.getPointAt(g),m=s[p%s.length],f=new _t({color:m}),_=new w(u,f);if(_.position.copy(y),this.scene.add(_),p%3===1){const x=new Ze(m,0,4,1.5);x.position.copy(y),x.userData={maxIntensity:.85},this.scene.add(x),this.streetlights.push(x)}}}createFairyLightsDecoration(){this.createFairyLightString(new L(-11.9,3.8,-7.1),new L(-8.1,3.8,-7.1),10,.35),this.createFairyLightString(new L(-8.1,3.65,-6.9),new L(-8,2.8,-4),12,.5),this.createFairyLightString(new L(3.5,2.65,6),new L(5.5,2.65,6),8,.25)}createPaimon(t,e){this.themeConfig.colors.sky;const n=new ot;n.position.set(t,1.25,e);const i=new V({color:16769202,flatShading:!0}),s=new w(new Rt(.18,8,8),i);s.position.y=.18,s.castShadow=!0,n.add(s);const a=new V({color:16776432,flatShading:!0}),r=new w(new Rt(.2,6,6),a);r.position.set(0,.22,-.02),n.add(r);const c=new de(.06,.25,4);c.rotateX(Math.PI/6);const l=new w(c,a);l.position.set(-.16,.08,-.04),l.rotation.z=.3,l.castShadow=!0,n.add(l);const h=new w(c,a);h.position.set(.16,.08,-.04),h.rotation.z=-.3,h.castShadow=!0,n.add(h);const d=new _t({color:1710618}),u=new w(new K(.08,.1,.05,5),d);u.position.y=.36,n.add(u);const p=new V({color:16777215,flatShading:!0}),g=new w(new de(.12,.32,5),p);g.position.y=-.08,g.rotation.x=Math.PI,g.castShadow=!0,n.add(g);const y=new _t({color:870305}),m=new w(new U(.14,.04,.04),y);m.position.set(0,.06,.1),n.add(m);const f=new V({color:2503224,flatShading:!0}),_=new w(new U(.24,.35,.04),f);_.position.set(0,-.1,-.1),_.rotation.x=.1,n.add(_),this.scene.add(n),this.paimon=n,this.interactables.push({id:"paimon",name:"派蒙 (打开菜单)",x:t,y:.6,z:e,triggerRadius:2.2})}createLakePortal(t,e,n){const i=new ot;i.position.set(t,e,n);const s=11583173,a=new V({color:s,flatShading:!0}),r=new w(new K(.9,1,.22,12),a);r.position.y=.11,r.castShadow=!0,r.receiveShadow=!0,i.add(r);const c=new w(new K(.75,.65,.35,12),a);c.position.y=.38,c.castShadow=!0,c.receiveShadow=!0,i.add(c);const l=new _t({color:45311,transparent:!0,opacity:.65,side:me}),h=new w(new Pn(.7,12),l);h.rotateX(-Math.PI/2),h.position.y=.54,i.add(h);const d=new K(.08,.16,.9,8),u=new _t({color:14743546,transparent:!0,opacity:.82}),p=new w(d,u);p.position.y=.95,i.add(p);const g=new _t({color:16777215}),y=new w(new U(.08,.08,.08),g);y.position.set(.12,1.35,.08),i.add(y);const m=y.clone();m.position.set(-.14,1.4,-.1),i.add(m);const f=y.clone();f.position.set(.05,1.25,-.15),i.add(f);const _=new w(new K(.03,.03,.8,8),new V({color:5125166}));_.position.set(1,.4,.4),_.rotation.z=.15,_.castShadow=!0,i.add(_);const x=new w(new U(.55,.16,.03),new V({color:9268835}));x.position.set(1.05,.72,.4),x.rotation.z=.15,x.rotation.y=.2,x.castShadow=!0,i.add(x);const M=new w(new U(.38,.06,.04),new _t({color:58879}));M.position.set(1.04,.72,.42),M.rotation.z=.15,M.rotation.y=.2,i.add(M),this.scene.add(i),this.interactables.push({id:"enter_lake",name:"前往云顶天池",x:t,y:e,z:n,triggerRadius:1.8})}createCastlePortal(t,e,n){const i=new ot;i.position.set(t,e,n);const s=16764117,a=new V({color:s,flatShading:!0}),r=new w(new K(.9,1,.22,12),a);r.position.y=.11,r.castShadow=!0,r.receiveShadow=!0,i.add(r);const c=new w(new K(.75,.65,.35,12),a);c.position.y=.38,c.castShadow=!0,c.receiveShadow=!0,i.add(c);const l=new _t({color:16739211,transparent:!0,opacity:.7,side:me}),h=new w(new Pn(.7,12),l);h.rotateX(-Math.PI/2),h.position.y=.54,i.add(h);const d=new K(.08,.16,.9,8),u=new _t({color:16773363,transparent:!0,opacity:.85}),p=new w(d,u);p.position.y=.95,i.add(p);const g=new _t({color:16777215}),y=new w(new U(.08,.08,.08),g);y.position.set(.12,1.35,.08),i.add(y);const m=y.clone();m.position.set(-.14,1.4,-.1),i.add(m);const f=y.clone();f.position.set(.05,1.25,-.15),i.add(f);const _=new w(new K(.03,.03,.8,8),new V({color:6111287}));_.position.set(1,.4,.4),_.rotation.z=.15,_.castShadow=!0,i.add(_);const x=new w(new U(.55,.16,.03),new V({color:16747937}));x.position.set(1.05,.72,.4),x.rotation.z=.15,x.rotation.y=.2,x.castShadow=!0,i.add(x);const M=new w(new U(.38,.06,.04),new _t({color:16728193}));M.position.set(1.04,.72,.42),M.rotation.z=.15,M.rotation.y=.2,i.add(M),this.scene.add(i),this.interactables.push({id:"enter_castle",name:"前往粉色庄园",x:t,y:e,z:n,triggerRadius:1.8})}}class rw{constructor(t,e){this.scene=t,this.themeConfig=e,this.colliders=[],this.interactables=[],this.group=new ot,this.materials={wood:new V({color:7951688,flatShading:!0}),woodLight:new V({color:14142664,flatShading:!0}),wall:new V({color:16448250,flatShading:!0}),wallTrim:new V({color:15723497,flatShading:!0}),glass:new _t({color:14743546,transparent:!0,opacity:.25,side:me}),leaves:new V({color:4431943,flatShading:!0}),coconut:new V({color:4073251,flatShading:!0}),carpet:new V({color:16772275,flatShading:!0}),sofaBody:new V({color:12310267,flatShading:!0}),sofaCushion:new V({color:14938877,flatShading:!0}),metalGold:new V({color:16763432,flatShading:!0}),white:new V({color:16777215,flatShading:!0}),paintingSun:new _t({color:16771899}),paintingArt:new _t({color:16740419}),bedSpread:new V({color:16747136,flatShading:!0})},this.buildHouseMap(),this.scene.add(this.group)}buildHouseMap(){const t=new U(24,.12,24),e=new w(t,this.materials.woodLight);e.position.y=.06,e.receiveShadow=!0,e.castShadow=!0,this.group.add(e),this.colliders.push({mesh:e,radius:16,worldX:0,worldZ:0,worldY:.12,type:"floor"});const n=new U(.4,5.5,.4);[{x:-11.8,z:-11.8},{x:11.8,z:-11.8},{x:-11.8,z:11.8},{x:11.8,z:11.8}].forEach(M=>{const R=new w(n,this.materials.wood);R.position.set(M.x,2.75,M.z),R.castShadow=!0,this.group.add(R)});for(let M=-10;M<=10;M+=5){const R=new U(23.6,.15,.25),A=new w(R,this.materials.wood);A.position.set(0,5.4,M),this.group.add(A)}const s=new w(new U(23.6,5.5,.1),this.materials.wall);s.position.set(0,2.75,-11.8),s.castShadow=!0,s.receiveShadow=!0,this.group.add(s);const a=new w(new U(.1,5.5,23.6),this.materials.wall);a.position.set(11.8,2.75,0),a.castShadow=!0,a.receiveShadow=!0,this.group.add(a);const r=new w(new U(.1,5.5,5.8),this.materials.wall);r.position.set(-11.8,2.75,-8.9),r.castShadow=!0,this.group.add(r);const c=new w(new U(.1,5.5,5.8),this.materials.wall);c.position.set(-11.8,2.75,8.9),c.castShadow=!0,this.group.add(c);const l=new w(new U(.1,1.6,12),this.materials.wall);l.position.set(-11.8,.8,0),l.castShadow=!0,this.group.add(l);const h=new w(new U(.1,1.4,12),this.materials.wall);h.position.set(-11.8,4.8,0),h.castShadow=!0,this.group.add(h);const d=new w(new U(.04,2.4,12),this.materials.glass);d.position.set(-11.8,2.8,0),this.group.add(d);const u=new w(new U(10.6,5.5,.1),this.materials.wall);u.position.set(-6.5,2.75,11.8),u.castShadow=!0,this.group.add(u);const p=new w(new U(10.6,5.5,.1),this.materials.wall);p.position.set(6.5,2.75,11.8),p.castShadow=!0,this.group.add(p);const g=new w(new U(2.4,2.5,.1),this.materials.wall);g.position.set(0,4.25,11.8),g.castShadow=!0,this.group.add(g);const y=new w(new U(2.5,3.1,.2),this.materials.wood);y.position.set(0,1.5,11.8),this.group.add(y);const m=new w(new U(1.3,.35,.05),this.materials.wood);m.position.set(0,3.25,11.68),m.castShadow=!0,this.group.add(m);const f=new w(new U(.8,.12,.06),new V({color:16732754}));f.position.set(0,3.25,11.7),this.group.add(f),this.interactables.push({id:"exit_house",name:"离开房子",x:0,y:.12,z:11.2,triggerRadius:1.6}),this.createBed(-8,-7),this.createEasel(8,-8),this.createWardrobe(11,0),this.createSofaLounge(0,-2),this.createDiningTable(-10.5,0),this.createMonstera(-9.5,9.5);const _=new K(4,4,.01,24),x=new w(_,this.materials.carpet);x.position.set(0,.125,3),x.receiveShadow=!0,this.group.add(x),this.createSunsetPainting(0,-11.73),this.createReservedSpot(8.5,8.5),this.createCeilingLight(),this.createWindowScenery(),this.createFloorLamp(1.8,-3.2)}createBed(t,e){const n=new ot;n.position.set(t,.12,e);const i=new w(new U(2.6,.32,3),this.materials.wood);i.castShadow=!0,n.add(i);const s=new w(new U(2.4,.28,2.8),this.materials.white);s.position.y=.24,n.add(s);const a=new w(new U(2.42,.29,2),this.materials.bedSpread);a.position.set(0,.26,.4),a.castShadow=!0,n.add(a);const r=new w(new U(.9,.16,.5),this.materials.white);r.position.set(-.55,.4,-1),n.add(r);const c=new w(new U(.9,.16,.5),this.materials.white);c.position.set(.55,.4,-1),n.add(c);const l=new w(new U(.7,.5,.7),this.materials.wood);l.position.set(-1.8,.1,-1),l.castShadow=!0,n.add(l);const h=new w(new U(.7,.5,.7),this.materials.wood);h.position.set(1.8,.1,-1),h.castShadow=!0,n.add(h);const d=new w(new K(.08,.08,.18,4),this.materials.metalGold);d.position.set(-1.8,.44,-1),n.add(d);const u=new w(new K(.12,.18,.2,8),this.materials.white);u.position.set(-1.8,.62,-1),n.add(u);const p=new Ze(16758605,.9,8,1.5);p.position.set(-1.8,.65,-1),n.add(p),this.group.add(n),this.interactables.push({id:"house_bed",name:"躺下",x:t,y:.12,z:e,triggerRadius:2})}createEasel(t,e){const n=new ot;n.position.set(t,.12,e),n.rotation.y=-Math.PI/4;const i=new w(new K(.035,.035,2.4,4),this.materials.wood);i.position.set(-.5,1.15,0),i.rotation.z=-.15,i.castShadow=!0,n.add(i);const s=new w(new K(.035,.035,2.4,4),this.materials.wood);s.position.set(.5,1.15,0),s.rotation.z=.15,s.castShadow=!0,n.add(s);const a=new w(new K(.035,.035,2.4,4),this.materials.wood);a.position.set(0,1.15,-.5),a.rotation.x=.22,a.castShadow=!0,n.add(a);const r=new w(new U(1.4,.07,.14),this.materials.wood);r.position.set(0,1.05,.08),r.castShadow=!0,n.add(r);const c=new w(new U(1.2,.9,.04),this.materials.white);c.position.set(0,1.5,.08),c.rotation.x=-.08,c.castShadow=!0,n.add(c);const l=new w(new wn(1.14,.84),new _t({color:11725810}));l.position.set(0,1.5,.11),l.rotation.x=-.08,n.add(l);const h=new w(new Rt(.11,6,6),this.materials.paintingSun);h.position.set(.2,1.62,.12),n.add(h);const d=new w(new wn(1.14,.35),new _t({color:48340}));d.position.set(0,1.28,.12),d.rotation.x=-.08,n.add(d),this.group.add(n),this.interactables.push({id:"house_easel",name:"写生",x:t,y:.12,z:e,triggerRadius:1.8})}createWardrobe(t,e){const n=new ot;n.position.set(t,.12,e);const i=new w(new U(.9,2.8,1.8),this.materials.wood);i.position.y=1.4,i.castShadow=!0,i.receiveShadow=!0,n.add(i);const s=new w(new U(.06,2.5,.82),this.materials.woodLight);s.position.set(-.46,1.4,-.42),n.add(s);const a=new w(new U(.06,2.5,.82),this.materials.woodLight);a.position.set(-.46,1.4,.42),n.add(a);const r=new w(new Rt(.06,4,4),this.materials.metalGold);r.position.set(-.52,1.4,-.08),n.add(r);const c=new w(new Rt(.06,4,4),this.materials.metalGold);c.position.set(-.52,1.4,.08),n.add(c);const l=new U(2,.01,1.8),h=new w(l,this.materials.carpet);h.position.set(-1.4,.005,0),h.receiveShadow=!0,n.add(h);const d=new ot;d.position.set(-2.4,0,1);const u=new w(new K(.25,.25,.05,6),this.materials.metalGold);u.position.y=.025,u.castShadow=!0,d.add(u);const p=new w(new K(.035,.035,2,4),this.materials.wood);p.position.y=1,p.castShadow=!0,d.add(p);const g=new w(new K(.18,.3,.35,8),this.materials.white);g.position.y=2,g.castShadow=!0,d.add(g);const y=new w(new Rt(.07,6,6),new _t({color:16774557}));y.position.y=1.9,d.add(y);const m=new Ze(16772290,2.2,10,1.2);m.position.set(0,1.9,0),m.castShadow=!1,d.add(m),n.add(d),this.group.add(n),this.interactables.push({id:"house_wardrobe",name:"衣柜换装",x:t-1.4,y:.12,z:e,triggerRadius:2})}createSofaLounge(t,e){const n=new ot;n.position.set(t,.12,e);const i=new U(4.2,.01,2.8),s=new w(i,this.materials.carpet);s.position.y=.005,n.add(s);const a=new w(new U(3,.28,1.2),this.materials.sofaBody);a.position.y=.24,a.castShadow=!0,n.add(a);const r=new w(new U(3,.8,.25),this.materials.sofaBody);r.position.set(0,.72,-.475),r.castShadow=!0,n.add(r);const c=new w(new U(.25,.55,1.2),this.materials.sofaBody);c.position.set(-1.375,.42,0),c.castShadow=!0,n.add(c);const l=new w(new U(.25,.55,1.2),this.materials.sofaBody);l.position.set(1.375,.42,0),l.castShadow=!0,n.add(l);for(let f=0;f<3;f++){const _=new w(new U(.82,.15,.85),this.materials.sofaCushion);_.position.set(-.82+f*.82,.38,.05),_.castShadow=!0,n.add(_)}const h=new ot;h.position.set(0,0,.9);const d=new w(new U(1.6,.06,.8),this.materials.wood);d.position.y=.35,d.castShadow=!0,h.add(d);const u=new K(.04,.04,.35,4),p=new w(u,this.materials.wood);p.position.set(-.7,.175,0),p.castShadow=!0,h.add(p);const g=new w(u,this.materials.wood);g.position.set(.7,.175,0),g.castShadow=!0,h.add(g);const y=new w(new K(.08,.06,.12,5),this.materials.coconut);y.position.set(0,.44,0),y.castShadow=!0,h.add(y);const m=new w(new Rt(.1,5,5),this.materials.leaves);m.position.set(0,.52,0),h.add(m),n.add(h),this.group.add(n)}createDiningTable(t,e){const n=new ot;n.position.set(t,.12,e);const i=new w(new U(.9,.08,2.5),this.materials.wood);i.position.y=1,i.castShadow=!0,n.add(i);const s=new K(.035,.035,1,4);[{x:-.38,z:-1.1},{x:.38,z:-1.1},{x:-.38,z:1.1},{x:.38,z:1.1}].forEach(m=>{const f=new w(s,this.materials.wood);f.position.set(m.x,.5,m.z),f.castShadow=!0,n.add(f)});const r=new U(.42,.06,.42),c=new K(.02,.02,.5,4);for(let m=-1;m<=1;m+=2){const f=new ot;f.position.set(.68*m,0,0);const _=new w(r,this.materials.wood);_.position.y=.53,_.castShadow=!0,f.add(_);for(let M=-1;M<=1;M+=2)for(let R=-1;R<=1;R+=2){const A=new w(c,this.materials.wood);A.position.set(.16*M,.25,.16*R),A.castShadow=!0,f.add(A)}const x=new w(new U(.06,.5,.42),this.materials.wood);x.position.set(.18*m,.78,0),x.castShadow=!0,f.add(x),n.add(f)}const l=[13959168,2001125,16757504];for(let m=0;m<3;m++){const f=new w(new U(.38,.06,.3),new V({color:l[m],flatShading:!0}));f.position.set(-.06,1.07+m*.062,.3),f.rotation.y=.12*m-.08,f.castShadow=!0,n.add(f)}const h=new w(new K(.12,.09,.22,5),this.materials.white);h.position.set(0,1.15,-.5),h.castShadow=!0,n.add(h);const d=new w(new Rt(.16,6,6),this.materials.leaves);d.position.set(0,1.3,-.5),n.add(d);const u=new w(new K(.08,.08,.04,4),this.materials.metalGold);u.position.set(.2,1.06,.8),n.add(u);const p=new w(new K(.015,.015,.35,4),this.materials.metalGold);p.position.set(.2,1.22,.8),p.rotation.z=-.2,n.add(p);const g=new w(new K(.08,.14,.16,6),this.materials.white);g.position.set(.13,1.38,.8),n.add(g);const y=new Ze(16777184,.8,6,1.2);y.position.set(.13,1.34,.8),n.add(y),this.group.add(n)}createMonstera(t,e){const n=new ot;n.position.set(t,.12,e);const i=new w(new K(.35,.28,.6,6),this.materials.carpet);i.position.y=.3,i.castShadow=!0,n.add(i);const s=new K(.03,.03,.9,4);for(let a=0;a<5;a++){const r=new w(s,this.materials.wood),c=a/5*Math.PI*2;r.position.set(Math.cos(c)*.14,.6,Math.sin(c)*.14),r.rotation.z=Math.cos(c)*.45,r.rotation.x=Math.sin(c)*.45,n.add(r);const l=new w(new Rt(.35,5,5),this.materials.leaves);l.scale.set(1.3,.2,1.8),l.position.set(Math.cos(c)*.52,.96,Math.sin(c)*.52),l.rotation.y=c,l.rotation.x=.45,l.castShadow=!0,n.add(l)}this.group.add(n)}createSunsetPainting(t,e){const n=new w(new U(4.2,2,.05),this.materials.wood);n.position.set(t,3,e),n.castShadow=!0,this.group.add(n);const i=new w(new U(3.8,1.6,.02),this.materials.paintingArt);i.position.set(t,3,e+.035),this.group.add(i);const s=new w(new Rt(.24,6,6),this.materials.paintingSun);s.position.set(t+.8,3.2,e+.05),this.group.add(s)}createReservedSpot(t,e){const n=new ot;n.position.set(t,.12,e);const i=new w(new U(3,.02,3),new V({color:9479342,flatShading:!0,transparent:!0,opacity:.5}));i.position.y=.01,n.add(i);const s=new w(new K(.02,.02,.45,4),this.materials.wood);s.position.set(0,.22,0),s.castShadow=!0,n.add(s);const a=new w(new U(.6,.25,.03),this.materials.wood);a.position.set(0,.44,0),a.castShadow=!0,n.add(a),this.group.add(n)}createCeilingLight(){const t=new ot;t.position.set(0,5.4,0);const e=new w(new K(.2,.2,.06,6),this.materials.wood);t.add(e);const n=new w(new K(.015,.015,1.2,4),new V({color:1118481}));n.position.y=-.6,t.add(n);const i=new w(new K(.08,.35,.28,8),this.materials.metalGold);i.position.y=-1.34,i.castShadow=!0,t.add(i);const s=new w(new Rt(.12,6,6),new _t({color:16775620}));s.position.y=-1.48,t.add(s),this.group.add(t);const a=new Ze(16772290,1.7,28,1.2);a.position.set(0,3.82,0),a.castShadow=!1,this.group.add(a)}createWindowScenery(){const t=new ot;t.position.set(-17.5,-1.2,0);const e=new K(3.5,2.5,1.5,8),n=new w(e,this.materials.wood);n.receiveShadow=!0,t.add(n);const i=new w(new K(3.5,3.4,.2,8),this.materials.woodLight);i.position.y=.85,i.receiveShadow=!0,t.add(i);const s=new ot;s.position.set(0,.95,-.6),s.scale.set(.65,.65,.65);const a=new w(new K(.18,.25,2.5,5),this.materials.wood);a.position.y=1.25,a.rotation.z=-.12,s.add(a);const r=new ot;r.position.set(-.15,2.5,0);const c=new U(1.4,.02,.35);c.translate(.7,0,0);for(let m=0;m<6;m++){const f=new w(c,this.materials.leaves);f.rotation.y=m/6*Math.PI*2,f.rotation.z=-.2,r.add(f)}s.add(r),t.add(s);const l=new w(new Rt(1.2,10,10),new _t({color:16769154}));l.position.set(-4.5,7.8,-4.5),t.add(l);const h=new ot;h.position.set(1.5,4,3);const d=new V({color:16448250,flatShading:!0});for(let m=0;m<3;m++){const f=new w(new Rt(.35+m*.1,5,5),d);f.position.set(m*.4-.4,0,m%2*.1),h.add(f)}t.add(h);const u=new Ze(8445674,1.5,12,1.2);u.position.set(-1,3.2,-1),t.add(u);const p=new Rt(.06,4,4),g=new _t({color:16772275});[{x:-3.5,y:5.5,z:-2},{x:-2,y:6.5,z:2},{x:1.5,y:5.2,z:-3},{x:2.5,y:7,z:1},{x:-1.2,y:4.5,z:3.5},{x:-5,y:6,z:0}].forEach(m=>{const f=new w(p,g);f.position.set(m.x,m.y,m.z),t.add(f)}),this.group.add(t)}createFloorLamp(t,e){const n=new ot;n.position.set(t,.12,e);const i=new w(new K(.3,.3,.05,6),this.materials.metalGold);i.castShadow=!0,n.add(i);const s=new w(new K(.04,.04,2.2,4),this.materials.wood);s.position.y=1.1,s.castShadow=!0,n.add(s);const a=new w(new K(.2,.35,.4,8),this.materials.white);a.position.y=2.2,a.castShadow=!0,n.add(a);const r=new w(new Rt(.08,6,6),new _t({color:16771899}));r.position.y=2.1,n.add(r);const c=new Ze(16765312,1.2,12,1.2);c.position.set(0,2,0),c.castShadow=!1,n.add(c),this.group.add(n)}}class ts{constructor(t,e,n,i){this.scene=t,this.camera=e,this.colliders=n,this.themeConfig=i,this.position=new L(0,4,0),this.velocity=new L,this.speed=8,this.jumpForce=7,this.gravity=18,this.isGrounded=!1,this.radius=.6,this.controlsLocked=!1,this.targetRotation=0,this.keys={w:!1,a:!1,s:!1,d:!1,space:!1,shift:!1},this.cameraAngleH=Math.PI/2,this.cameraAngleV=.35,this.cameraDistance=8.5,this.isSitting=!1,this.swingRef=null,this.isLyingDown=!1,this.initMesh(),this.initControls()}initMesh(){this.group=new ot,this.group.position.copy(this.position),this.activeModel="girl";const t=this.themeConfig.player.hairColor||16747136,e=this.themeConfig.player.clothingColor||16777215,n=this.themeConfig.player.hatColor||16765312;this.rebuildMesh(t,e,n)}rebuildMesh(t,e,n){for(;this.group.children.length>0;){const A=this.group.children[0];this.group.remove(A),A.geometry&&A.geometry.dispose(),A.material&&(Array.isArray(A.material)?A.material.forEach(E=>E.dispose()):A.material.dispose())}this.tailL=null,this.tailR=null,this.catTail=null;const i=this.themeConfig.colors.sky===330776,s=new V({color:16769213,flatShading:!0}),a=new V({color:16777215,flatShading:!0}),r=new V({color:t,flatShading:!0});this.hairMat=r;const c=new K(.2,.24,.35,8),l=new V({color:e,flatShading:!0});this.clothingMat=l,this.body=new w(c,l),this.body.position.y=.55,this.body.castShadow=!0,this.group.add(this.body);const h=i?2503224:4149685,d=new K(.24,.3,.3,8),u=new V({color:h,flatShading:!0}),p=new w(d,u);p.position.y=.25,p.castShadow=!0,this.group.add(p);const g=new Rt(.34,8,8);this.head=new w(g,s),this.head.position.y=.94,this.head.castShadow=!0,this.group.add(this.head);const y=new K(.08,.08,.15,6),m=new w(y,s);m.position.y=.75,this.group.add(m);const f=i?6111287:this.activeModel==="boy"?16732754:16777215,_=new V({color:f,flatShading:!0}),x=new Rt(.09,6,6);if(x.scale(1,i?1:.7,1.3),this.footL=new w(x,_),this.footL.position.set(-.16,.04,0),this.footR=new w(x,_),this.footR.position.set(.16,.04,0),!i&&this.activeModel==="girl"){const A=new U(.12,.04,.08),E=new w(A,_);E.position.set(-.16,.06,.08);const I=new w(A,_);I.position.set(.16,.06,.08),this.group.add(E),this.group.add(I)}this.group.add(this.footL),this.group.add(this.footR),this.activeModel==="girl"?this.buildGirlModel(r,a,n,i):this.activeModel==="boy"?this.buildBoyModel(r,a,n,i):this.activeModel==="kitty"&&this.buildKittyModel(r,a,n,i);const M=i?13959168:16777215,R=new V({color:M,transparent:!i,opacity:i?1:.8,side:me,flatShading:!0});if(i){const A=new wn(.55,.7,2,4);this.cape=new w(A,R),this.cape.position.set(.05,.62,-.22),this.cape.rotation.x=.12,this.cape.rotation.y=.05,this.cape.castShadow=!0,this.group.add(this.cape)}else{const A=new wn(.65,.75,3,5);this.cape=new w(A,R),this.cape.position.set(0,.48,-.32),this.cape.rotation.x=.15,this.cape.castShadow=!0,this.group.add(this.cape)}this.scene.add(this.group)}buildGirlModel(t,e,n,i){const s=new Rt(.36,8,8),a=new w(s,t);a.position.set(0,.98,-.04),this.group.add(a);const r=new U(.18,.18,.12),c=new w(r,t);c.position.set(-.12,1.05,.26),c.rotation.z=-.2,c.rotation.y=.1,this.group.add(c);const l=new w(r,t);l.position.set(.12,1.05,.26),l.rotation.z=.2,l.rotation.y=-.1,this.group.add(l);const h=new de(.1,.52,6);if(h.rotateX(Math.PI),this.tailL=new w(h,t),this.tailL.position.set(-.35,.94,-.05),this.tailL.rotation.z=-.25,this.group.add(this.tailL),this.tailR=new w(h,t),this.tailR.position.set(.35,.94,-.05),this.tailR.rotation.z=.25,this.group.add(this.tailR),i){const P=new w(new U(.07,.07,.04),e);P.position.set(.24,1.12,.24),P.rotation.z=Math.PI/4,this.group.add(P)}else{const P=new w(new U(.08,.08,.04),new V({color:5025616}));P.position.set(.24,1.12,.24),P.rotation.z=-.4;const O=new w(new U(.06,.06,.04),new V({color:16732754}));O.position.set(.24,1.14,.26),O.rotation.z=-.4,this.group.add(P),this.group.add(O)}if(i){const P=new ot;P.position.set(0,1.25,-.04);const O=new de(.35,.6,8);O.translate(0,.3,0);const j=new V({color:n,flatShading:!0});this.hatMat=j;const D=new w(O,j);D.rotation.z=-.15,D.rotation.x=-.1,D.castShadow=!0,P.add(D);const F=new K(.36,.36,.12,8),z=new w(F,e);z.position.y=.05,P.add(z);const Z=new Rt(.08,6,6),Y=new w(Z,e);Y.position.set(.08,.62,-.04),P.add(Y),this.group.add(P)}else{const P=new ot;P.position.set(0,1.28,-.04);const O=new K(.72,.72,.04,10),j=new V({color:n,flatShading:!0});this.hatMat=j;const D=new w(O,j);D.castShadow=!0,P.add(D);const F=new K(.32,.38,.25,8),z=new w(F,j);z.position.y=.14,z.castShadow=!0,P.add(z);const Z=new K(.39,.39,.06,8),Y=new w(Z,e);Y.position.y=.05,P.add(Y),this.group.add(P)}const d=new ot;d.position.set(0,1.22,.3),d.rotation.x=-.15;const u=new Rt(.12,6,6);u.scale(1,1,.2);const p=new _t({color:1710618}),g=new w(u,p);g.position.x=-.16;const y=new w(u,p);y.position.x=.16,d.add(g),d.add(y);const m=i?16777215:16744619,f=new V({color:m,flatShading:!0});if(i){const P=new U(.48,.2,.06),O=new w(P,f);O.position.set(0,0,.02),d.add(O)}else{const P=new K(.15,.15,.05,8);P.rotateX(Math.PI/2);const O=new w(P,f);O.position.set(-.16,0,.02);const j=new w(P,f);j.position.set(.16,0,.02),d.add(O),d.add(j)}this.group.add(d);const _=new ot;_.position.set(.1,i?1.55:1.48,-.06);const x=new Rt(.14,6,6);x.scale(1,.9,1.1);const M=i?11583173:16765312,R=new V({color:M,flatShading:!0}),A=new w(x,R);_.add(A);const E=new Rt(.04,4,4),I=new w(E,R);I.position.set(-.06,.09,.05);const v=new w(E,R);v.position.set(.06,.09,.05),_.add(I),_.add(v);const S=new w(new Rt(.02,4,4),new V({color:16747136}));if(S.position.set(.08,0,.11),_.add(S),i){const P=new K(.11,.11,.04,6),O=new w(P,new V({color:12986408}));O.position.y=-.06,_.add(O)}else{const P=new w(new Rt(.02,4,4),e);P.position.set(.06,.12,.08),_.add(P)}if(this.group.add(_),i){const P=new ot;P.position.set(0,.58,.3);const O=new w(new U(.25,.25,.25),new V({color:3046706,flatShading:!0}));O.castShadow=!0,P.add(O);const j=new w(new U(.27,.05,.27),new V({color:13959168,flatShading:!0}));P.add(j),this.group.add(P)}else{const P=new ot;P.position.set(0,.58,.35);const O=new U(.3,.16,.06),j=new w(O,new V({color:16732754}));P.add(j);const D=new U(.32,.04,.08),F=new w(D,new V({color:5025616}));F.position.y=-.09,P.add(F),this.group.add(P)}this.buildFaceDetails()}buildBoyModel(t,e,n,i){const s=new Rt(.35,8,8),a=new w(s,t);a.position.set(0,.98,-.04),this.group.add(a);const r=new de(.08,.22,4);r.rotateX(Math.PI/1.8);for(let et=0;et<4;et++){const pt=new w(r,t),bt=-.15+et*.1;pt.position.set(bt,1.08,.26),pt.rotation.y=bt*.5,pt.castShadow=!0,this.group.add(pt)}const c=new de(.07,.22,4);c.rotateX(-.3),[{x:-.14,y:1.25,z:-.08},{x:.14,y:1.25,z:-.08},{x:0,y:1.28,z:-.04},{x:-.08,y:1.24,z:-.2},{x:.08,y:1.24,z:-.2}].forEach(et=>{const pt=new w(c,t);pt.position.set(et.x,et.y,et.z),pt.castShadow=!0,this.group.add(pt)});const h=new ot;h.position.set(0,1.24,-.04);const d=new V({color:n,flatShading:!0});this.hatMat=d;const u=new K(.35,.36,.22,8),p=new w(u,d);p.castShadow=!0,h.add(p);const g=new U(.46,.02,.35),y=new w(g,d);y.position.set(0,-.06,.28),y.rotation.x=.14,y.castShadow=!0,h.add(y);const m=new Rt(.04,4,4),f=new w(m,e);f.position.y=.12,h.add(f),this.group.add(h);const _=new ot;_.position.set(0,1.22,.3);const x=new U(.14,.09,.02),M=new _t({color:1118481}),R=new w(x,M);R.position.x=-.16;const A=new w(x,M);A.position.x=.16,_.add(R),_.add(A);const E=new V({color:i?16777215:2201331,flatShading:!0}),I=new w(new U(.18,.02,.03),E);I.position.set(0,0,.01),_.add(I);const v=new w(new U(.02,.11,.04),E);v.position.set(-.24,0,.01);const S=new w(new U(.02,.11,.04),E);S.position.set(.24,0,.01),_.add(v),_.add(S),this.group.add(_);const P=new ot;P.position.set(-.35,.65,.05),P.scale.set(.8,.8,.8);const O=new V({color:16732754,flatShading:!0}),j=new w(new U(.22,.12,.15),O);j.castShadow=!0,P.add(j);const D=new Rt(.03,4,4),F=new w(D,new _t({color:16777215}));F.position.set(-.05,.08,.08);const z=new w(D,new _t({color:16777215}));z.position.set(.05,.08,.08),P.add(F),P.add(z);const Z=new Rt(.06,5,5);Z.scale(1.2,.8,1);const Y=new w(Z,O);Y.position.set(-.14,.04,.08);const q=new w(Z,O);q.position.set(.14,.04,.08),P.add(Y),P.add(q),this.group.add(P);const J=new ot;J.position.set(.25,.52,.28),J.rotation.set(-.15,-.4,.35);const nt=new V({color:58998,flatShading:!0}),ct=new w(new U(.15,.9,.04),nt);ct.castShadow=!0,J.add(ct);const X=new w(new U(.16,.2,.05),new V({color:16771899,flatShading:!0}));X.position.y=.05,J.add(X),this.group.add(J),this.buildFaceDetails()}buildKittyModel(t,e,n,i){const s=t,a=new Rt(.07,6,6);a.scale(1.3,.8,1);const r=new w(a,e);r.position.set(0,.86,.29),this.group.add(r);const c=new Rt(.035,4,4),l=new V({color:16747136}),h=new w(c,l);h.position.set(0,.89,.35),this.group.add(h);const d=new U(.26,.015,.015),u=new _t({color:1118481});for(let ct=0;ct<3;ct++){const X=new w(d,u);X.position.set(-.26,.86+(ct-1)*.04,.25),X.rotation.z=-(ct-1)*.12-.05,X.rotation.y=.2,this.group.add(X);const et=new w(d,u);et.position.set(.26,.86+(ct-1)*.04,.25),et.rotation.z=(ct-1)*.12+.05,et.rotation.y=-.2,this.group.add(et)}const p=new de(.12,.28,4);p.rotateX(.1);const g=new w(p,s);g.position.set(-.22,1.2,.06),g.rotation.z=.25,g.castShadow=!0,this.group.add(g);const y=new w(p,s);y.position.set(.22,1.2,.06),y.rotation.z=-.25,y.castShadow=!0,this.group.add(y);const m=new V({color:16747136,flatShading:!0}),f=new de(.08,.2,4);f.rotateX(.1);const _=new w(f,m);_.position.set(-.21,1.21,.09),_.rotation.z=.25,this.group.add(_);const x=new w(f,m);x.position.set(.21,1.21,.09),x.rotation.z=-.25,this.group.add(x);const M=i?3046706:13959168,R=new V({color:M,flatShading:!0}),A=new K(.21,.21,.06,8),E=new w(A,R);E.position.y=.73,this.group.add(E);const I=new V({color:n,flatShading:!0});this.hatMat=I;const v=new Rt(.07,6,6),S=new w(v,I);S.position.set(0,.69,.28),this.group.add(S);const P=new Vn(.03,.01,4,8),O=new w(P,I);O.position.set(0,.74,.25),this.group.add(O),this.catTail=new ot,this.catTail.position.set(0,.22,-.28);let j=this.catTail;const D=4,F=new K(.04,.04,.18,5);F.translate(0,.09,0);for(let ct=0;ct<D;ct++){const X=new w(F,s);X.position.set(0,ct===0?0:.15,ct===0?0:-.05),X.rotation.x=-.3,X.castShadow=!0,j.add(X),j=X}this.group.add(this.catTail);const z=new ot;z.position.set(0,.56,.32),z.rotation.set(.1,-.4,.2);const Z=new V({color:48340,flatShading:!0}),Y=new w(new U(.18,.09,.05),Z);Y.castShadow=!0,z.add(Y);const q=new de(.05,.08,3);q.rotateX(Math.PI/2);const J=new w(q,Z);J.position.set(-.11,0,0),z.add(J);const nt=new w(new Rt(.012,4,4),new _t({color:16777215}));nt.position.set(.06,.02,.03),z.add(nt),this.group.add(z),this.buildFaceDetails()}buildFaceDetails(){const t=new Rt(.06,5,5),e=new _t({color:5125166}),n=new w(t,e);n.position.set(-.11,.94,.27);const i=new w(t,e);i.position.set(.11,.94,.27),this.group.add(n),this.group.add(i);const s=new Rt(.05,4,4),a=new V({color:16747136,flatShading:!0}),r=new w(s,a);r.position.set(-.19,.87,.25);const c=new w(s,a);c.position.set(.19,.87,.25),this.group.add(r),this.group.add(c)}updateModel(t){if(this.activeModel===t)return;this.activeModel=t;const e=this.hairMat?this.hairMat.color.getHex():this.themeConfig.player.hairColor||16747136,n=this.clothingMat?this.clothingMat.color.getHex():this.themeConfig.player.clothingColor||16777215,i=this.hatMat?this.hatMat.color.getHex():this.themeConfig.player.hatColor||16765312;this.rebuildMesh(e,n,i)}initControls(){const t=(c,l)=>{if(this.isSitting||this.isLyingDown){l&&(c.key===" "||c.key==="Spacebar")&&this.standUp();return}if(this.controlsLocked)return;const h=c.key.toLowerCase();if((h==="w"||c.key==="ArrowUp")&&(this.keys.w=l),(h==="s"||c.key==="ArrowDown")&&(this.keys.s=l),(h==="a"||c.key==="ArrowLeft")&&(this.keys.a=l),(h==="d"||c.key==="ArrowRight")&&(this.keys.d=l),c.key===" "||c.key==="Spacebar"){const d=window.parent&&window.parent.isRadialMenuOpen;this.keys.space=d?!1:l}c.key==="Shift"&&(this.keys.shift=l)};window.addEventListener("keydown",c=>t(c,!0)),window.addEventListener("keyup",c=>t(c,!1));let e=!1,n={x:0,y:0};window.addEventListener("mousedown",c=>{e=!0,n={x:c.clientX,y:c.clientY}}),window.addEventListener("mousemove",c=>{if(!e)return;const l=c.clientX-n.x,h=c.clientY-n.y;this.cameraAngleH-=l*.005,this.cameraAngleV=Math.max(.1,Math.min(1.2,this.cameraAngleV+h*.005)),n={x:c.clientX,y:c.clientY}}),window.addEventListener("mouseup",()=>{e=!1});let i=null;document.addEventListener("touchstart",c=>{for(let l=0;l<c.changedTouches.length;l++){const h=c.changedTouches[l],d=h.target&&h.target.closest?h.target:null,u=d?d.closest("#mobile-controls")||d.closest(".hud-header")||d.closest(".modal-overlay")||d.closest(".modal-card")||d.closest(".sso-sidebar")||d.closest(".sidebar-overlay")||d.id==="audio-btn":!1,p=h.clientX<window.innerWidth*.45;if(!u&&!p&&i===null){e=!0,i=h.identifier,n={x:h.clientX,y:h.clientY};break}}}),document.addEventListener("touchmove",c=>{if(!e||i===null)return;let l=null;for(let u=0;u<c.touches.length;u++)if(c.touches[u].identifier===i){l=c.touches[u];break}if(!l)return;c.preventDefault();const h=l.clientX-n.x,d=l.clientY-n.y;this.cameraAngleH-=h*.005,this.cameraAngleV=Math.max(.1,Math.min(1.2,this.cameraAngleV+d*.005)),n={x:l.clientX,y:l.clientY}},{passive:!1});const s=c=>{if(i===null)return;let l=!1;for(let h=0;h<c.changedTouches.length;h++)if(c.changedTouches[h].identifier===i){l=!0;break}l&&(e=!1,i=null)};document.addEventListener("touchend",s),document.addEventListener("touchcancel",s),window.addEventListener("modal-opened",()=>{this.controlsLocked=!0,this.resetInputs()}),window.addEventListener("modal-closed",()=>{this.controlsLocked=!1});const a=document.getElementById("btn-jump");a&&(a.addEventListener("touchstart",c=>{if(c.preventDefault(),this.isSitting||this.isLyingDown){this.standUp();return}this.controlsLocked||(this.keys.space=!0)}),a.addEventListener("touchend",c=>{c.preventDefault(),this.keys.space=!1}));const r=document.getElementById("btn-run");r&&(r.addEventListener("touchstart",c=>{c.preventDefault(),this.controlsLocked||(this.keys.shift=!0)}),r.addEventListener("touchend",c=>{c.preventDefault(),this.keys.shift=!1}))}resetInputs(){this.keys={w:!1,a:!1,s:!1,d:!1,space:!1,shift:!1},this.velocity.set(0,this.velocity.y,0)}update(t,e){if(window.self!==window.top&&window.parent&&(window.parent.isRadialMenuOpen?(this.keys.space=!1,window.parent.keys&&(window.parent.keys.space=!1)):window.parent.keys&&(this.keys.space=this.keys.space||window.parent.keys.space),window.parent.keys&&(this.keys.shift=this.keys.shift||window.parent.keys.shift,this.keys.j=this.keys.j||window.parent.keys.j)),(this.isSitting||this.isLyingDown)&&this.keys.space&&(this.standUp(),window.parent&&window.parent.keys&&(window.parent.keys.space=!1),this.keys.space=!1),this.isLyingDown){this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.lyingRotation?(this.group.rotation.x=this.lyingRotation.x,this.group.rotation.y=this.lyingRotation.y,this.group.rotation.z=this.lyingRotation.z):(this.group.rotation.x=-Math.PI/2,this.group.rotation.y=0,this.group.rotation.z=0),this.body.rotation.x=0,this.footL.position.set(-.16,.05,0),this.footR.position.set(.16,.05,0),this.body.position.y=.38,this.head.position.y=.88,this.cape.rotation.x=.15;const M=this.cape.geometry.attributes.position;for(let v=0;v<M.count;v++)M.setZ(v,0);M.needsUpdate=!0;const R=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,A=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,E=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(R-this.camera.position.x)*.08,this.camera.position.y+=(A-this.camera.position.y)*.08,this.camera.position.z+=(E-this.camera.position.z)*.08;const I=this.position.clone().add(new L(0,.4,0));this.camera.lookAt(I);return}if(this.isSitting&&this.swingRef){if(this.swingRef.isStatic)this.position.copy(this.swingRef.position),this.position.y+=.22,this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.group.rotation.y=this.swingRef.rotationY;else{const v=this.swingRef.rotation.x,S=1.1;this.position.x=this.swingRef.parent.position.x+this.swingRef.position.x,this.position.y=this.swingRef.parent.position.y+this.swingRef.position.y-S*Math.cos(v)-.28,this.position.z=this.swingRef.parent.position.z+this.swingRef.position.z-S*Math.sin(v),this.velocity.set(0,0,0),this.isGrounded=!0,this.group.position.copy(this.position),this.group.rotation.y=0}this.footL.position.set(-.16,.15,.18),this.footR.position.set(.16,.15,.18),this.body.position.y=.3,this.head.position.y=.8,this.cape.rotation.x=-.1+Math.sin(e*.002)*.05;const M=this.cape.geometry.attributes.position;for(let v=0;v<M.count;v++)M.setZ(v,0);M.needsUpdate=!0,this.tailL&&(this.tailL.rotation.z=-.2-Math.sin(e*.002)*.1),this.tailR&&(this.tailR.rotation.z=.2+Math.sin(e*.002)*.1),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.003)*.15);const R=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,A=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,E=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(R-this.camera.position.x)*.08,this.camera.position.y+=(A-this.camera.position.y)*.08,this.camera.position.z+=(E-this.camera.position.z)*.08;const I=this.position.clone().add(new L(0,.8,0));this.camera.lookAt(I);return}let n=0,i=0;if(!this.controlsLocked&&(this.keys.w&&(i-=1),this.keys.s&&(i+=1),this.keys.a&&(n-=1),this.keys.d&&(n+=1),window.self!==window.top&&window.parent&&window.parent.joystickDir)){const M=window.parent.joystickDir;(M.x!==0||M.y!==0)&&(n+=M.x,i+=M.y)}const a=new L(n,0,i).normalize().clone().applyAxisAngle(new L(0,1,0),this.cameraAngleH),r=this.keys.shift?this.speed*1.6:this.speed;if(this.velocity.x=a.x*r,this.velocity.z=a.z*r,this.isGrounded||(this.velocity.y-=this.gravity*t),this.position.addScaledVector(this.velocity,t),this.app&&this.app.currentMap==="house")this.position.x<-11.5&&(this.position.x=-11.5),this.position.x>11.5&&(this.position.x=11.5),this.position.z<-11.5&&(this.position.z=-11.5),this.position.z>11.5&&(this.position.z=11.5);else{const R=Math.sqrt(this.position.x*this.position.x+this.position.z*this.position.z);R>21.2&&(this.position.x=this.position.x/R*21.2,this.position.z=this.position.z/R*21.2)}let c=!1,l=-999;for(const M of this.colliders)if(M.type==="floor"){const R=this.position.x-M.worldX,A=this.position.z-M.worldZ;Math.sqrt(R*R+A*A)<M.radius+.1&&this.position.y>=M.worldY-.8&&this.position.y<=M.worldY+.1&&(l=Math.max(l,M.worldY),c=!0)}c?this.velocity.y<=0&&(this.position.y=l,this.velocity.y=0,this.isGrounded=!0):this.isGrounded=!1,this.position.y<-10&&(this.position.set(0,4,0),this.velocity.set(0,0,0),this.isGrounded=!1);const h=window.parent&&window.parent.isRadialMenuOpen;this.keys.space&&this.isGrounded&&!this.controlsLocked&&!h&&(this.velocity.y=this.jumpForce,this.isGrounded=!1,this.keys.space=!1,window.parent&&window.parent.keys&&(window.parent.keys.space=!1)),this.group.position.copy(this.position);const d=Math.sqrt(this.velocity.x*this.velocity.x+this.velocity.z*this.velocity.z);if(d>.1){this.targetRotation=Math.atan2(this.velocity.x,this.velocity.z);let M=this.targetRotation-this.group.rotation.y;M=Math.atan2(Math.sin(M),Math.cos(M)),this.group.rotation.y+=M*.15;const R=this.keys.shift?24:16;this.footL.position.z=Math.sin(e*.001*R)*.25,this.footL.position.y=.05+Math.max(0,Math.cos(e*.001*R))*.12,this.footR.position.z=-Math.sin(e*.001*R)*.25,this.footR.position.y=.05+Math.max(0,-Math.cos(e*.001*R))*.12,this.tailL&&(this.tailL.rotation.z=-.2-Math.abs(Math.sin(e*.001*R))*.18),this.tailR&&(this.tailR.rotation.z=.2+Math.abs(Math.sin(e*.001*R))*.18),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.001*R*1.5)*.35,this.catTail.rotation.z=Math.cos(e*.001*R*1.5)*.06),this.body.rotation.x=this.keys.shift?.22:.1,this.body.position.y=.38+Math.abs(Math.sin(e*.001*R))*.06,this.head.position.y=.88+Math.abs(Math.sin(e*.001*R))*.04}else this.body.rotation.x=0,this.footL.position.set(-.16,.05,0),this.footR.position.set(.16,.05,0),this.body.position.y=.38+Math.sin(e*.003)*.02,this.head.position.y=.88+Math.sin(e*.003)*.02,this.tailL&&(this.tailL.rotation.z=-.2+Math.sin(e*.003)*.04),this.tailR&&(this.tailR.rotation.z=.2-Math.sin(e*.003)*.04),this.catTail&&(this.catTail.rotation.y=Math.sin(e*.003)*.15,this.catTail.rotation.z=Math.cos(e*.003)*.03);const u=this.cape.geometry.attributes.position,p=18,g=2.2,y=.08+d*.03;for(let M=0;M<u.count;M++){u.getX(M);const A=.4-u.getY(M),E=Math.sin(e*.001*p-A*g)*y*(A/.8);u.setZ(M,E)}u.needsUpdate=!0;const m=this.position.x+Math.sin(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance,f=this.position.y+Math.sin(this.cameraAngleV)*this.cameraDistance+.8,_=this.position.z+Math.cos(this.cameraAngleH)*Math.cos(this.cameraAngleV)*this.cameraDistance;this.camera.position.x+=(m-this.camera.position.x)*.08,this.camera.position.y+=(f-this.camera.position.y)*.08,this.camera.position.z+=(_-this.camera.position.z)*.08;const x=this.position.clone().add(new L(0,.8,0));this.camera.lookAt(x)}sit(t){this.isSitting=!0,this.swingRef=t,this.controlsLocked=!0}lieDown(t,e){this.isLyingDown=!0,this.controlsLocked=!0,this.position.copy(t),this.position.y=t.y+.58,e?this.lyingRotation=e:this.lyingRotation=null,window.parent&&window.parent.appShell&&typeof window.parent.appShell.hideMobileControls=="function"&&window.parent.appShell.hideMobileControls(),window.gameApp&&typeof window.gameApp.updateTaskProgress=="function"&&window.gameApp.updateTaskProgress("rest",1)}updateOutfit(t,e){const n=parseInt(e);t==="hair"&&this.hairMat?this.hairMat.color.setHex(n):t==="clothing"&&this.clothingMat?this.clothingMat.color.setHex(n):t==="hat"&&this.hatMat&&this.hatMat.color.setHex(n)}standUp(){if(this.isLyingDown){this.isLyingDown=!1,this.controlsLocked=!1,this.group.rotation.x=0,this.group.rotation.y=0,this.group.rotation.z=0,this.lyingRotation?(this.lyingRotation=null,this.position.x+=1):this.position.z+=1.4,this.position.y=.8;const n=document.getElementById("bed-hud");n&&(n.style.display="none"),window.parent&&window.parent.appShell&&typeof window.parent.appShell.showMobileControls=="function"&&window.parent.appShell.showMobileControls();return}const t=this.swingRef&&this.swingRef.isStatic;this.isSitting=!1,this.swingRef=null,this.controlsLocked=!1,t?(this.position.x>0?this.position.x+=.9:this.position.x-=.9,this.position.y=.6):(this.position.z+=1.2,this.position.y=.8);const e=document.getElementById("exit-sitting-hud");e&&(e.style.display="none")}}class es{constructor(t,e,n,i){this.player=t,this.generator=e,this.modalManager=n,this.app=i,this.promptEl=document.getElementById("interact-prompt"),this.promptTextEl=this.promptEl?this.promptEl.querySelector(".prompt-text"):null,this.mobileInteractBtn=document.getElementById("btn-interact")||window.parent&&window.parent.document.getElementById("btn-interact"),this.activeInteractZone=null,this.isTransitioningCamera=!1,this.cameraSavedState=null,this.init()}init(){window.addEventListener("keydown",t=>{t.key.toLowerCase()==="e"&&this.triggerActiveInteraction()}),this.mobileInteractBtn&&(this.mobileInteractBtn.addEventListener("touchstart",t=>{t.preventDefault(),this.triggerActiveInteraction()},{passive:!1}),this.mobileInteractBtn.addEventListener("click",t=>{t.preventDefault(),this.triggerActiveInteraction()})),window.addEventListener("modal-closed",()=>{this.isTransitioningCamera&&this.cameraSavedState&&(this.isTransitioningCamera=!1,this.player.cameraDistance=this.cameraSavedState.distance,this.player.cameraAngleH=this.cameraSavedState.angleH,this.player.cameraAngleV=this.cameraSavedState.angleV,this.cameraSavedState.rotationY!==void 0&&(this.player.group.rotation.y=this.cameraSavedState.rotationY),this.cameraSavedState.controlsLocked!==void 0&&(this.player.controlsLocked=this.cameraSavedState.controlsLocked),this.activeInteractZone=null)})}update(){if(this.player.carriedBall){this.activeInteractZone={id:"drop_ball",name:"放下"},this.showPrompt("放下");return}if(this.player.controlsLocked)return;let t=null,e=999;const n=this.player.position;for(const i of this.generator.interactables){if(i.id.startsWith("farm_plot_")&&this.app&&this.app.gameData){const l=parseInt(i.id.replace("farm_plot_","")),h=this.app.gameData.farmPlots[l];if(h&&h.status!=="ready")continue}const s=n.x-i.x,a=n.y-i.y,r=n.z-i.z,c=Math.sqrt(s*s+a*a+r*r);if(c<i.triggerRadius&&c<e&&(e=c,t=i,i.id.startsWith("farm_plot_")&&this.app&&this.app.gameData)){const l=parseInt(i.id.replace("farm_plot_","")),h=this.app.gameData.farmPlots[l];if(h)if(h.status==="empty")i.name="种植农作物";else if(h.status==="ready")i.name="收割作物";else{const d=h.seedId==="sunflower_seed"?30:60,u=Math.floor((Date.now()-h.plantTime)/1e3),p=Math.max(0,d-u);i.name=`作物生长中 (${p}s)`}}}if(this.app&&this.app.beachBallsList)for(const i of this.app.beachBallsList){if(i.isCarried)continue;const s=n.x-i.position.x,a=n.y-i.position.y,r=n.z-i.position.z,c=Math.sqrt(s*s+a*a+r*r);c<1.6&&c<e&&(e=c,t={id:"pick_ball",name:"抱起",ball:i})}t?(this.activeInteractZone=t,this.showPrompt(t.name)):(this.activeInteractZone=null,this.hidePrompt())}showPrompt(t){if(this.promptEl&&this.promptEl.classList.add("visible"),this.mobileInteractBtn){this.mobileInteractBtn.style.display="flex";let e=!1;if(this.activeInteractZone&&this.activeInteractZone.id.startsWith("farm_plot_")&&this.app&&this.app.gameData){const s=parseInt(this.activeInteractZone.id.replace("farm_plot_","")),a=this.app.gameData.farmPlots[s];a&&a.status==="empty"&&(e=!0)}const n=`
<svg style="display: flex;" class="lucide lucide-sparkles" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275z"/>
  <path d="m5 3 1 2.5L8.5 6 6 7 5 9.5 4 7 1.5 6 4 5.5z"/>
  <path d="m19 17 1 2.5 2.5.5-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1z"/>
</svg>`,i=`
<svg style="display: flex;" class="lucide lucide-sprout" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M7 20h10" />
  <path d="M10 20V12h4v8" />
  <path d="M12 12a5 5 0 0 0-5-5H4v2h3a3 3 0 0 1 3 3v0" />
  <path d="M12 8a5 5 0 0 1 5-5h3v2h-3a3 3 0 0 0-3 3v0" />
</svg>`;this.mobileInteractBtn.innerHTML=e?i:n}}hidePrompt(){this.promptEl&&this.promptEl.classList.remove("visible"),this.mobileInteractBtn&&(this.mobileInteractBtn.style.display="none")}pickUpBall(t){t.isCarried=!0,this.player.carriedBall=t,this.hidePrompt(),this.mobileInteractBtn&&(this.mobileInteractBtn.textContent="👐")}dropCarriedBall(){const t=this.player.carriedBall;if(!t)return;t.isCarried=!1,this.player.carriedBall=null,t.throwNoCollideTimer=.4;const e=new L(0,0,1).applyQuaternion(this.player.group.quaternion);t.velocity.copy(this.player.velocity),t.velocity.addScaledVector(e,5.5),t.velocity.y=2.8,t.isGrounded=!1,this.hidePrompt(),this.mobileInteractBtn&&(this.mobileInteractBtn.textContent="✨")}triggerActiveInteraction(){if(!this.activeInteractZone)return;const t=this.activeInteractZone;if(t.id==="drop_ball"){this.dropCarriedBall();return}if(t.id==="pick_ball"){this.pickUpBall(t.ball);return}if(t.id==="paimon"){try{window.parent&&window.parent.appShell&&typeof window.parent.appShell.toggleSidebar=="function"?window.parent.appShell.toggleSidebar():typeof window.openSSOSidebar=="function"&&window.openSSOSidebar()}catch(e){console.warn("[交互] 打开侧边栏失败:",e)}this.hidePrompt();return}if(t.id==="enter_house"){this.player.carriedBall&&this.dropCarriedBall(),this.app.switchMap("house");return}if(t.id==="enter_castle"){this.player.carriedBall&&this.dropCarriedBall(),this.app.switchMap("castle");return}if(t.id==="exit_house"){this.player.carriedBall&&this.dropCarriedBall(),this.app.modalMgr?this.app.modalMgr.openModal("exit"):this.app.switchMap("island");return}if(t.id==="swing"){this.player.isSitting?this.player.standUp():(this.player.carriedBall&&this.dropCarriedBall(),this.player.sit(this.generator.swingSeat),this.hidePrompt());return}if(t.id==="ball_vendor"){window.dispatchEvent(new CustomEvent("spawn-ball",{detail:{x:t.x,z:t.z}}));return}if(t.id==="house_bed"||t.id==="lie_bed"){if(this.player.isLyingDown)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e=new L(t.x,t.y,t.z);this.player.lieDown(e),this.hidePrompt();const n=document.getElementById("bed-hud")||document.getElementById("exit-sitting-hud");n&&(n.style.display="flex")}return}if(t.id==="lake_seat_1"||t.id==="lake_seat_2"){if(this.player.isSitting)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e=t.id==="lake_seat_1",n={isStatic:!0,position:new L(e?7.5:-7.5,.78,0),rotationY:e?-Math.PI/2:Math.PI/2};this.player.sit(n);const i=document.getElementById("exit-sitting-hud");if(i){const s=document.getElementById("exit-sitting-hud-text");s&&(s.textContent="🧘 您正在静坐观赏中"),i.style.display="flex"}this.hidePrompt()}return}if(t.id==="sit_sofa"){if(this.player.isSitting)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e={isStatic:!0,position:new L(0,.72+.1,-8.7),rotationY:Math.PI};this.player.sit(e);const n=document.getElementById("exit-sitting-hud");if(n){const i=document.getElementById("exit-sitting-hud-text");i&&(i.textContent="🧘 您正在沙发小憩中"),n.style.display="flex"}this.hidePrompt()}return}if(t.id==="lie_lounger_1"||t.id==="lie_lounger_2"){if(this.player.isLyingDown)this.player.standUp();else{this.player.carriedBall&&this.dropCarriedBall();const e=new L(t.x,t.y,t.z),n={x:-Math.PI/6,y:-Math.PI/2,z:0};this.player.lieDown(e,n);const i=document.getElementById("exit-sitting-hud");if(i){const s=document.getElementById("exit-sitting-hud-text");s&&(s.textContent="☀️ 您正在享受日光浴中"),i.style.display="flex"}this.hidePrompt()}return}if(t.id.startsWith("farm_plot_")){const e=parseInt(t.id.replace("farm_plot_",""));this.app&&typeof this.app.triggerPlotInteraction=="function"&&this.app.triggerPlotInteraction(e),this.hidePrompt();return}if(t.id==="pk_crystal"){this.modalManager.openModal("pk"),this.hidePrompt();return}if(t.id==="house_easel"){this.modalManager.openModal("easel"),this.hidePrompt();return}if(t.id==="house_wardrobe"||t.id==="wardrobe"){this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV,rotationY:this.player.group.rotation.y,controlsLocked:this.player.controlsLocked},this.isTransitioningCamera=!0,this.player.controlsLocked=!0,this.player.cameraDistance=2.4,this.player.cameraAngleH=0,this.player.cameraAngleV=.08,this.player.group.rotation.y=0,setTimeout(()=>{this.modalManager.openModal("wardrobe"),this.hidePrompt()},450);return}this.player.controlsLocked||(this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV},this.isTransitioningCamera=!0,t.id==="arcade"?(this.player.cameraDistance=2.4,this.player.cameraAngleH=0,this.player.cameraAngleV=.15):t.id==="skills"?(this.player.cameraDistance=9.5,this.player.cameraAngleV=.5):t.id==="projects"&&(this.player.cameraDistance=7,this.player.cameraAngleH=-Math.PI/2,this.player.cameraAngleV=.25),setTimeout(()=>{this.modalManager.openModal(t.id),this.hidePrompt()},450))}}class cw{constructor(t,e,n,i,s){this.scene=t,this.radius=.36,this.position=new L(e,n,i),this.velocity=new L((Math.random()-.5)*1.5,3.2,(Math.random()-.5)*1.5),this.gravity=15,this.friction=.985,this.bounceElasticity=.65,this.isGrounded=!1,this.throwNoCollideTimer=0,this.initMesh(s)}initMesh(t){this.group=new ot,this.group.position.copy(this.position);const e=new Rt(this.radius,12,12),n=new V({color:t,flatShading:!0});this.ballMesh=new w(e,n),this.ballMesh.castShadow=!0,this.ballMesh.receiveShadow=!0,this.group.add(this.ballMesh);const i=new V({color:16777215,flatShading:!0}),s=new K(this.radius+.005,this.radius+.005,this.radius*.25,12,1,!0),a=new w(s,i);a.rotation.x=Math.PI/2,this.group.add(a);const r=new K(this.radius+.004,this.radius+.004,this.radius*.25,12,1,!0),c=new w(r,i);c.rotation.z=Math.PI/2,this.group.add(c),this.scene.add(this.group)}update(t,e){if(this.throwNoCollideTimer>0&&(this.throwNoCollideTimer-=t),this.isCarried){const s=new L(0,0,1).applyQuaternion(e.group.quaternion);this.position.copy(e.position).addScaledVector(s,.65),this.position.y+=.65,this.velocity.set(0,0,0),this.isGrounded=!1,this.group.position.copy(this.position);return}this.isGrounded||(this.velocity.y-=this.gravity*t),this.velocity.x*=Math.pow(this.friction,t*60),this.velocity.z*=Math.pow(this.friction,t*60),this.position.addScaledVector(this.velocity,t);const n=this.app&&this.app.currentMap==="house"?.12:.6;if(this.position.y-this.radius<=n?(this.position.y=n+this.radius,this.velocity.y<-1.5?this.velocity.y=-this.velocity.y*this.bounceElasticity:(this.velocity.y=0,this.isGrounded=!0)):this.isGrounded=!1,this.app&&this.app.currentMap==="house"){const s=11.8-this.radius;this.position.x<-s?(this.position.x=-s,this.velocity.x=-this.velocity.x*this.bounceElasticity,this.playKickSound()):this.position.x>s&&(this.position.x=s,this.velocity.x=-this.velocity.x*this.bounceElasticity,this.playKickSound()),this.position.z<-s?(this.position.z=-s,this.velocity.z=-this.velocity.z*this.bounceElasticity,this.playKickSound()):this.position.z>s&&(this.position.z=s,this.velocity.z=-this.velocity.z*this.bounceElasticity,this.playKickSound())}else{const a=Math.sqrt(this.position.x*this.position.x+this.position.z*this.position.z);if(a+this.radius>21.5){const r=this.position.x/a,c=this.position.z/a,l=this.velocity.x*r+this.velocity.z*c;l>0&&(this.velocity.x-=2*l*r,this.velocity.z-=2*l*c,this.velocity.x*=.68,this.velocity.z*=.68),this.position.x=r*(21.5-this.radius),this.position.z=c*(21.5-this.radius)}}if(this.throwNoCollideTimer<=0){const s=this.position.x-e.position.x,a=this.position.z-e.position.z,r=Math.sqrt(s*s+a*a),c=(e.radius||.6)+this.radius-.05;if(r<c&&Math.abs(this.position.y-e.position.y)<1.3){const l=Math.atan2(s,a),h=new L(Math.sin(l),0,Math.cos(l)),d=c-r;this.position.x+=h.x*d,this.position.z+=h.z*d;const u=Math.sqrt(e.velocity.x*e.velocity.x+e.velocity.z*e.velocity.z),p=4.8,g=u*1.3,y=p+g;this.velocity.x=h.x*y,this.velocity.z=h.z*y,this.velocity.y=2.4+g*.45,this.isGrounded=!1,this.playKickSound()}}const i=Math.sqrt(this.velocity.x*this.velocity.x+this.velocity.z*this.velocity.z);if(i>.08){const s=-this.velocity.z/i,a=this.velocity.x/i,r=i/this.radius*t;this.ballMesh.rotateOnWorldAxis(new L(s,0,a),r)}this.group.position.copy(this.position)}playKickSound(){window.dispatchEvent(new CustomEvent("kick-sound",{detail:{freq:140+Math.random()*60}}))}destroy(){this.scene.remove(this.group),this.group.traverse(t=>{t.isMesh&&(t.geometry.dispose(),t.material&&t.material.dispose&&t.material.dispose())})}}class lw{constructor(){if(document.addEventListener("dblclick",n=>{n.preventDefault()},{passive:!1}),document.addEventListener("selectstart",n=>{n.target.tagName!=="INPUT"&&n.target.tagName!=="TEXTAREA"&&n.preventDefault()}),"ontouchstart"in window||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0)document.body.classList.add("is-mobile");else{const n=()=>{document.body.classList.add("is-mobile"),window.removeEventListener("touchstart",n)};window.addEventListener("touchstart",n)}this.container=document.getElementById("canvas-container"),this.clock=new ew,this.renderer=null,this.scene=null,this.camera=null,this.player=null,this.environment=null,this.islandGen=null,this.modalMgr=null,this.interactMgr=null,this.beachBallsList=[],this.activeBombs=[],this.activeExplosions=[],this.bombCooldownActive=!1;const e=Di.activeTheme||"beach";this.themeConfig=Di.themes[e],this.audioCtx=null,this.isPlayingMusic=!1,this.synthInterval=null,this.initEngine(),this.initWorld(),this.initSSO(),this.initGameSystems(),this.animate()}initSSO(){const t=new URLSearchParams(window.location.search),e=t.get("sso_access_token"),n=t.get("sso_user");if(e&&n){localStorage.setItem("sso_access_token",e),localStorage.setItem("sso_user",n),t.delete("sso_access_token"),t.delete("sso_user");const E=t.toString(),I=window.location.pathname+(E?"?"+E:"")+window.location.hash;window.history.replaceState({},document.title,I)}const i=document.getElementById("sso-login-btn"),s=document.getElementById("sso-user-info"),a=document.getElementById("sso-avatar");document.getElementById("sso-sidebar");const r=document.getElementById("sidebar-overlay"),c=document.getElementById("sidebar-close-btn"),l=document.getElementById("sidebar-avatar"),h=document.getElementById("sidebar-username"),d=document.getElementById("sidebar-user-status"),u=document.getElementById("sidebar-login-btn"),p=document.getElementById("sidebar-logout-btn");window.showMockToast=function(E){let I=document.querySelector(".mock-toast");I&&I.remove();const v=document.createElement("div");v.className="mock-toast",v.textContent=`${E} 功能正在开发中，敬请期待！😊`,document.body.appendChild(v),setTimeout(()=>{v.classList.add("show")},50),setTimeout(()=>{v.classList.remove("show"),setTimeout(()=>v.remove(),300)},2200)};const g=()=>{const E=document.getElementById("sso-sidebar"),I=document.getElementById("sidebar-overlay");E&&E.classList.add("open"),I&&I.classList.add("visible"),this.player&&(this.player.controlsLocked=!0,this.player.resetInputs())};window.openSSOSidebar=()=>{g()};const y=()=>{const E=document.getElementById("sso-sidebar"),I=document.getElementById("sidebar-overlay");E&&E.classList.remove("open"),I&&I.classList.remove("visible"),this.player&&(this.player.controlsLocked=!1)},m=E=>{E.stopPropagation(),g()};i&&i.addEventListener("click",m),s&&s.addEventListener("click",m),c&&c.addEventListener("click",E=>{E.stopPropagation(),y()}),r&&r.addEventListener("click",E=>{E.stopPropagation(),y()});const f=()=>{const E=localStorage.getItem("sso_access_token"),I=localStorage.getItem("sso_user");if(E&&I)try{const v=JSON.parse(I);i&&(i.style.display="none"),s&&(s.style.display="flex");const S=v.avatar||'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E';a&&(a.src=S),l&&(l.src=S),h&&(h.textContent=v.username),d&&(d.textContent="已登录",d.style.borderColor="rgba(100, 255, 150, 0.4)",d.style.color="#5aff8a"),u&&(u.style.display="none"),p&&(p.style.display="flex")}catch(v){console.error("Parse user failed",v)}else i&&(i.style.display="flex"),s&&(s.style.display="none"),l&&(l.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E'),h&&(h.textContent="未登录"),d&&(d.textContent="游客",d.style.borderColor="rgba(255, 140, 105, 0.25)",d.style.color="var(--primary)"),u&&(u.style.display="inline-block"),p&&(p.style.display="none")},_=document.getElementById("sidebar-back-2d-btn");if(_){const E=I=>{I.stopPropagation(),(window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1")&&window.location.port==="3000"?window.location.href="http://127.0.0.1:8000/index.html":window.location.href="/index.html"};_.addEventListener("click",E)}u&&u.addEventListener("click",E=>{E.preventDefault();let v=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?"http://127.0.0.1:8000/index.html":"/index.html";if(document.referrer&&(document.referrer.includes("index.html")||document.referrer.endsWith("/")))try{const P=new URL(document.referrer);(P.pathname==="/"||P.pathname.endsWith("/index.html"))&&(v=P.origin+P.pathname)}catch{}const S=window.location.href;window.location.href=`${v}?sso_return_url=${encodeURIComponent(S)}`}),p&&p.addEventListener("click",E=>{E.preventDefault(),localStorage.removeItem("sso_access_token"),localStorage.removeItem("sso_user"),f(),y(),window.location.reload()});const x=document.getElementById("sidebar-stuck-btn");x&&x.addEventListener("click",E=>{E.stopPropagation(),this.unstuckPlayer(),y()});const M=document.getElementById("btn-map-island"),R=document.getElementById("btn-map-house");M&&M.addEventListener("click",E=>{E.stopPropagation(),this.switchMap("island"),y()}),R&&R.addEventListener("click",E=>{E.stopPropagation(),this.switchMap("house"),y()}),[{id:"btn-sidebar-leaderboard",name:"leaderboard"},{id:"btn-sidebar-tasks",name:"tasks"},{id:"btn-sidebar-farm",name:"farm"},{id:"btn-sidebar-pk",name:"pk"},{id:"btn-sidebar-bag",name:"bag"},{id:"btn-sidebar-home",name:"home"}].forEach(E=>{const I=document.getElementById(E.id);I&&I.addEventListener("click",v=>{v.stopPropagation(),y(),E.name==="farm"?(this.switchMap("farm"),setTimeout(()=>{if(window.showMockToast){let S=document.querySelector(".mock-toast");S&&S.remove();const P=document.createElement("div");P.className="mock-toast",P.textContent="已传送至您的 3D 农场岛！走近泥地格按 E 种植/收割 🌾",document.body.appendChild(P),setTimeout(()=>P.classList.add("show"),50),setTimeout(()=>{P.classList.remove("show"),setTimeout(()=>P.remove(),300)},2200)}},this.currentMap==="house"?600:50)):E.name==="pk"?(this.switchMap("pk_arena",new L(0,.6+.1,-6.5)),setTimeout(()=>{if(window.showMockToast){let S=document.querySelector(".mock-toast");S&&S.remove();const P=document.createElement("div");P.className="mock-toast",P.textContent="已传送至 3D 竞技大厅！走近前方蓝色的“决斗水晶”按 E 开启匹配决斗 ⚔️",document.body.appendChild(P),setTimeout(()=>P.classList.add("show"),50),setTimeout(()=>{P.classList.remove("show"),setTimeout(()=>P.remove(),300)},2500)}},this.currentMap==="house"?600:50)):this.modalMgr&&this.modalMgr.openModal(E.name)})}),f(),window.addEventListener("keydown",E=>{if(E.key==="Escape"){const I=document.activeElement;if(I&&(I.tagName==="INPUT"||I.tagName==="TEXTAREA"||I.isContentEditable))return;const v=document.getElementById("btn-settle-close");if(v){E.preventDefault(),v.click();return}if(this.modalMgr&&this.modalMgr.isAnyModalOpen){E.preventDefault(),this.modalMgr.closeAllModals();return}if(window.self!==window.top&&window.parent&&window.parent.appShell&&typeof window.parent.appShell.toggleSidebar=="function"){E.preventDefault(),window.parent.appShell.toggleSidebar();return}const S=document.getElementById("sso-sidebar");S&&(E.preventDefault(),S.classList.contains("open")?y():g())}}),document.addEventListener("touchmove",E=>{E.target.closest(".scrollable")||E.target.closest(".wardrobe-sidebar")||E.target.closest(".modal-body")||E.target.closest(".sso-sidebar")||E.cancelable&&E.preventDefault()},{passive:!1})}initEngine(){this.scene=new pg;const t=this.themeConfig.colors.sky||11725810;this.scene.background=new Vt(t),this.camera=new Ge(45,window.innerWidth/window.innerHeight,.1,200),this.renderer=new Ah({antialias:!0,alpha:!1}),this.renderer.setSize(window.innerWidth,window.innerHeight);const e="ontouchstart"in window||navigator.maxTouchPoints>0;this.renderer.setPixelRatio(e?Math.min(window.devicePixelRatio,1.35):Math.min(window.devicePixelRatio,2)),this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.type=e?Tr:jl,this.renderer.toneMapping=Kl,this.renderer.toneMappingExposure=1.35,this.container.appendChild(this.renderer.domElement),window.addEventListener("resize",()=>this.onWindowResize())}initWorld(){this.currentMap="island",document.body.id==="page-lobby"?this.currentMap="island":document.body.id==="page-house"?this.currentMap="house":document.body.id==="page-farm"?this.currentMap="farm":document.body.id==="page-pvp"?this.currentMap="pk_arena":document.body.id==="page-lake"?this.currentMap="lake":document.body.id==="page-castle"&&(this.currentMap="castle"),this.modalMgr=new sw,this.environment=new ow(this.scene,this.themeConfig),this.currentMap==="island"?(this.islandGen=new aw(this.scene,this.themeConfig),this.player=new ts(this.scene,this.camera,this.islandGen.colliders,this.themeConfig),this.interactMgr=new es(this.player,this.islandGen,this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="house"?(this.houseGen=new rw(this.scene,this.themeConfig),this.houseGen.group.visible=!0,this.player=new ts(this.scene,this.camera,this.houseGen.colliders,this.themeConfig),this.interactMgr=new es(this.player,this.houseGen,this.modalMgr,this),this.environment.setIndoorMode(!0)):this.currentMap==="farm"?(this.farmGroup=new ot,this.scene.add(this.farmGroup),this.farmGroup.visible=!0,this.buildFarmPlatform(),this.player=new ts(this.scene,this.camera,this.farmColliders||[],this.themeConfig),this.interactMgr=new es(this.player,{interactables:this.farmInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="pk_arena"?(this.pkArenaGroup=new ot,this.scene.add(this.pkArenaGroup),this.pkArenaGroup.visible=!0,this.buildPKPlatform(),this.player=new ts(this.scene,this.camera,this.pkArenaColliders||[],this.themeConfig),this.interactMgr=new es(this.player,{interactables:this.pkArenaInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)):this.currentMap==="lake"?(this.lakeGroup=new ot,this.scene.add(this.lakeGroup),this.lakeGroup.visible=!0,this.buildLakePlatform(),this.player=new ts(this.scene,this.camera,this.lakeColliders||[],this.themeConfig),this.interactMgr=new es(this.player,{interactables:this.lakeInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1),window.addEventListener("piano-note-played",a=>{this.currentMap==="lake"&&this.spawnNoteParticle(a.detail.note)})):this.currentMap==="castle"&&(this.castleGroup=new ot,this.scene.add(this.castleGroup),this.castleGroup.visible=!0,this.buildCastlePlatform(),this.player=new ts(this.scene,this.camera,this.castleColliders||[],this.themeConfig),this.interactMgr=new es(this.player,{interactables:this.castleInteractables||[]},this.modalMgr,this),this.environment.setIndoorMode(!1)),this.player.app=this;const e=new URLSearchParams(window.location.search).get("spawn");if(e){const a=e.split(",").map(Number);a.length===3&&!a.some(isNaN)&&(this.player.position.set(a[0],a[1],a[2]),this.player.group.position.copy(this.player.position),this.currentMap==="house"||this.currentMap==="farm"||this.currentMap==="castle"?(this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="pk_arena"?a[2]<0?(this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):(this.player.group.rotation.y=-Math.PI/2,this.player.cameraAngleH=-Math.PI/2):(this.currentMap==="island"||this.currentMap==="lake")&&(this.player.group.rotation.y=0,this.player.cameraAngleH=0))}else this.currentMap==="house"?(this.player.position.set(0,.12+.1,9.5),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="farm"?(this.player.position.set(0,.6+.1,-8),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="pk_arena"?(this.player.position.set(-5,.6+.1,0),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=-Math.PI/2,this.player.cameraAngleH=-Math.PI/2):this.currentMap==="lake"?(this.player.position.set(0,.6+.1,8.5),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):this.currentMap==="castle"?(this.player.position.set(-2.5,.6+.1,11.5),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=Math.PI,this.player.cameraAngleH=Math.PI):(this.player.position.set(0,4,0),this.player.group.position.copy(this.player.position));const n=Di.activeTheme==="christmas";window.addEventListener("spawn-ball",a=>{if(this.currentMap!=="island")return;const r=a.detail.x,c=a.detail.z+.6,l=n?[16777215,14743546,16120573]:[16732754,4244735,16771899,16747136,58998],h=l[Math.floor(Math.random()*l.length)],d=new cw(this.scene,r,1.3,c,h);if(d.app=this,this.beachBallsList.push(d),this.beachBallsList.length>5){let u=-1;for(let p=0;p<this.beachBallsList.length;p++)if(!this.beachBallsList[p].isCarried){u=p;break}u!==-1&&this.beachBallsList.splice(u,1)[0].destroy()}this.playCustomSound(n?320:450,.12,"sine",.08)}),window.addEventListener("kick-sound",a=>{this.playCustomSound(n?a.detail.freq*.6:a.detail.freq,.16,n?"sine":"triangle",.18)}),this.initWardrobeUI();const i=document.getElementById("btn-toggle-time");if(i){const a=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.environment&&(this.environment.isNight=!this.environment.isNight,this.playCustomSound(this.environment.isNight?220:440,.4,"sine",.08))};i.addEventListener("touchstart",a,{passive:!1}),i.addEventListener("click",a)}const s=document.getElementById("btn-stand-up");if(s){const a=r=>{r&&(r.preventDefault(),r.stopPropagation()),this.player&&this.player.isLyingDown&&this.player.standUp()};s.addEventListener("touchstart",a,{passive:!1}),s.addEventListener("click",a)}window.parent&&window.parent.appShell&&typeof window.parent.appShell.onMapLoaded=="function"&&window.parent.appShell.onMapLoaded(this.currentMap)}initWardrobeUI(){const t=(n,i)=>{const s=document.getElementById(n);if(!s)return;s.querySelectorAll(".color-btn").forEach(r=>{r.addEventListener("click",()=>{var l;(l=s.querySelector(".color-btn.active"))==null||l.classList.remove("active"),r.classList.add("active");const c=r.getAttribute("data-color");this.player&&this.player.updateOutfit(i,c)})})};t("wardrobe-hair","hair"),t("wardrobe-clothes","clothing"),t("wardrobe-hat","hat"),document.querySelectorAll(".model-btn").forEach(n=>{n.addEventListener("click",()=>{var s;(s=document.querySelector(".model-btn.active"))==null||s.classList.remove("active"),n.classList.add("active");const i=n.getAttribute("data-model");if(this.player){this.player.updateModel(i);const a=document.getElementById("wardrobe-hair-title"),r=document.getElementById("wardrobe-clothing-title"),c=document.getElementById("wardrobe-hat-title");i==="kitty"?(a&&(a.textContent="毛皮颜色 (Fur Color)"),r&&(r.textContent="小猫背心 (Vest Color)"),c&&(c.textContent="金铃铛颜色 (Bell Color)")):(a&&(a.textContent="发发 / 毛毛"),r&&(r.textContent="服装颜色"),c&&(c.textContent="配饰 / 铃铛颜色")),this.playCustomSound(440,.15,"triangle",.06)}})})}playCustomSound(t,e,n="sine",i=.05){if(window.parent&&typeof window.parent.playCustomSound=="function"){window.parent.playCustomSound(t,e,n,i);return}try{this.audioCtx||(this.audioCtx=new(window.AudioContext||window.webkitAudioContext)),this.audioCtx.state==="suspended"&&this.audioCtx.resume();const s=this.audioCtx.createOscillator(),a=this.audioCtx.createGain();s.type=n,s.frequency.setValueAtTime(t,this.audioCtx.currentTime),a.gain.setValueAtTime(i,this.audioCtx.currentTime),a.gain.exponentialRampToValueAtTime(1e-4,this.audioCtx.currentTime+e),s.connect(a),a.connect(this.audioCtx.destination),s.start(),s.stop(this.audioCtx.currentTime+e)}catch(s){console.warn("Play custom sound failed",s)}}initMobileJoystick(){}initAudioSynth(){}playMelodyLoop(){}playMelodyLoop(){const t=Di.activeTheme==="christmas",e=t?1.2:1,n=[[130.81,196,261.63,329.63,392].map(r=>r*e),[146.83,220,293.66,349.23,440].map(r=>r*e),[164.81,246.94,329.63,392,493.88].map(r=>r*e),[116.54,174.61,233.08,293.66,349.23].map(r=>r*e)];let i=0,s=0;const a=(r,c,l="sine",h=.05)=>{if(!this.isPlayingMusic||!this.audioCtx)return;const d=this.audioCtx.createOscillator(),u=this.audioCtx.createGain();d.type=l,d.frequency.setValueAtTime(r,this.audioCtx.currentTime),u.gain.setValueAtTime(h,this.audioCtx.currentTime),u.gain.exponentialRampToValueAtTime(1e-4,this.audioCtx.currentTime+c),d.connect(u),u.connect(this.audioCtx.destination),d.start(),d.stop(this.audioCtx.currentTime+c)};this.synthInterval=setInterval(()=>{const r=n[i],c=[0,2,1,3,2,4,3,1],l=c[s%c.length],h=r[l];if(a(h,.9,"sine",t?.05:.08),s%4===0&&Math.random()>.3){const u=h*2;a(u,1.6,"sine",t?.04:.03)}s++,s%16===0&&(i=(i+1)%n.length)},320)}onWindowResize(){this.camera.aspect=window.innerWidth/window.innerHeight,this.camera.updateProjectionMatrix(),this.renderer.setSize(window.innerWidth,window.innerHeight)}switchMap(t,e=null,n=null,i=null){let s="";t==="island"?s="lobby.html":t==="house"?s="house.html":t==="farm"?s="farm.html":t==="pk_arena"?s="pvp.html":t==="lake"?s="lake.html":t==="castle"&&(s="castle.html");const a=[];e&&a.push(`spawn=${e.x.toFixed(2)},${e.y.toFixed(2)},${e.z.toFixed(2)}`),n&&a.push(`modal=${n}`),i&&a.push(`action=${i}`),a.length>0&&(s+="?"+a.join("&"));const r=document.getElementById("fade-overlay");r&&r.classList.add("fade-in"),setTimeout(()=>{window.location.href=s},450)}unstuckPlayer(){if(this.player&&((this.player.isSitting||this.player.isLyingDown)&&this.player.standUp(),this.currentMap==="house"?this.player.position.set(0,.12+.1,9.5):this.player.position.set(-10,.6+.1,-5.2),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),this.player.group.rotation.y=this.currentMap==="house"?Math.PI:0,this.player.cameraAngleH=this.currentMap==="house"?Math.PI:0,window.showMockToast)){let t=document.querySelector(".mock-toast");t&&t.remove();const e=document.createElement("div");e.className="mock-toast",e.textContent="重置成功！角色已脱离卡死 🌀",document.body.appendChild(e),setTimeout(()=>{e.classList.add("show")},50),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>e.remove(),300)},2200)}}animate(){if(requestAnimationFrame(()=>this.animate()),window.parent&&window.parent.keys){const n=!!window.parent.keys.j;n&&!this.lastParentJ&&typeof this.playerPerformAttack=="function"&&this.playerPerformAttack(),this.lastParentJ=n}const t=Math.min(this.clock.getDelta(),.1),e=this.clock.getElapsedTime()*1e3;this.player&&this.player.update(t,e),this.environment&&this.environment.update(e),this.islandGen&&this.islandGen.update(e,this.environment),this.interactMgr&&this.interactMgr.update(),this.beachBallsList&&this.player&&this.beachBallsList.forEach(n=>n.update(t,this.player)),this.updateGameSystemsFrame(t,e),this.currentMap==="lake"&&this.updateLakeFrame(t,e),this.currentMap==="castle"&&this.updateCastleFrame(t,e),this.renderer&&this.scene&&this.camera&&this.renderer.render(this.scene,this.camera)}getInitialGameData(){return{coins:200,level:1,exp:0,pkPoints:1e3,pkWins:0,pkLoses:0,onlineTime:0,backpack:[{id:"sunflower_seed",name:"向日葵种子",type:"seed",count:5,quality:"green",desc:"可在农田里种植，成熟后收割获得丰厚金币。"},{id:"strawberry_seed",name:"草莓种子",type:"seed",count:2,quality:"blue",desc:"可在农田里种植，成熟收割获得巨额回报。"}],farmPlots:[{id:0,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:1,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:2,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:3,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:4,status:"empty",seedId:null,plantTime:0,unlocked:!0},{id:5,status:"empty",seedId:null,plantTime:0,unlocked:!0}],homeFurnitures:[],ownedFurnitures:["painting_1","tree_1"],tasks:[{id:"kick_ball",name:"在群岛领取沙滩球或踢球 1 次",progress:0,target:1,reward:50,status:"ongoing",type:"kick"},{id:"rest_bed",name:"在温馨小屋床上休息 1 次",progress:0,target:1,reward:50,status:"ongoing",type:"rest"},{id:"play_billiards",name:"游玩 1 局弹射台球游戏",progress:0,target:1,reward:80,status:"ongoing",type:"game_billiards"},{id:"play_poker",name:"游玩 1 局 21点纸牌游戏",progress:0,target:1,reward:80,status:"ongoing",type:"game_poker"},{id:"crop_harvest",name:"收割成熟的农地作物 3 次",progress:0,target:3,reward:100,status:"ongoing",type:"harvest"}],dailyChestClaimed:!1,lastTaskResetDate:new Date().toLocaleDateString()}}async loadGameData(){const t=localStorage.getItem("sso_access_token"),e=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";let n=null;if(t)try{const a=await(await fetch(`${e}/api/game/data?game_id=3d-home-all`,{headers:{Authorization:`Bearer ${t}`}})).json();a.success&&a.data&&a.data.save_data&&(n=a.data.save_data)}catch(s){console.error("从云端加载存档失败，采用本地缓存",s)}if(!n){const s=localStorage.getItem("player_game_data");if(s)try{n=JSON.parse(s)}catch(a){console.error("本地存档解析失败",a)}}if(!n)n=this.getInitialGameData();else{const s=this.getInitialGameData();n=Object.assign({},s,n)}this.gameData=n;const i=new Date().toLocaleDateString();this.gameData.lastTaskResetDate!==i&&(this.gameData.tasks=this.getInitialGameData().tasks,this.gameData.dailyChestClaimed=!1,this.gameData.lastTaskResetDate=i,this.saveGameData()),this.updateBaseUI()}async saveGameData(){localStorage.setItem("player_game_data",JSON.stringify(this.gameData));const t=localStorage.getItem("sso_access_token"),e=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";if(t)try{await fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"3d-home-all",score:this.gameData.level,save_data:this.gameData})}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"pkPoints",score:this.gameData.pkPoints})}).catch(()=>{}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"coins",score:this.gameData.coins})}).catch(()=>{}),fetch(`${e}/api/game/score`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t}`},body:JSON.stringify({game_id:"level",score:this.gameData.level})}).catch(()=>{})}catch(n){console.error("云端存档同步失败",n)}this.updateBaseUI()}updateBaseUI(){const t=document.getElementById("farm-coins"),e=document.getElementById("home-coins"),n=document.getElementById("farm-level"),i=document.getElementById("farm-exp"),s=document.querySelector("#modal-bag .bag-coins-val");t&&(t.textContent=this.gameData.coins),e&&(e.textContent=this.gameData.coins),n&&(n.textContent=this.gameData.level),i&&(i.textContent=this.gameData.exp),s&&(s.textContent=this.gameData.coins)}initGameSystems(){this.gameData=this.getInitialGameData(),this.loadGameData(),setInterval(()=>{this.gameData.onlineTime++,this.gameData.onlineTime%60===0&&(this.gameData.exp+=15,this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,this.playCustomSound(523.25,.4,"triangle",.1)),this.saveGameData())},1e3),window.addEventListener("spawn-ball",()=>{this.updateTaskProgress("kick",1)}),window.addEventListener("modal-opened",i=>{const s=i.detail.modalId;s==="leaderboard"&&this.refreshLeaderboard(),s==="tasks"&&this.refreshTasks(),s==="farm"&&this.refreshFarm(),s==="pk"&&this.refreshPK(),s==="bag"&&this.refreshBag(),s==="home"&&this.refreshHome(),s==="shop"&&(this.updateShopCoins(),this.renderShopItems(this.getActiveShopTab()))}),this.initLeaderboardUI(),this.initTasksUI(),this.initFarmUI(),this.initPKUI(),this.initBagUI(),this.initHomeUI(),this.initMapUI(),this.initShopUI(),this.initRadialSeedMenu();const t=new URLSearchParams(window.location.search),e=t.get("modal");if(e&&this.modalMgr&&setTimeout(()=>{this.modalMgr.openModal(e)},500),t.get("action")==="edit"&&setTimeout(()=>{this.enterHomeEditMode()},500),this.currentMap==="pk_arena"&&setTimeout(()=>{this.modalMgr&&this.modalMgr.openModal("pk")},500),this.currentMap==="farm"){const i=document.createElement("div");i.id="farm-bubbles-container",i.style.position="absolute",i.style.top="0",i.style.left="0",i.style.width="100%",i.style.height="100%",i.style.pointerEvents="none",i.style.zIndex="10",document.body.appendChild(i)}window.addEventListener("kick-sound",()=>{this.updateTaskProgress("kick",1)}),this.currentMap==="house"&&(typeof this.renderHomeFurnitures=="function"&&this.renderHomeFurnitures(),this.initExitChoicesUI()),window.addEventListener("keydown",i=>{if(i.target.tagName==="INPUT"||i.target.tagName==="TEXTAREA")return;const s=i.key.toLowerCase();s==="b"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.bag.classList.contains("open")?this.modalMgr.closeModal("bag"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("bag")))):s==="j"?(i.preventDefault(),this.currentMap==="farm"?this.isRadialMenuOpen?this.closeRadialSeedMenu():this.openRadialSeedMenu():this.modalMgr&&(this.modalMgr.modals.tasks.classList.contains("open")?this.modalMgr.closeModal("tasks"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("tasks")))):s==="p"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.leaderboard.classList.contains("open")?this.modalMgr.closeModal("leaderboard"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("leaderboard")))):s==="m"?(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.map.classList.contains("open")?this.modalMgr.closeModal("map"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("map")))):s==="g"&&(i.preventDefault(),this.modalMgr&&(this.modalMgr.modals.shop.classList.contains("open")?this.modalMgr.closeModal("shop"):(this.modalMgr.closeAllModals(),this.modalMgr.openModal("shop"))))})}initLeaderboardUI(){const t=document.querySelectorAll("#modal-leaderboard .tab-btn");t.forEach(e=>{e.addEventListener("click",n=>{t.forEach(i=>i.classList.remove("active")),e.classList.add("active"),this.refreshLeaderboard(e.getAttribute("data-tab"))})})}getMockLeaderboard(t){const e=["浮云行者","琴海微风","金色沙滩","椰子冰沙","派蒙小跟班","晨曦守护","月见草","落樱纷飞","温馨秋千","大锤王二"],n=[];let i=t==="pkPoints"?1e3:t==="coins"?200:1,s=t==="pkPoints"?60:t==="coins"?50:2;for(let h=0;h<9;h++)n.push({username:e[h],avatar:"",score:i+(9-h)*s});let a=this.gameData.pkPoints;t==="coins"&&(a=this.gameData.coins),t==="level"&&(a=this.gameData.level);const r=localStorage.getItem("sso_user");let c="您自己",l="";if(r)try{const h=JSON.parse(r);c=h.username,l=h.avatar}catch{}return n.push({username:c,avatar:l,score:a,isMe:!0}),n.sort((h,d)=>d.score-h.score),n.slice(0,10)}async refreshLeaderboard(t="pkPoints"){const e=document.getElementById("leaderboard-list-view"),n=document.getElementById("leaderboard-my-rank");if(!e)return;e.innerHTML='<div style="text-align:center; padding: 20px; font-size: 0.85rem; color: var(--text-muted);">数据加载中...</div>';const i=localStorage.getItem("sso_access_token"),s=window.location.hostname==="localhost"||window.location.hostname==="127.0.0.1"?`http://${window.location.hostname}:3001`:"http://111.229.107.228:3001";let a=[],r=!1;if(i)try{const p=await fetch(`${s}/api/game/leaderboard?game_id=${t}`).then(g=>g.json());p.success&&p.leaderboard&&p.leaderboard.length>0&&(a=p.leaderboard,r=!0)}catch(p){console.error("加载服务端排行榜失败",p)}r||(a=this.getMockLeaderboard(t)),e.innerHTML="";const c=localStorage.getItem("sso_user");let l="您自己";if(c)try{l=JSON.parse(c).username}catch{}a.forEach((p,g)=>{const y=p.username===l||p.isMe,m=document.createElement("div");m.className=`leaderboard-item rank-${g+1}`,y&&(m.style.background="rgba(255, 140, 105, 0.15)",m.style.borderColor="rgba(255, 140, 105, 0.3)");const f=p.avatar||'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"%3E%3Ccircle cx="12" cy="8" r="4"%3E%3C/circle%3E%3Cpath d="M12 14c-4 0-6 2-6 4v2h12v-2c0-2-2-4-6-4z"%3E%3C/path%3E%3C/svg%3E',_=t==="pkPoints"?" 积分":t==="coins"?" 金币":" 级";m.innerHTML=`
        <div class="leaderboard-rank" style="font-weight: bold; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%;">${g+1}</div>
        <img class="leaderboard-avatar" src="${f}" alt="头像" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1.5px solid rgba(255,255,255,0.2);">
        <div class="leaderboard-name" style="flex: 1; margin-left: 10px; font-size: 0.9rem; font-weight: 600;">${p.username}</div>
        <div class="leaderboard-score" style="font-size: 0.95rem; font-weight: bold; color: var(--primary);">${p.score}${_}</div>
      `,e.appendChild(m)});let h=this.gameData.pkPoints;t==="coins"&&(h=this.gameData.coins),t==="level"&&(h=this.gameData.level);let d="未上榜";const u=a.findIndex(p=>p.username===l||p.isMe);u!==-1&&(d=`第 ${u+1} 名`),n&&(n.innerHTML=`
        <span>当前名次: <strong style="color: var(--primary);">${d}</strong></span>
        <span style="margin-left: 20px;">我的数值: <strong style="color: var(--secondary);">${h}</strong></span>
      `)}initTasksUI(){const t=document.getElementById("btn-tasks-claim-chest"),e=document.getElementById("tasks-chest-btn"),n=i=>{if(i.stopPropagation(),this.gameData.tasks.filter(a=>a.progress>=a.target).length===5&&!this.gameData.dailyChestClaimed){this.gameData.dailyChestClaimed=!0,this.gameData.coins+=300,this.showCoinFloatText(300,i.clientX,i.clientY),this.gameData.exp+=100;let a=!1;this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,a=!0),this.saveGameData(),this.updateBaseUI(),this.refreshTasks(),a?setTimeout(()=>{this.playCustomSound(523.25,.4,"triangle",.1),this.showToast("恭喜升级啦！✨ 等级提升！")},300):(this.playCustomSound(880,.1,"sine",.05),setTimeout(()=>this.playCustomSound(1200,.2,"sine",.05),100))}};t&&t.addEventListener("click",n),e&&e.addEventListener("click",n)}updateTaskProgress(t,e=1){let n=!1;this.gameData.tasks.forEach(i=>{i.type===t&&i.status==="ongoing"&&(i.progress=Math.min(i.target,i.progress+e),i.progress>=i.target&&(i.status="claimable"),n=!0)}),n&&this.saveGameData()}refreshTasks(){const t=document.getElementById("tasks-list");if(!t)return;t.innerHTML="";const e=this.gameData.tasks.filter(c=>c.progress>=c.target).length,n=document.getElementById("tasks-progress-text"),i=document.getElementById("tasks-progress-bar"),s=document.getElementById("tasks-chest-btn"),a=document.getElementById("tasks-chest-tips"),r=document.getElementById("btn-tasks-claim-chest");n&&(n.textContent=`${e} / 5`),i&&(i.style.width=`${e/5*100}%`),this.gameData.dailyChestClaimed?(s&&(s.textContent="📦",s.style.animation="none",s.style.cursor="default"),a&&(a.innerHTML='<span style="color: #4caf50; font-weight: bold;">每日宝箱奖励已领取！📯</span><br><span style="font-size: 0.68rem;">获得了 300金币 + 100经验。明天再来吧！🌟</span>'),r&&(r.textContent="已领取",r.disabled=!0,r.style.background="rgba(255,255,255,0.08)",r.style.color="var(--text-muted)",r.style.borderColor="transparent")):e===5?(s&&(s.textContent="🎁",s.style.animation="chestBounce 1.2s infinite alternate ease-in-out",s.style.cursor="pointer"),a&&(a.innerHTML='<span style="color: #ffd700; font-weight: bold;">今日任务已全部达成！✨</span><br><span style="font-size: 0.68rem; color: #fff;">快点击宝箱或下方按钮领取额外大奖！</span>'),r&&(r.textContent="开启宝箱",r.disabled=!1,r.style.background="linear-gradient(135deg, #ffd700 0%, #ff9800 100%)",r.style.color="#000",r.style.borderColor="#ffd700")):(s&&(s.textContent="🎁",s.style.animation="none",s.style.cursor="default"),a&&(a.textContent="完成今日全部 5 个任务即可开启宝箱，获得 300 金币与 100 经验！"),r&&(r.textContent="未达成",r.disabled=!0,r.style.background="rgba(255,255,255,0.04)",r.style.color="var(--text-muted)",r.style.borderColor="transparent")),this.gameData.tasks.forEach(c=>{const l=document.createElement("div");l.className=`task-card-item ${c.status==="claimed"?"task-completed":""}`;let h="";c.status==="ongoing"?h=`<button class="task-btn-action" data-action="go" data-type="${c.type}">去完成</button>`:c.status==="claimable"?h=`<button class="task-btn-action task-btn-claim" data-action="claim" data-id="${c.id}">领取奖励</button>`:h='<button class="task-btn-action task-btn-done">已领取</button>';const d=Math.min(100,Math.floor(c.progress/c.target*100));l.innerHTML=`
        <div class="task-meta">
          <span class="task-title">${c.name}</span>
          <span class="task-reward">🎁 +${c.reward}金币</span>
        </div>
        <div class="task-progress-wrap" style="margin-top: 10px;">
          <div class="task-progress-bar">
            <div class="task-progress-fill" style="width: ${d}%;"></div>
          </div>
          <span class="task-progress-text">${c.progress}/${c.target}</span>
          ${h}
        </div>
      `;const u=l.querySelector(".task-btn-claim");u&&u.addEventListener("click",g=>{g.stopPropagation(),this.claimTaskReward(c.id,g.clientX,g.clientY)});const p=l.querySelector('.task-btn-action[data-action="go"]');p&&p.addEventListener("click",g=>{if(g.stopPropagation(),this.modalMgr.closeAllModals(),c.type==="game_billiards"){const y=Di.games.find(m=>m.id==="billiards");y&&this.modalMgr.launchGame(y),this.updateTaskProgress("game_billiards",1)}else if(c.type==="game_poker"){const y=Di.games.find(m=>m.id==="21dian");y&&this.modalMgr.launchGame(y),this.updateTaskProgress("game_poker",1)}else c.type==="kick"?this.switchMap("island",new L(-5,.7,5)):c.type==="rest"?this.switchMap("house",new L(2.8,.22,4)):c.type==="harvest"&&this.switchMap("farm",new L(0,.7,-8))}),t.appendChild(l)})}claimTaskReward(t,e,n){const i=this.gameData.tasks.find(s=>s.id===t);!i||i.status!=="claimable"||(i.status="claimed",this.gameData.coins+=i.reward,this.saveGameData(),this.showCoinFloatText(i.reward,e,n),this.refreshTasks())}showCoinFloatText(t,e,n){const i=document.createElement("div");i.className="coin-float-text";const s=e!==void 0?e:window.innerWidth/2,a=n!==void 0?n:window.innerHeight/2;i.style.left=`${s}px`,i.style.top=`${a}px`;const r=t>0;i.innerHTML=`${r?"+":""}${t} <span style="font-size: 1.1em; margin-left: 2px;">🪙</span>`,i.style.color=r?"#ffd700":"#ff8a80",i.style.textShadow=r?"0 0 10px rgba(255,215,0,0.6)":"0 0 10px rgba(255,138,128,0.6)",document.body.appendChild(i),r?(this.playCustomSound(987.77,.08,"square",.03),setTimeout(()=>this.playCustomSound(1318.51,.25,"square",.03),80)):this.playCustomSound(329.63,.15,"sawtooth",.04),setTimeout(()=>{i.remove()},1e3)}showToast(t){let e=document.querySelector(".mock-toast");e&&e.remove();const n=document.createElement("div");n.className="mock-toast",n.textContent=t,document.body.appendChild(n),setTimeout(()=>{n.classList.add("show")},50),setTimeout(()=>{n.classList.remove("show"),setTimeout(()=>n.remove(),300)},2200)}triggerPlotInteraction(t){const e=this.gameData.farmPlots[t];if(e)if(e.status==="empty")this.activePlotIndex=t,this.openRadialSeedMenu();else if(e.status==="ready")this.harvestCrop(t);else{const n=e.seedId==="sunflower_seed"?30:60,i=Math.floor((Date.now()-e.plantTime)/1e3),s=Math.max(0,n-i),a=e.seedId==="sunflower_seed"?"向日葵":"草莓";this.showToast(`${a} 正在生长中，还需等待 ${s} 秒 ⏳`)}}initFarmUI(){this.refreshFarm()}refreshFarm(){const t=document.getElementById("farm-grid");t&&(t.innerHTML="",this.gameData.farmPlots.forEach((e,n)=>{const i=document.createElement("div");if(i.className="farm-plot",!e.unlocked)i.classList.add("locked"),i.innerHTML=`
          <div style="font-size: 1.5rem; opacity: 0.4;">🔒</div>
          <span style="font-size: 0.65rem; color: #ff8a80; margin-top: 4px;">未解锁</span>
        `;else if(e.status==="empty")i.innerHTML=`
          <div style="font-size: 1.8rem; color: #2ecc71;">➕</div>
          <span style="font-size: 0.72rem; color: var(--text-muted); margin-top: 4px;">空地</span>
        `,i.addEventListener("click",()=>{this.activePlotIndex=n,this.openRadialSeedMenu()});else{const s=e.status==="ready",a=e.seedId==="sunflower_seed"?"🌻":"🍓",r=e.seedId==="sunflower_seed"?"向日葵":"草莓";let c="";if(s)c='<span class="plot-crop-ready">🌾 可收割</span>';else{const l=e.seedId==="sunflower_seed"?30:60,h=Math.floor((Date.now()-e.plantTime)/1e3);c=`<span class="plot-crop-timer">⏳ ${Math.max(0,l-h)}s</span>`}i.innerHTML=`
          <span class="plot-crop-icon">${a}</span>
          <span class="plot-crop-name">${r}</span>
          ${c}
        `,s&&i.addEventListener("click",()=>{this.harvestCrop(n)})}t.appendChild(i)}))}buyAndPlant(t){const e=t==="sunflower_seed"?10:20;if(this.gameData.coins<e){alert("金币不足，无法购买种子！");return}this.gameData.coins-=e;const n=this.gameData.farmPlots[this.activePlotIndex];n.status="growing",n.seedId=t,n.plantTime=Date.now(),this.saveGameData(),document.getElementById("sub-modal-seed-shop").style.display="none",this.player&&(this.player.controlsLocked=!1),this.refreshFarm(),this.playCustomSound(330,.25,"sine",.1),this.recreateCrop3D(this.activePlotIndex);const i=t==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功播种了 ${i} 种子 🌱`)}harvestCrop(t){const e=this.gameData.farmPlots[t];if(!e||e.status!=="ready")return;const n=e.seedId==="sunflower_seed"?"sunflower_crop":"strawberry_crop",i=e.seedId==="sunflower_seed"?"新鲜向日葵":"多汁草莓",s=e.seedId,a=e.seedId==="sunflower_seed"?15:35;e.status="empty",e.seedId=null,e.plantTime=0;const r=this.gameData.backpack.find(l=>l.id===n);r?r.count++:this.gameData.backpack.push({id:n,name:i,type:"collect",count:1,quality:s==="sunflower_seed"?"green":"blue",desc:"在自家农田收获的优质作物，可直接在背包中出售以换取游戏币。"}),this.gameData.exp+=a,this.gameData.exp>=100&&(this.gameData.level++,this.gameData.exp-=100,this.playCustomSound(523.25,.4,"triangle",.1)),this.saveGameData(),this.refreshFarm(),this.updateTaskProgress("harvest",1),this.playCustomSound(440,.2,"sine",.1),this.recreateCrop3D(t);const c=s==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功收割了 ${c} 🌾！已存入背包`)}recreateCrop3D(t){if(!this.farmPlots3D)return;const e=this.farmPlots3D[t];if(!e)return;e.plantGroup.clear();const n=this.gameData.farmPlots[t];if(n.status==="empty"||!n.seedId)return;const i=new ot;if(n.seedId==="sunflower_seed"){const a=new K(.04,.04,.7,6),r=new V({color:3046706}),c=new w(a,r);c.position.y=.35,c.castShadow=!0,i.add(c);const l=new K(.2,.2,.06,8),h=new V({color:16771899}),d=new w(l,h);d.position.set(0,.7,.05),d.rotation.x=Math.PI/4,i.add(d);const u=new K(.1,.1,.08,8),p=new V({color:6111287}),g=new w(u,p);g.position.set(0,.72,.07),g.rotation.x=Math.PI/4,i.add(g)}else{const a=new U(.25,.04,.25),r=new V({color:2600544}),c=new w(a,r);c.position.y=.04,i.add(c);const l=new de(.18,.35,6),h=new V({color:16717636}),d=new w(l,h);d.rotation.x=Math.PI,d.position.y=.25,d.castShadow=!0,i.add(d)}e.plantGroup.add(i),n.status==="ready"?e.plantGroup.scale.set(1,1,1):e.plantGroup.scale.set(.15,.15,.15)}initPKUI(){const t=document.getElementById("btn-pk-match");t&&t.addEventListener("click",s=>{s.stopPropagation(),this.triggerPKMatching()});const e=document.getElementById("btn-cancel-match");e&&e.addEventListener("click",s=>{s.stopPropagation(),this.cancelPKMatching()});const n=document.getElementById("btn-create-room");n&&n.addEventListener("click",s=>{s.stopPropagation(),alert("正在努力创建房间中... 暂无其他联机对手，已为您指派了机器人。"),this.modalMgr.closeAllModals(),this.triggerPKMatching()});const i=document.getElementById("btn-pk-attack");i&&(i.addEventListener("touchstart",s=>{s.preventDefault(),s.stopPropagation(),this.playerPerformAttack()},{passive:!1}),i.addEventListener("click",s=>{s.stopPropagation(),this.playerPerformAttack()})),window.addEventListener("keydown",s=>{s.key.toLowerCase()==="j"&&this.playerPerformAttack()}),window.addEventListener("mousedown",s=>{if(s.button===0&&this.isPKActive){const a=s.target.tagName.toLowerCase();if(a==="button"||a==="a"||s.target.closest(".sidebar-container")||s.target.closest(".modal-card")||s.target.closest(".pk-hud")||s.target.closest(".action-buttons"))return;this.playerPerformAttack()}})}refreshPK(){const t=document.getElementById("pk-points-val"),e=document.getElementById("pk-rank-badge"),n=document.getElementById("pk-win-rate"),i=document.getElementById("pk-total-battles");t&&(t.textContent=this.gameData.pkPoints);const s=this.gameData.pkPoints;let a="🥉 皇家青铜";s>=1200&&s<1500&&(a="🥈 璀璨白银"),s>=1500&&s<1800&&(a="🥇 荣耀黄金"),s>=1800&&(a="👑 傲世战神"),e&&(e.textContent=a);const r=this.gameData.pkWins+this.gameData.pkLoses;if(i&&(i.textContent=r),n){const l=r>0?Math.floor(this.gameData.pkWins/r*100):0;n.textContent=`${l}%`}const c=document.getElementById("room-list");c&&(c.innerHTML=`
        <div class="room-card">
          <span>🎮 浮空挑战赛房 #102</span>
          <span style="color: #2ecc71;">在线匹配中...</span>
        </div>
        <div class="room-card">
          <span>🤖 人机搏击训练室 #001</span>
          <span style="color: var(--primary);">常驻训练</span>
        </div>
      `)}triggerPKMatching(){const t=document.getElementById("radar-overlay");if(!t)return;t.style.display="flex",this.modalMgr.closeAllModals(),this.radarTimerVal=0;const e=document.getElementById("radar-timer");e&&(e.textContent="0"),this.matchingInterval=setInterval(()=>{this.radarTimerVal++,e&&(e.textContent=this.radarTimerVal),this.radarTimerVal>=3&&(this.cancelPKMatching(),this.startPKMatch(!0))},1e3)}cancelPKMatching(){this.matchingInterval&&(clearInterval(this.matchingInterval),this.matchingInterval=null);const t=document.getElementById("radar-overlay");t&&(t.style.display="none")}startPKMatch(t=!0){if(this.currentMap!=="pk_arena"){this.switchMap("pk_arena");return}(this.isHomeBuildActive||document.getElementById("home-edit-hud")&&document.getElementById("home-edit-hud").style.display==="flex")&&this.exitHomeEditMode(!1),this.isPKActive=!0,this.pkOpponentType=t?"robot":"player",(!this.pkArenaColliders||this.pkArenaColliders.length===0)&&this.buildPKPlatform(),this.player&&(this.player.colliders=this.pkArenaColliders||[]),this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!1),this.interactMgr.generator={interactables:[]},document.getElementById("pk-hud").style.display="flex",this.playerHP=100,this.opponentHP=100,this.updatePKHPUI(),this.playerEquippedWeapon=null,this.playerWeapon3D&&(this.player.group.remove(this.playerWeapon3D),this.playerWeapon3D=null),this.activeBombs=[],this.activeExplosions=[],this.bombCooldownActive=!1;const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");e&&(e.style.display="none");const n=document.getElementById("pk-debug-info");if(n&&(n.style.display="block",n.textContent="准备战斗，请先走向擂台周边的武器架拾取武器..."),t){this.opponent3D&&(this.pkArenaGroup.remove(this.opponent3D),this.opponent3D=null);const i=new ot,s=new w(new U(.4,.4,.4),new V({color:15158332}));s.position.y=1.35,i.add(s);const a=new w(new U(.5,.7,.3),new V({color:2899536}));a.position.y=.8,i.add(a);const r=new K(.08,.08,.45,8),c=new w(r,new V({color:3426654}));c.position.set(-.16,.225,0),i.add(c);const l=c.clone();l.position.x=.16,i.add(l),i.position.set(5.5,.6,0),this.pkArenaGroup.add(i),this.opponent3D=i,this.opponentVelocity=new L(0,0,0),this.opponentIsGrounded=!0,this.opponentEquippedWeapon="sword";const h=this.createSword3D();h.position.set(.35,.8,.1),h.rotation.x=Math.PI/2,this.opponent3D.add(h),this.opponentWeapon3D=h}}updatePKHPUI(){const t=document.getElementById("pk-hud-p1-hp"),e=document.getElementById("pk-hud-p2-hp"),n=document.getElementById("pk-hud-p1-hp-text"),i=document.getElementById("pk-hud-p2-hp-text");t&&(t.style.width=`${this.playerHP}%`),e&&(e.style.width=`${this.opponentHP}%`),n&&(n.textContent=`${this.playerHP} / 100`),i&&(i.textContent=`${this.opponentHP} / 100`)}playDamageBubble(t,e,n=!1){const i=document.createElement("div");i.className="damage-bubble",n?(i.style.color="#ff1744",i.textContent=`-${e} HP`):(i.style.color="#ffeb3b",i.textContent=`-${e}`),document.body.appendChild(i),(()=>{if(!this.camera||!i.parentElement)return;const a=t.clone().add(new L(0,n?1:1.3,0));a.project(this.camera);const r=(a.x*.5+.5)*window.innerWidth,c=(-(a.y*.5)+.5)*window.innerHeight;i.style.left=`${r}px`,i.style.top=`${c}px`})(),setTimeout(()=>{i.classList.add("fade-up")},30),setTimeout(()=>{i.remove()},750)}showScreenFlash(){let t=document.getElementById("player-hurt-flash");t||(t=document.createElement("div"),t.id="player-hurt-flash",document.body.appendChild(t)),t.style.opacity="1",setTimeout(()=>{t.style.opacity="0"},120)}playerPerformAttack(){if(!(!this.isPKActive||this.playerHP<=0||!this.playerEquippedWeapon))if(this.playerEquippedWeapon==="bomb"){if(this.bombCooldownActive){if(this.playCustomSound(150,.1,"sine",.1),window.showMockToast){let t=document.querySelector(".mock-toast");t&&t.remove();const e=document.createElement("div");e.className="mock-toast",e.textContent="炸弹正在冷却中！💣",document.body.appendChild(e),setTimeout(()=>e.classList.add("show"),50),setTimeout(()=>{e.classList.remove("show"),setTimeout(()=>e.remove(),300)},1200)}return}this.triggerBombCooldown(),this.throwBomb()}else this.playerWeapon3D&&(this.playerWeapon3D.rotation.z=-Math.PI/2,setTimeout(()=>{this.playerWeapon3D&&(this.playerWeapon3D.rotation.z=0)},150)),this.playCustomSound(260,.1,"triangle",.15),this.performMeleeAttack()}performMeleeAttack(){const t=this.player.position,e=this.opponent3D.position,n=t.x-e.x,i=t.z-e.z,s=Math.sqrt(n*n+i*i);if(console.log(`[PK Damage Check] Player: (${t.x.toFixed(2)}, ${t.z.toFixed(2)}), Robot: (${e.x.toFixed(2)}, ${e.z.toFixed(2)}), Plane Distance: ${s.toFixed(2)}`),s<=4.5){let a=20,r=1.8;this.playerEquippedWeapon==="sword"?(a=20,r=2):this.playerEquippedWeapon==="hammer"&&(a=10,r=7.5),this.opponentHP=Math.max(0,this.opponentHP-a),this.updatePKHPUI(),this.playDamageBubble(e,a,!1),this.opponent3D&&(this.opponent3D.traverse(l=>{l.isMesh&&l.material&&(l.userData.origColor===void 0&&(l.userData.origColor=l.material.color.getHex()),l.material.color.setHex(16724787))}),setTimeout(()=>{this.opponent3D&&this.opponent3D.traverse(l=>{l.isMesh&&l.material&&l.userData.origColor!==void 0&&l.material.color.setHex(l.userData.origColor)})},150));const c=new L().subVectors(e,t).normalize();c.y=.4,this.opponentVelocity.addScaledVector(c,r*2.8),this.playCustomSound(120,.15,"sawtooth",.1),this.opponentHP<=0&&this.endPKBattle(!0)}else{console.log(`[PK Damage Check] MISS - Distance ${s.toFixed(2)}m is greater than 4.5m`);const a=document.getElementById("pk-debug-info");if(a){const r=document.createElement("span");r.style.color="#ff5722",r.style.fontWeight="bold",r.style.marginLeft="10px",r.textContent="[MISS - 距离过远]",a.appendChild(r),setTimeout(()=>r.remove(),1200)}}}triggerBombCooldown(){this.bombCooldownActive=!0;let t=5;const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack"),n=()=>{e&&(e.disabled=!0,e.style.opacity="0.5",e.innerHTML=`<span style="font-size: 1.1rem; font-weight: bold; color: #ffeb3b; font-family: system-ui; display: flex; align-items: center; justify-content: center;">💣 ${t}s</span>`)};n();const i=setInterval(()=>{if(this.playerEquippedWeapon!=="bomb"){clearInterval(i),this.bombCooldownActive=!1,e&&(e.disabled=!1,e.style.opacity="1");return}t--,t<=0?(clearInterval(i),this.bombCooldownActive=!1,this.playerEquippedWeapon==="bomb"&&this.playerWeapon3D&&(this.playerWeapon3D.visible=!0),e&&(e.disabled=!1,e.style.opacity="1",e.innerHTML=`
<svg style="display: flex;" class="lucide lucide-bomb" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="11" cy="13" r="9" />
  <path d="m19.5 4.5-3.5 3.5" />
  <path d="m21 3-2.5 2.5" />
  <path d="M19 8.5c.5-.5 1-1.5.5-2.5-.5-.5-1.5 0-2 .5" />
</svg>`)):n()},1e3)}throwBomb(){if(!this.player)return;this.playCustomSound(350,.1,"sine",.1),this.playerWeapon3D&&(this.playerWeapon3D.visible=!1);const t=new L(0,0,1).applyQuaternion(this.player.group.quaternion).normalize(),e=this.createBomb3D(),n=this.player.position.clone().add(t.clone().multiplyScalar(.5));n.y+=1,e.position.copy(n),this.scene.add(e);const s=t.clone().multiplyScalar(9);s.y=4;const a={mesh:e,velocity:s,position:n,timeElapsed:0,maxLifetime:1.5};this.activeBombs||(this.activeBombs=[]),this.activeBombs.push(a)}updateActiveBombs(t){if(!this.activeBombs||this.activeBombs.length===0)return;const e=9.8,n=.6;for(let i=this.activeBombs.length-1;i>=0;i--){const s=this.activeBombs[i];s.timeElapsed+=t,s.velocity.y-=e*t,s.position.addScaledVector(s.velocity,t),s.mesh.position.copy(s.position),s.mesh.rotation.x+=.05,s.mesh.rotation.y+=.05;let a=!1;if(s.position.y<=n&&Math.sqrt(s.position.x*s.position.x+s.position.z*s.position.z)<8&&(s.position.y=n,a=!0),this.opponent3D&&!a){const r=this.opponent3D.position;s.position.distanceTo(r)<.8&&(a=!0)}s.timeElapsed>=s.maxLifetime&&(a=!0),a&&(this.explodeBomb(s.position),this.scene.remove(s.mesh),this.activeBombs.splice(i,1))}}explodeBomb(t){if(this.playCustomSound(180,.35,"sawtooth",.25),setTimeout(()=>{this.playCustomSound(60,.2,"sine",.3)},50),this.createExplosionEffects(t),this.opponent3D&&this.isPKActive){const e=this.opponent3D.position;if(t.distanceTo(e)<=3.5){const a=e.clone().sub(t);a.y=0,a.normalize(),this.opponentVelocity.addScaledVector(a,6),this.opponentVelocity.y=3.5,this.opponentIsGrounded=!1,this.opponentHP=Math.max(0,this.opponentHP-50),this.updatePKHPUI(),this.playDamageBubble(e,50,!1),this.opponent3D.traverse(c=>{c.isMesh&&c.material&&(c.userData.origColor===void 0&&(c.userData.origColor=c.material.color.getHex()),c.material.color.setHex(16724787))}),setTimeout(()=>{this.opponent3D&&this.opponent3D.traverse(c=>{c.isMesh&&c.material&&c.userData.origColor!==void 0&&c.material.color.setHex(c.userData.origColor)})},150),this.opponentHP<=0&&this.endPKBattle(!0)}}}createExplosionEffects(t){const e=new Rt(.2,8,8),n=new _t({color:16754470,transparent:!0,opacity:.9,depthWrite:!1}),i=new w(e,n);i.position.copy(t),this.scene.add(i);const s={mesh:i,type:"ball",scaleSpeed:9,opacitySpeed:2.2,scale:1,opacity:.9};this.activeExplosions||(this.activeExplosions=[]),this.activeExplosions.push(s);const a=12,r=new U(.08,.08,.08),c=[16727296,16761095,7697781];for(let l=0;l<a;l++){const h=c[Math.floor(Math.random()*c.length)],d=new V({color:h,transparent:!0,opacity:.9,flatShading:!0}),u=new w(r,d);u.position.copy(t);const p=Math.random()*Math.PI*2,g=1.5+Math.random()*3.5,y=new L(Math.cos(p)*g,2.5+Math.random()*3,Math.sin(p)*g);this.scene.add(u);const m={mesh:u,type:"particle",velocity:y,opacity:.9,rotationSpeed:new L(Math.random()*10,Math.random()*10,Math.random()*10)};this.activeExplosions.push(m)}}updateExplosionEffects(t){if(!this.activeExplosions||this.activeExplosions.length===0)return;const e=9.8;for(let n=this.activeExplosions.length-1;n>=0;n--){const i=this.activeExplosions[n];i.type==="ball"?(i.scale+=i.scaleSpeed*t,i.opacity-=i.opacitySpeed*t,i.mesh.scale.set(i.scale,i.scale,i.scale),i.mesh.material.opacity=Math.max(0,i.opacity),i.opacity<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.activeExplosions.splice(n,1))):i.type==="particle"&&(i.velocity.y-=e*t,i.mesh.position.addScaledVector(i.velocity,t),i.mesh.rotation.x+=i.rotationSpeed.x*t,i.mesh.rotation.y+=i.rotationSpeed.y*t,i.mesh.rotation.z+=i.rotationSpeed.z*t,i.opacity-=1.8*t,i.mesh.material.opacity=Math.max(0,i.opacity),i.opacity<=0&&(this.scene.remove(i.mesh),i.mesh.geometry.dispose(),i.mesh.material.dispose(),this.activeExplosions.splice(n,1)))}}endPKBattle(t=!0){if(!this.isPKActive)return;this.isPKActive=!1,this.player&&(this.player.position.set(0,.6+.1,-6),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position)),this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!0);const e=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");e&&(e.style.display="none");let n=t?20:-10;this.gameData.pkPoints+n<0&&(n=-this.gameData.pkPoints),this.gameData.pkPoints+=n,t?this.gameData.pkWins++:this.gameData.pkLoses++,this.saveGameData();const i=t?"🎉 荣耀胜利！":"💀 惜败对手",s=t?"成功击败挑战者，天梯积分 +20！":"不幸败于挑战者，天梯积分 -10。",a=document.createElement("div");a.style.position="fixed",a.style.inset="0",a.style.zIndex="500",a.style.background="rgba(15,17,21,0.85)",a.style.backdropFilter="blur(20px)",a.style.webkitBackdropFilter="blur(20px)",a.style.display="flex",a.style.alignItems="center",a.style.justifyContent="center",a.style.color="white",a.innerHTML=`
      <div class="modal-card settle-card">
        <h2 class="settle-title" style="color: ${t?"#d97706":"#e74c3c"};">${i}</h2>
        <p class="settle-desc">${s}</p>
        <div class="settle-score-box">
          <span>当前天梯积分: <strong class="settle-score-val">${this.gameData.pkPoints}</strong></span>
        </div>
        <div class="settle-buttons">
          <button class="hud-btn settle-btn-action" id="btn-settle-retry">继续挑战 ⚔️</button>
          <button class="hud-btn settle-btn-secondary" id="btn-settle-close">返回群岛 🏝️</button>
        </div>
      </div>
    `,document.body.appendChild(a),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalOpened=="function"&&window.parent.appShell.onModalOpened("pk_settle");const r=a.querySelector("#btn-settle-close");r&&r.addEventListener("click",()=>{a.remove(),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed("pk_settle"),this.switchMap("island"),document.getElementById("pk-hud").style.display="none",document.getElementById("pk-debug-info")&&(document.getElementById("pk-debug-info").style.display="none")});const c=a.querySelector("#btn-settle-retry");c&&c.addEventListener("click",()=>{a.remove(),window.parent&&window.parent.appShell&&typeof window.parent.appShell.onModalClosed=="function"&&window.parent.appShell.onModalClosed("pk_settle"),this.startPKMatch(!0)})}initMapUI(){document.querySelectorAll("#modal-map .map-node").forEach(e=>{e.addEventListener("click",()=>{const n=e.getAttribute("data-map");n&&(this.playCustomSound(440,.08,"sine",.15),setTimeout(()=>{this.playCustomSound(554.37,.08,"sine",.15)},80),this.modalMgr&&this.modalMgr.closeModal("map"),this.switchMap(n))})})}initBagUI(){const t=document.querySelectorAll("#modal-bag .bag-tabactive");t.forEach(e=>{e.addEventListener("click",n=>{t.forEach(i=>i.classList.remove("active")),e.classList.add("active"),this.refreshBag(e.getAttribute("data-tab"))})})}refreshBag(t="seed"){this.updateBaseUI();const e=document.getElementById("bag-grid"),n=document.getElementById("bag-item-detail");if(!e||!n)return;e.innerHTML="";const i=this.gameData.backpack.filter(s=>s.type===t);for(let s=0;s<20;s++){const a=document.createElement("div");a.className="bag-item-box";const r=i[s];if(r&&r.count>0){const c=`q-${r.quality||"white"}`;a.classList.add(c);let l="📦";r.id.includes("seed")?l="🌱":r.id==="sunflower_crop"?l="🌻":r.id==="strawberry_crop"?l="🍓":r.id.includes("painting")?l="🖼️":r.id.includes("tree")?l="🎄":r.id.includes("sofa")?l="🛋️":r.id.includes("swing")&&(l="🎪"),a.innerHTML=`
          <span style="font-size: 1.8rem;">${l}</span>
          <span class="bag-item-count">${r.count}</span>
        `,a.addEventListener("click",()=>{document.querySelectorAll(".bag-item-box.active").forEach(h=>h.classList.remove("active")),a.classList.add("active"),this.showBagItemDetail(r)})}else a.innerHTML="";e.appendChild(a)}n.querySelector(".item-detail-empty").style.display="flex",n.querySelector(".item-detail-content").style.display="none"}showBagItemDetail(t){const e=document.getElementById("bag-item-detail"),n=e.querySelector(".item-detail-empty"),i=e.querySelector(".item-detail-content");n.style.display="none",i.style.display="flex";let s="📦";t.id.includes("seed")?s="🌱":t.id==="sunflower_crop"?s="🌻":t.id==="strawberry_crop"?s="🍓":t.id.includes("painting")?s="🖼️":t.id.includes("tree")?s="🎄":t.id.includes("sofa")?s="🛋️":t.id.includes("swing")&&(s="🎪");const a={white:"普普通通",green:"翠绿新生",blue:"蔚蓝奇迹",purple:"秘境紫光",gold:"傲视至尊"},r=`bq-${t.quality||"white"}`,c=a[t.quality||"white"];let l="出售",h=!1,d=10;t.id==="sunflower_crop"?(d=20,h=!1):t.id==="strawberry_crop"?(d=45,h=!1):t.id.includes("seed")?(h=!0,l="去农田种植"):(h=!0,l="摆放家具");const p=t.count>1?`
      <div class="bag-sell-range-container" style="display: flex; flex-direction: column; gap: 4px; width: 100%; margin-bottom: 6px; padding: 0 10px; box-sizing: border-box;">
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.72rem; color: var(--text-muted);">
          <span>选择出售数量</span>
          <span class="range-val" style="font-weight: bold; color: var(--primary);"><strong id="sell-count-label">1</strong> / ${t.count}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; width: 100%;">
          <button class="bag-range-btn" id="btn-range-minus">-</button>
          <input type="range" id="sell-count-range" min="1" max="${t.count}" value="1" style="flex: 1; height: 6px; background: rgba(0,0,0,0.1); border-radius: 4px; outline: none; cursor: pointer; accent-color: var(--primary);" />
          <button class="bag-range-btn" id="btn-range-plus">+</button>
        </div>
      </div>
    `:"";i.innerHTML=`
      <div style="font-size: 3.5rem; margin-top: 20px;">${s}</div>
      <h3 style="font-size: 1.1rem; font-weight: bold; color: white; margin-top: 10px;">${t.name}</h3>
      <span class="bag-right-quality-badge ${r}">${c}</span>
      <p style="font-size: 0.75rem; color: var(--text-muted); line-height: 1.4; padding: 0 10px; margin-top: 12px; flex-grow: 1;">${t.desc}</p>
      
      <div style="width: 100%; display: flex; flex-direction: column; gap: 10px; margin-top: auto;">
        ${p}
        ${h?`<button class="hud-btn" id="btn-bag-use" style="width: 100%; padding: 8px 0; background: rgba(100, 255, 100, 0.15); border-color: rgba(100,255,100,0.3); color: #fff;">${l}</button>`:""}
        <button class="hud-btn" id="btn-bag-sell" style="width: 100%; padding: 8px 0; background: rgba(255, 140, 105, 0.1); border-color: rgba(255, 140, 105, 0.3); color: #fff;">出售 (获得 ${d}金币)</button>
      </div>
    `;const g=i.querySelector("#btn-bag-sell"),y=i.querySelector("#sell-count-range"),m=i.querySelector("#sell-count-label"),f=i.querySelector("#btn-range-minus"),_=i.querySelector("#btn-range-plus");let x=1;const M=A=>{x=Math.max(1,Math.min(t.count,A)),y&&(y.value=x),m&&(m.textContent=x),g&&(g.textContent=`出售 (获得 ${x*d}金币)`)};y&&y.addEventListener("input",A=>{M(parseInt(A.target.value)||1)}),f&&f.addEventListener("click",A=>{A.stopPropagation(),M(x-1)}),_&&_.addEventListener("click",A=>{A.stopPropagation(),M(x+1)}),g&&g.addEventListener("click",A=>{A.stopPropagation(),this.sellBagItem(t.id,d,x,A.clientX,A.clientY)});const R=i.querySelector("#btn-bag-use");R&&R.addEventListener("click",A=>{A.stopPropagation(),this.modalMgr.closeAllModals(),t.id.includes("seed")?this.switchMap("farm",new L(0,.7,-8)):this.switchMap("house",null,"home")})}sellBagItem(t,e,n,i,s){const a=this.gameData.backpack.find(c=>c.id===t);if(!a||a.count<n)return;a.count-=n;const r=e*n;this.gameData.coins+=r,this.saveGameData(),this.showCoinFloatText(r,i,s),this.refreshBag(document.querySelector("#modal-bag .bag-tabactive.active").getAttribute("data-tab"))}initHomeUI(){const t=document.getElementById("btn-enter-edit-mode");t&&t.addEventListener("click",s=>{s.stopPropagation(),this.modalMgr.closeAllModals(),this.enterHomeEditMode()});const e=document.getElementById("btn-edit-cancel");e&&e.addEventListener("click",s=>{s.stopPropagation(),this.exitHomeEditMode(!1)});const n=document.getElementById("btn-edit-save");n&&n.addEventListener("click",s=>{s.stopPropagation(),this.exitHomeEditMode(!0)});const i=document.getElementById("btn-edit-rotate");i&&i.addEventListener("click",s=>{s.stopPropagation(),this.rotateEditFurniture()}),window.addEventListener("keydown",s=>{s.key.toLowerCase()==="r"&&this.rotateEditFurniture()})}initExitChoicesUI(){document.querySelectorAll(".exit-choice-btn").forEach(e=>{e.addEventListener("click",n=>{n.stopPropagation();const i=e.getAttribute("data-target");this.modalMgr.closeModal("exit"),i==="island"?this.switchMap("island"):i==="farm"?this.switchMap("farm"):i==="pk"&&this.switchMap("pk_arena")})})}refreshHome(){const t=document.getElementById("furniture-shop-grid");if(!t)return;t.innerHTML="",[{id:"painting_1",type:"painting",name:"浮空岛日落挂画",price:50,emoji:"🖼️"},{id:"tree_1",type:"christmas_tree",name:"闪烁圣诞树",price:100,emoji:"🎄"},{id:"sofa_1",type:"rabbit_sofa",name:"粉嫩兔子沙发",price:150,emoji:"🛋️"},{id:"swing_1",type:"swing_chair",name:"室内网兜秋千",price:200,emoji:"🎪"}].forEach(n=>{const i=document.createElement("div");i.className="furniture-shop-card";const s=this.gameData.ownedFurnitures.includes(n.id);let a="";s?a=`<button class="hud-btn" data-action="place" data-id="${n.id}" style="width: 100%; font-size: 0.75rem; background: rgba(100, 255, 100, 0.15); border-color: rgba(100,255,100,0.3);">摆放家具</button>`:a=`<button class="hud-btn" data-action="buy" data-id="${n.id}" style="width: 100%; font-size: 0.75rem;">购买 (${n.price}金币)</button>`,i.innerHTML=`
        <div style="font-size: 2.2rem;">${n.emoji}</div>
        <div style="font-size: 0.8rem; font-weight: bold; color: #fff;">${n.name}</div>
        ${a}
      `;const r=i.querySelector('button[data-action="buy"]');r&&r.addEventListener("click",l=>{l.stopPropagation(),this.buyFurniture(n,l.clientX,l.clientY)});const c=i.querySelector('button[data-action="place"]');c&&c.addEventListener("click",l=>{l.stopPropagation(),this.modalMgr.closeAllModals(),this.startPlacingFurniture(n.type,n.id)}),t.appendChild(i)})}buyFurniture(t,e,n){if(this.gameData.coins<t.price){alert("金币不足，无法购买该家具！");return}this.gameData.coins-=t.price,this.gameData.ownedFurnitures.push(t.id),this.gameData.backpack.push({id:t.id,name:t.name,type:"decor",count:1,quality:"purple",desc:"购买于家园工坊的精美家具模型。进入家园编辑模式即可随意定位摆放它！"}),this.saveGameData(),this.refreshHome(),this.showCoinFloatText(-t.price,e,n)}enterHomeEditMode(){if(this.currentMap!=="house"){this.switchMap("house",null,null,"edit");return}this.isHomeBuildActive=!0,this.player.controlsLocked=!0,this.player.resetInputs(),this.cameraSavedState={distance:this.player.cameraDistance,angleH:this.player.cameraAngleH,angleV:this.player.cameraAngleV,position:this.camera.position.clone()},this.player.cameraDistance=8.5,this.player.cameraAngleV=Math.PI/2.1,this.player.cameraAngleH=Math.PI,this.editGrid=new iw(12,24,5227511,4473924),this.editGrid.position.set(0,.13,5),this.scene.add(this.editGrid),document.getElementById("home-edit-hud").style.display="flex"}startPlacingFurniture(t,e){this.enterHomeEditMode(),this.pendingFurnitureId=e,this.pendingFurnitureType=t,this.editPreviewGroup=this.createFurnitureModel(t),this.editPreviewGroup.position.set(0,.12,5),this.editPreviewGroup.traverse(n=>{n.isMesh&&(n.material=n.material.clone(),n.material.transparent=!0,n.material.opacity=.55,n.material.color.setHex(5227511))}),this.scene.add(this.editPreviewGroup),this.editFurnitureRotationY=0}rotateEditFurniture(){!this.isHomeBuildActive||!this.editPreviewGroup||(this.editFurnitureRotationY+=Math.PI/2,this.editPreviewGroup.rotation.y=this.editFurnitureRotationY,this.playCustomSound(400,.08,"sine",.05))}exitHomeEditMode(t=!0){if(this.isHomeBuildActive){if(this.isHomeBuildActive=!1,this.cameraSavedState&&(this.player.cameraDistance=this.cameraSavedState.distance,this.player.cameraAngleH=this.cameraSavedState.angleH,this.player.cameraAngleV=this.cameraSavedState.angleV,this.player.controlsLocked=!1),this.editGrid&&(this.scene.remove(this.editGrid),this.editGrid=null),t&&this.editPreviewGroup&&this.pendingFurnitureId){const e=this.editPreviewGroup.position;this.gameData.homeFurnitures.push({id:this.pendingFurnitureId+"_"+Date.now(),type:this.pendingFurnitureType,x:e.x,y:e.y,z:e.z,ry:this.editFurnitureRotationY});const n=this.gameData.backpack.find(i=>i.id===this.pendingFurnitureId);n&&(n.count--,n.count<=0&&(this.gameData.backpack=this.gameData.backpack.filter(i=>i.id!==this.pendingFurnitureId))),this.saveGameData(),this.renderHomeFurnitures(),this.playCustomSound(494,.2,"sine",.1)}this.editPreviewGroup&&(this.scene.remove(this.editPreviewGroup),this.editPreviewGroup=null),this.pendingFurnitureId=null,this.pendingFurnitureType=null,document.getElementById("home-edit-hud").style.display="none"}}renderHomeFurnitures(){this.houseGen&&(this.houseGen.furnituresGroup||(this.houseGen.furnituresGroup=new ot,this.houseGen.group.add(this.houseGen.furnituresGroup)),this.houseGen.furnituresGroup.clear(),this.gameData.homeFurnitures.forEach(t=>{const e=this.createFurnitureModel(t.type);e.position.set(t.x,t.y,t.z),e.rotation.y=t.ry,this.houseGen.furnituresGroup.add(e)}))}updateGameSystemsFrame(t,e){if(this.updateActivePlotForRadialMenu(),this.updateFarmPlotsFrame(),this.updatePKBattleFrame(t),this.updateHomeBuildFrame(),this.updatePKHallAnimations(t,e),this.currentMap==="farm"&&this.player&&this.player.position.y<-3.5&&(this.player.position.set(0,.6+.1,-8),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),window.showMockToast)){let n=document.querySelector(".mock-toast");n&&n.remove();const i=document.createElement("div");i.className="mock-toast",i.textContent="小心！不要掉入农场外的浮空深渊哦 ☁️",document.body.appendChild(i),setTimeout(()=>i.classList.add("show"),50),setTimeout(()=>{i.classList.remove("show"),setTimeout(()=>i.remove(),300)},2e3)}}updatePKHallAnimations(t,e){if(this.currentMap==="pk_arena"&&(this.pkCrystalMesh&&this.pkCrystalMesh.visible&&(this.pkCrystalMesh.rotation.y+=.015,this.pkCrystalMesh.position.y=1.35+Math.sin(e*.002)*.12),this.swordPreview&&(this.swordPreview.rotation.y+=.015,this.swordPreview.position.y=1.45+Math.sin(e*.0025)*.06),this.hammerPreview&&(this.hammerPreview.rotation.y+=.015,this.hammerPreview.position.y=1.45+Math.cos(e*.0025)*.06),this.bombPreview&&(this.bombPreview.rotation.y+=.015,this.bombPreview.position.y=1.45+Math.sin(e*.0025+1)*.06),!this.isPKActive&&(this.pkCrystalMesh&&(this.pkCrystalMesh.visible=!0),this.player&&this.player.position.y<-3.5&&(this.player.position.set(0,.6+.1,-6),this.player.velocity.set(0,0,0),this.player.group.position.copy(this.player.position),window.showMockToast)))){let n=document.querySelector(".mock-toast");n&&n.remove();const i=document.createElement("div");i.className="mock-toast",i.textContent="小心！不要跌落入云海深渊哦 ☁️",document.body.appendChild(i),setTimeout(()=>i.classList.add("show"),50),setTimeout(()=>{i.classList.remove("show"),setTimeout(()=>i.remove(),300)},2200)}}updateFarmPlotsFrame(){const t=document.getElementById("farm-bubbles-container");if(!t)return;const e=this.farmPlots3D;if(!e||!this.gameData||this.currentMap!=="farm"){t.innerHTML="";return}this.gameData.farmPlots.forEach((n,i)=>{const s=e[i];if(s){if(n.status!=="empty"&&s.plantGroup.children.length===0&&this.recreateCrop3D(i),n.status==="growing"){const a=n.seedId==="sunflower_seed"?30:60,r=Math.floor((Date.now()-n.plantTime)/1e3);if(r>=a)n.status="ready",this.saveGameData(),this.refreshFarm(),this.recreateCrop3D(i);else{const l=.15+r/a*.85;s.plantGroup.scale.set(l,l,l)}}if(n.status!=="empty"&&n.seedId){let a=document.getElementById(`crop-bubble-${i}`);a||(a=document.createElement("div"),a.id=`crop-bubble-${i}`,a.className="farm-crop-bubble",t.appendChild(a));const r=n.seedId==="sunflower_seed"?30:60,c=Math.floor((Date.now()-n.plantTime)/1e3),l=Math.max(0,r-c);if(n.status==="ready")a.innerHTML="🌾 可收割",a.style.background="linear-gradient(135deg, #27ae60, #1e824c)",a.style.borderColor="rgba(255,255,255,0.3)";else{const p=n.seedId==="sunflower_seed"?"🌻":"🍓";a.innerHTML=`${p} ⏳ ${l}s`,a.style.background="rgba(15,17,21,0.85)",a.style.borderColor="rgba(255,255,255,0.12)"}const h=new L(s.x,1.3,s.z);h.project(this.camera);const d=(h.x*.5+.5)*window.innerWidth,u=(-(h.y*.5)+.5)*window.innerHeight;a.style.left=`${d}px`,a.style.top=`${u}px`,a.style.opacity="1"}else{const a=document.getElementById(`crop-bubble-${i}`);a&&a.remove()}}})}updatePKBattleFrame(t){if(this.updateActiveBombs(t),this.updateExplosionEffects(t),!this.isPKActive||!this.opponent3D)return;if(this.player.position.y<-3.5){this.endPKBattle(!1);return}if(this.opponent3D.position.y<-3.5){this.endPKBattle(!0);return}const e=this.opponent3D,n=this.player.position;if(this.opponentIsGrounded||(this.opponentVelocity.y-=9.8*t),e.position.addScaledVector(this.opponentVelocity,t),this.opponentVelocity.x*=.88,this.opponentVelocity.z*=.88,e.position.y<=.6?Math.sqrt(e.position.x*e.position.x+e.position.z*e.position.z)<8?(e.position.y=.6,this.opponentVelocity.y=0,this.opponentIsGrounded=!0):this.opponentIsGrounded=!1:this.opponentIsGrounded=!1,this.opponentIsGrounded&&this.playerHP>0){const r=e.position.distanceTo(n),c=n.x-e.position.x,l=n.z-e.position.z,h=Math.atan2(c,l);e.rotation.y=h,r>1.8?e.translateZ(2.4*t):Math.random()<.018&&this.opponentPerformAttack()}const i=document.getElementById("pk-debug-info");i&&(this.playerEquippedWeapon?i.style.display="none":(i.style.display="block",i.innerHTML='<span style="font-weight: bold; color: #ffeb3b; animation: settleBlink 1.2s infinite;">⚠️ 尚未装备武器！请走向擂台周边的武器架拾取武器 ⚔️</span>'));const s=this.player.position;[{x:-7.5,z:0,weapon:"sword"},{x:7.5,z:0,weapon:"hammer"},{x:0,z:6.8,weapon:"bomb"}].forEach(r=>{if(s.distanceTo(new L(r.x,.6,r.z))<1.6&&this.playerEquippedWeapon!==r.weapon){const l=r.weapon;this.playerEquippedWeapon=l;const h=document.getElementById("btn-pk-attack")||window.parent&&window.parent.document.getElementById("btn-pk-attack");if(h){h.style.display="flex";const u={sword:`
<svg style="display: flex;" class="lucide lucide-swords" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5" />
  <line x1="13" x2="19" y1="19" y2="13" />
  <line x1="16" x2="20" y1="16" y2="20" />
  <line x1="19" x2="21" y1="21" y2="19" />
  <polyline points="14.5 6.5 18 3 21 3 21 6 17.5 9.5" />
  <line x1="5" x2="9" y1="14" y2="18" />
  <line x1="7" x2="4" y1="17" y2="20" />
  <line x1="3" x2="5" y1="19" y2="21" />
</svg>`,hammer:`
<svg style="display: flex;" class="lucide lucide-hammer" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="m15 5 4 4" />
  <path d="M21.5 12H16c-.5 0-1-.5-1-1V4.5L9 9.5c-.5.5-.5 1.5 0 2l11 11c.5.5 1.5.5 2 0z" />
  <path d="m2.1 21.9 10.3-10.3" />
</svg>`,bomb:`
<svg style="display: flex;" class="lucide lucide-bomb" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="11" cy="13" r="9" />
  <path d="m19.5 4.5-3.5 3.5" />
  <path d="m21 3-2.5 2.5" />
  <path d="M19 8.5c.5-.5 1-1.5.5-2.5-.5-.5-1.5 0-2 .5" />
</svg>`};h.innerHTML=u[l]||u.sword}this.playerWeapon3D&&this.player.group.remove(this.playerWeapon3D);let d;if(l==="sword"?d=this.createSword3D():l==="hammer"?d=this.createHammer3D():d=this.createBomb3D(),d.position.set(.32,.8,.1),d.rotation.x=Math.PI/2,this.player.group.add(d),this.playerWeapon3D=d,this.playCustomSound(600,.15,"sine",.1),window.showMockToast){let u=document.querySelector(".mock-toast");u&&u.remove();const p=document.createElement("div");p.className="mock-toast";const g={sword:"长剑 ⚔️",hammer:"大锤 🔨",bomb:"炸弹 💣"};p.textContent=`已装备武器：${g[l]}！`,document.body.appendChild(p),setTimeout(()=>p.classList.add("show"),50),setTimeout(()=>{p.classList.remove("show"),setTimeout(()=>p.remove(),300)},1800)}}})}opponentPerformAttack(){if(this.opponentHP<=0||this.playerHP<=0)return;if(this.opponentWeapon3D&&(this.opponentWeapon3D.rotation.z=-Math.PI/2,setTimeout(()=>{this.opponentWeapon3D&&(this.opponentWeapon3D.rotation.z=0)},150)),this.playCustomSound(220,.1,"sawtooth",.1),this.opponent3D.position.distanceTo(this.player.position)<=2.2){this.playerHP=Math.max(0,this.playerHP-15),this.updatePKHPUI(),this.showScreenFlash(),this.playDamageBubble(this.player.position,15,!0);const n=new L().subVectors(this.player.position,this.opponent3D.position).normalize();n.y=.35,this.player.velocity.addScaledVector(n,4.2),this.playCustomSound(100,.2,"sine",.15),this.playerHP<=0&&this.endPKBattle(!1)}}updateHomeBuildFrame(){if(!this.isHomeBuildActive||!this.editPreviewGroup)return;const t=new dt(0,0),e=new nw;e.setFromCamera(t,this.camera);const n=e.intersectObjects(this.scene.children,!0);let i=null;for(let s=0;s<n.length;s++){const a=n[s];if(a.point&&Math.abs(a.point.y-.12)<.2){i=a.point;break}}if(i){let s=Math.round(i.x*2)/2,a=Math.round(i.z*2)/2;s=Math.max(-4,Math.min(4,s)),a=Math.max(1,Math.min(9,a)),this.editPreviewGroup.position.set(s,.12,a)}}buildFarmPlatform(){this.farmGroup.clear();const t=new K(12,12.5,1.2,32),e=new V({color:5025616,flatShading:!0}),n=new w(t,e);n.position.y=0,n.receiveShadow=!0,n.castShadow=!0,this.farmGroup.add(n);const i=new K(12.5,12,1.5,32),s=new V({color:6111287,flatShading:!0}),a=new w(i,s);a.position.y=-1.35,this.farmGroup.add(a),this.farmPlots3D=[];const r=new V({color:4073251,flatShading:!0}),c=new V({color:7951688,flatShading:!0}),l=[{x:-3.6,z:-2.2},{x:0,z:-2.2},{x:3.6,z:-2.2},{x:-3.6,z:2.2},{x:0,z:2.2},{x:3.6,z:2.2}];l.forEach((y,m)=>{const f=new ot;f.position.set(y.x,.6,y.z);const _=new w(new U(2.4,.02,2.4),r);_.receiveShadow=!0,f.add(_);const x=new w(new U(2.6,.1,.1),c);x.position.set(0,.05,1.25),x.castShadow=!0,f.add(x);const M=x.clone();M.position.z=-1.25,f.add(M);const R=new w(new U(.1,.1,2.4),c);R.position.set(1.25,.05,0),R.castShadow=!0,f.add(R);const A=R.clone();A.position.x=-1.25,f.add(A);const E=new ot;E.position.set(0,0,0),f.add(E),this.farmGroup.add(f),this.farmPlots3D.push({x:y.x,z:y.z,plantGroup:E})});const h=new K(.12,.16,1,6),d=new V({color:5125166}),u=new Is(.6),p=new V({color:1793568,flatShading:!0});[{x:-8,z:-8},{x:8,z:-8},{x:-8,z:8},{x:8,z:8}].forEach(y=>{const m=new ot;m.position.set(y.x,.6,y.z);const f=new w(h,d);f.position.y=.5,f.castShadow=!0,m.add(f);const _=new w(u,p);_.position.y=1.1,_.castShadow=!0,m.add(_),this.farmGroup.add(m)}),this.farmColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:12}],this.farmInteractables=l.map((y,m)=>({id:`farm_plot_${m}`,name:"农田格子",x:y.x,y:.6,z:y.z,triggerRadius:1.8}))}buildPKPlatform(){this.pkArenaGroup.clear();const t=new K(8,8.2,.4,32),e=new V({color:1779781,flatShading:!0,emissive:461593}),n=new w(t,e);n.position.y=.4,n.receiveShadow=!0,n.castShadow=!0,this.pkArenaGroup.add(n);const i=new Vn(8.02,.05,8,48);i.rotateX(Math.PI/2);const s=new _t({color:2733814}),a=new w(i,s);a.position.y=.58,this.pkArenaGroup.add(a);const r=new Vn(8.1,.03,8,48);r.rotateX(Math.PI/2);const c=new _t({color:15684432}),l=new w(r,c);l.position.y=.55,this.pkArenaGroup.add(l);const h=new _t({color:58879,transparent:!0,opacity:.65}),d=new U(3.6,.01,.16),u=new w(d,h);u.position.set(0,.605,0),this.pkArenaGroup.add(u);const p=new U(.16,.01,3.6),g=new w(p,h);g.position.set(0,.605,0),this.pkArenaGroup.add(g);const y=new Vn(.6,.04,4,24);y.rotateX(Math.PI/2);const m=new w(y,h);m.position.set(0,.605,0),this.pkArenaGroup.add(m);const f=new V({color:7901340,flatShading:!0});for(let v=0;v<6;v++){const S=v*Math.PI/3,P=10.5,O=Math.cos(S)*P,j=Math.sin(S)*P,D=new ot;D.position.set(O,.4,j);const F=new K(.5,.6,.4,8),z=new w(F,f);z.position.y=.2,z.castShadow=!0,z.receiveShadow=!0,D.add(z);const Z=new K(.35,.35,3.8,8),Y=new w(Z,f);Y.position.y=2.1,Y.castShadow=!0,Y.receiveShadow=!0,D.add(Y);const q=new K(.5,.4,.3,8),J=new w(q,f);J.position.y=4.15,J.castShadow=!0,D.add(J);const nt=new Qo(.25),ct=new w(nt,new _t({color:v%2===0?2733814:15684432,transparent:!0,opacity:.95}));ct.position.y=4.65,D.add(ct),this.pkArenaGroup.add(D)}const _=new V({color:16777215,flatShading:!0,transparent:!0,opacity:.88});for(let v=0;v<8;v++){const S=v*Math.PI/4+Math.random()*.2,P=21+Math.random()*5,O=Math.cos(S)*P,j=Math.sin(S)*P,D=-2.5-Math.random()*2,F=new ot;F.position.set(O,D,j);const z=3+Math.floor(Math.random()*4);for(let Z=0;Z<z;Z++){const Y=2.5+Math.random()*3.5,q=new Rt(Y,6,6),J=new w(q,_);J.position.set((Math.random()-.5)*Y*1.6,(Math.random()-.5)*Y*.6,(Math.random()-.5)*Y*1.6),F.add(J)}this.pkArenaGroup.add(F)}const x=new V({color:4545124,flatShading:!0});for(let v=0;v<10;v++){const S=Math.random()*Math.PI*2,P=9.5+Math.random()*4,O=Math.cos(S)*P,j=Math.sin(S)*P,D=.2+Math.random()*2.2,F=new Is(.25+Math.random()*.45),z=new w(F,x);z.position.set(O,D,j),z.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),z.castShadow=!0,this.pkArenaGroup.add(z)}const M=new K(.3,.4,.4,8),R=new w(M,f);R.position.set(0,.8,-5),R.castShadow=!0,R.receiveShadow=!0,this.pkArenaGroup.add(R);const A=new Qo(.3),E=new _t({color:58879,transparent:!0,opacity:.88});this.pkCrystalMesh=new w(A,E),this.pkCrystalMesh.scale.set(1,2,1),this.pkCrystalMesh.position.set(0,1.45,-5),this.pkArenaGroup.add(this.pkCrystalMesh);const I=[{x:-7.5,z:0,weapon:"sword"},{x:7.5,z:0,weapon:"hammer"},{x:0,z:6.8,weapon:"bomb"}];this.swordPreview=null,this.hammerPreview=null,this.bombPreview=null,I.forEach(v=>{const S=new ot;S.position.set(v.x,.6,v.z),v.z>0&&(S.rotation.y=Math.PI);const P=new K(.05,.05,1.3,8),O=new V({color:5125166,flatShading:!0}),j=new w(P,O);j.position.set(0,.65,-.4),j.castShadow=!0,S.add(j);const D=new w(P,O);D.position.set(0,.65,.4),D.castShadow=!0,S.add(D);const F=new U(.06,.06,1),z=new w(F,O);z.position.set(0,1.15,0),z.castShadow=!0,S.add(z);const Z=new U(.2,.08,1.1),Y=new w(Z,new V({color:4073251,flatShading:!0}));Y.position.set(0,.04,0),Y.receiveShadow=!0,S.add(Y);let q;v.weapon==="sword"?(q=this.createSword3D(),this.swordPreview=q):v.weapon==="hammer"?(q=this.createHammer3D(),this.hammerPreview=q):(q=this.createBomb3D(),this.bombPreview=q),q.scale.set(.65,.65,.65),q.position.set(0,1.45,0),S.add(q),this.pkArenaGroup.add(S)}),this.pkArenaColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:8}],this.pkArenaInteractables=[{id:"pk_crystal",name:"决斗匹配",x:0,y:.6,z:-5,triggerRadius:1.8}]}createSword3D(){const t=new ot,e=new K(.02,.02,.18,6),n=new V({color:4073251,flatShading:!0}),i=new w(e,n);i.position.y=-.2,i.castShadow=!0,t.add(i);const s=new U(.14,.04,.04),a=new V({color:16757504,flatShading:!0}),r=new w(s,a);r.position.y=-.1,r.castShadow=!0,t.add(r);const c=new U(.06,.55,.018),l=new V({color:13621468,emissive:1118481,flatShading:!0}),h=new w(c,l);h.position.y=.22,h.castShadow=!0,t.add(h);const d=new de(.042,.08,4),u=new w(d,l);return u.position.y=.525,u.rotation.y=Math.PI/4,u.castShadow=!0,t.add(u),t}createHammer3D(){const t=new ot,e=new K(.02,.02,.8,6),n=new V({color:2171169,flatShading:!0}),i=new w(e,n);i.position.y=-.1,i.castShadow=!0,t.add(i);const s=new U(.24,.32,.24),a=new V({color:4545124,flatShading:!0}),r=new w(s,a);r.position.y=.38,r.castShadow=!0,t.add(r);const c=new U(.25,.06,.25),l=new V({color:16757504,flatShading:!0}),h=new w(c,l);return h.position.y=.38,t.add(h),t}createBomb3D(){const t=new ot,e=new Rt(.18,10,10),n=new V({color:2503224,flatShading:!0}),i=new w(e,n);i.position.y=.1,i.castShadow=!0,t.add(i);const s=new K(.04,.05,.06,8),a=new V({color:5533306,flatShading:!0}),r=new w(s,a);r.position.y=.28,r.castShadow=!0,t.add(r);const c=new K(.008,.008,.1,4),l=new V({color:16766287,flatShading:!0}),h=new w(c,l);h.position.set(.02,.35,0),h.rotation.z=-.3,t.add(h);const d=new Rt(.025,4,4),u=new _t({color:16727296}),p=new w(d,u);return p.position.set(.05,.4,0),t.add(p),t}createFurnitureModel(t){const e=new ot;if(t==="painting"){const n=new U(1.2,.8,.06),i=new V({color:5125166,flatShading:!0}),s=new w(n,i);s.castShadow=!0,e.add(s);const a=new U(1.1,.7,.01),r=new V({color:16774112,flatShading:!0}),c=new w(a,r);c.position.z=.031,e.add(c);const l=new K(.18,.18,.01,12);l.rotateX(Math.PI/2);const h=new _t({color:16740419}),d=new w(l,h);d.position.set(0,.1,.038),e.add(d);const u=new U(1.1,.25,.01),p=new V({color:2733814,flatShading:!0}),g=new w(u,p);g.position.set(0,-.2,.038),e.add(g)}else if(t==="christmas_tree"){const n=new K(.1,.12,.4,8),i=new V({color:6111287,flatShading:!0}),s=new w(n,i);s.position.y=.2,s.castShadow=!0,e.add(s);const a=new V({color:1793568,flatShading:!0}),r=new w(new de(.55,.65,8),a);r.position.y=.65,r.castShadow=!0,e.add(r);const c=new w(new de(.42,.52,8),a);c.position.y=1.05,c.castShadow=!0,e.add(c);const l=new w(new de(.28,.38,8),a);l.position.y=1.4,l.castShadow=!0,e.add(l);const h=[16717636,16771899,58998,2733814,14696699];for(let d=0;d<12;d++){const u=new Rt(.045,4,4),p=new _t({color:h[d%h.length]}),g=new w(u,p),y=.4+Math.random()*1.1,m=.55*(1.5-y)/1.5,f=Math.random()*Math.PI*2;g.position.set(Math.cos(f)*m,y,Math.sin(f)*m),e.add(g)}}else if(t==="rabbit_sofa"){const n=new V({color:16744619,flatShading:!0}),i=new V({color:16777215,flatShading:!0}),s=new U(1.2,.3,.6),a=new w(s,n);a.position.y=.15,a.castShadow=!0,e.add(a);const r=new U(1.2,.55,.15),c=new w(r,n);c.position.set(0,.5,-.22),c.castShadow=!0,e.add(c);const l=new U(.14,.35,.08),h=new w(l,n);h.position.set(-.25,.9,-.22),h.rotation.z=.12,e.add(h);const d=new w(new U(.08,.25,.01),i);d.position.set(-.25,.9,-.179),d.rotation.z=.12,e.add(d);const u=new w(l,n);u.position.set(.25,.9,-.22),u.rotation.z=-.12,e.add(u);const p=new w(new U(.08,.25,.01),i);p.position.set(.25,.9,-.179),p.rotation.z=-.12,e.add(p);const g=new U(1.02,.1,.48),y=new w(g,i);y.position.set(0,.32,.03),e.add(y);const m=new U(.12,.38,.55),f=new w(m,n);f.position.set(-.54,.34,.02),f.castShadow=!0,e.add(f);const _=f.clone();_.position.x=.54,e.add(_)}else if(t==="swing_chair"){const n=new V({color:9479342,flatShading:!0}),i=new V({color:14737632,flatShading:!0}),s=new V({color:5227511,flatShading:!0}),a=new Vn(.35,.03,8,24);a.rotateX(Math.PI/2);const r=new w(a,n);r.position.y=.03,e.add(r);const c=new K(.03,.03,1.7,8),l=new w(c,n);l.position.set(0,.85,-.32),l.rotation.x=-.05,l.castShadow=!0,e.add(l);const h=new U(.06,.06,.38),d=new w(h,n);d.position.set(0,1.7,-.16),e.add(d);const u=new K(.008,.008,.1,4),p=new w(u,i);p.position.set(-.16,1.25,.02),p.rotation.z=.15,e.add(p);const g=new w(u,i);g.position.set(.16,1.25,.02),g.rotation.z=-.15,e.add(g);const y=new K(.24,.28,.12,12),m=new w(y,s);m.position.set(0,.82,.02),m.castShadow=!0,e.add(m);const f=new Rt(.28,8,8,0,Math.PI,0,Math.PI/2);f.rotateX(Math.PI/2);const _=new V({color:5227511,transparent:!0,opacity:.8,side:me,flatShading:!0}),x=new w(f,_);x.position.set(0,1.05,.02),x.rotation.y=Math.PI,e.add(x)}return e}initShopUI(){document.querySelectorAll("#modal-shop .shop-tabactive").forEach(r=>{r.addEventListener("click",c=>{const l=r.getAttribute("data-tab");this.switchShopTab(l)})}),this.switchShopTab("agriculture");const e=document.getElementById("btn-shop-count-minus"),n=document.getElementById("btn-shop-count-plus"),i=document.getElementById("btn-shop-count-plus10"),s=document.getElementById("shop-buy-count-slider"),a=document.getElementById("btn-shop-execute-buy");e&&s&&e.addEventListener("click",()=>{let r=parseInt(s.value)||1;r>1&&(s.value=r-1,this.updateShopBuyCountUI())}),n&&s&&n.addEventListener("click",()=>{let r=parseInt(s.value)||1;r<99&&(s.value=r+1,this.updateShopBuyCountUI())}),i&&s&&i.addEventListener("click",()=>{let r=parseInt(s.value)||1;s.value=Math.min(99,r+10),this.updateShopBuyCountUI()}),s&&s.addEventListener("input",()=>{this.updateShopBuyCountUI()}),a&&a.addEventListener("click",r=>{if(!this.selectedShopItem)return;const c=parseInt(s?s.value:1)||1;this.executeShopBuy(this.selectedShopItem,c,r.clientX,r.clientY)})}switchShopTab(t){const e=document.querySelectorAll("#modal-shop .shop-tabactive");e.forEach(n=>{n.getAttribute("data-tab")===t&&(e.forEach(i=>{i.classList.remove("active"),i.style.borderLeftColor="transparent",i.style.color="var(--text-muted)"}),n.classList.add("active"),n.style.borderLeftColor="#27ae60",n.style.color="#fff",this.renderShopItems(t))})}getActiveShopTab(){const t=document.querySelector("#modal-shop .shop-tabactive.active");return t?t.getAttribute("data-tab"):"agriculture"}getActiveBagTab(){const t=document.querySelector("#modal-bag .bag-tabactive.active");return t?t.getAttribute("data-tab"):"seed"}updateShopCoins(){const t=document.querySelector("#modal-shop .shop-coins-val");t&&(t.textContent=this.gameData.coins)}updateShopBuyCountUI(){const t=document.getElementById("shop-buy-count-slider"),e=document.getElementById("shop-buy-count-text"),n=document.querySelector("#shop-item-detail .shop-detail-total-price");if(!t||!this.selectedShopItem)return;const i=parseInt(t.value)||1;if(e&&(e.textContent=i),n)if(this.selectedShopItem.id.startsWith("coin_"))n.textContent="免费";else{const s=this.selectedShopItem.price*i;n.textContent=`🪙 ${s}`}}showShopItemDetail(t){this.selectedShopItem=t;const e=document.getElementById("shop-item-detail");if(!e)return;const n=e.querySelector(".shop-detail-empty"),i=e.querySelector(".shop-detail-content");n&&(n.style.display="none"),i&&(i.style.display="flex");const s=e.querySelector(".shop-detail-icon");if(s){const d=t.name.split(" ").pop()||"📦";s.textContent=d}const a=e.querySelector(".shop-detail-title");a&&(a.textContent=t.name.replace(/ 🌻| 🍓| 🖼️| 🎄| 🛋️| 🎪| 🪙| 🎁| 💎/,""));const r=e.querySelector(".shop-detail-owned");if(r)if(t.type==="seed"){const d=this.gameData.backpack.find(u=>u.id===t.id&&u.type==="seed");r.textContent=`已持有: ${d?d.count:0}`}else if(t.type==="decor"){const d=this.gameData.ownedFurnitures.includes(t.id);r.textContent=d?"✅ 已解锁":"🔒 未拥有"}else r.textContent="★ 免费福利";const c=e.querySelector(".shop-detail-desc");c&&(c.textContent=t.desc);const l=e.querySelector(".shop-detail-unit-price");l&&(t.id.startsWith("coin_")?l.textContent="￥0.00":l.textContent=`🪙 ${t.price}`);const h=document.getElementById("shop-buy-count-slider");h&&(h.value=1),this.updateShopBuyCountUI()}renderShopItems(t){const e=document.getElementById("shop-grid");if(!e)return;e.innerHTML="";let n=[];t==="agriculture"?n=[{id:"sunflower_seed",name:"向日葵种子 🌻",price:10,desc:"成熟需要 30 秒。收割可获得 20 金币 + 15 经验。",quality:"green",type:"seed"},{id:"strawberry_seed",name:"草莓种子 🍓",price:20,desc:"成熟需要 60 秒。收割可获得 45 金币 + 35 经验。",quality:"blue",type:"seed"}]:t==="decorations"?n=[{id:"painting_1",name:"浮空岛日落挂画 🖼️",price:50,desc:"悬挂在墙壁上的精美装饰，带来悠闲的落日余晖。",type:"decor",quality:"purple"},{id:"tree_1",name:"闪烁圣诞树 🎄",price:100,desc:"闪耀着七彩微光的圣诞树，散发节日温馨氛围。",type:"decor",quality:"purple"},{id:"sofa_1",name:"粉嫩兔子沙发 🛋️",price:150,desc:"兔耳设计的粉色单人沙发，触感松软，极度舒适。",type:"decor",quality:"purple"},{id:"swing_1",name:"室内网兜秋千 🎪",price:200,desc:"挂在天花板上的编织网秋千，轻轻摇曳，治愈满满。",type:"decor",quality:"purple"}]:t==="topup"&&(n=[{id:"coin_100",name:"免费金币充值包 🪙",amount:100,desc:"白嫖小包。免费充值 100 金币，附赠吃到金币声效！",type:"topup",quality:"gold",price:0},{id:"coin_500",name:"金币充值礼包 🎁",amount:500,desc:"免费大包。点击即刻免费充值 500 金币！",type:"topup",quality:"gold",price:0},{id:"coin_1000",name:"超级金币充值包 💎",amount:1e3,desc:"免费巨包！狂揽 1000 金币，金币爆屏！",type:"topup",quality:"gold",price:0}]);for(let s=0;s<12;s++){const a=document.createElement("div");a.className="shop-item-box";const r=n[s];if(r){const c=`q-${r.quality||"white"}`;a.classList.add(c),this.selectedShopItem&&this.selectedShopItem.id===r.id&&a.classList.add("active");const l=r.name.split(" ").pop()||"📦";a.innerHTML=`
          <span style="font-size: 1.8rem;">${l}</span>
          <span class="shop-item-box-price">${r.id.startsWith("coin_")?"免费":"🪙"+r.price}</span>
        `,a.addEventListener("click",()=>{document.querySelectorAll(".shop-item-box.active").forEach(h=>h.classList.remove("active")),a.classList.add("active"),this.showShopItemDetail(r)})}else a.innerHTML="";e.appendChild(a)}if(n.some(s=>this.selectedShopItem&&s.id===this.selectedShopItem.id))this.showShopItemDetail(this.selectedShopItem);else{this.selectedShopItem=null;const s=document.getElementById("shop-item-detail");if(s){const a=s.querySelector(".shop-detail-empty"),r=s.querySelector(".shop-detail-content");a&&(a.style.display="flex"),r&&(r.style.display="none")}}}executeShopBuy(t,e,n,i){if(t.id.startsWith("coin_")){const a=t.amount*e;this.gameData.coins+=a,this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(a,n,i),this.showShopItemDetail(t),setTimeout(()=>{this.refreshBag(this.getActiveBagTab())},50);return}const s=t.price*e;if(this.gameData.coins<s){alert("金币不足，无法购买！");return}if(this.gameData.coins-=s,t.type==="seed"){const a=this.gameData.backpack.find(r=>r.id===t.id&&r.type==="seed");a?a.count+=e:this.gameData.backpack.push({id:t.id,name:t.name.replace(/ 🌻| 🍓/,""),type:"seed",count:e,quality:t.quality,desc:t.desc}),this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(-s,n,i),this.showShopItemDetail(t),this.refreshFarm(),this.refreshBag("seed")}else if(t.type==="decor"){this.gameData.ownedFurnitures.includes(t.id)||this.gameData.ownedFurnitures.push(t.id);const a=this.gameData.backpack.find(r=>r.id===t.id&&r.type==="decor");a?a.count+=e:this.gameData.backpack.push({id:t.id,name:t.name.replace(/ 🖼️| 🎄| 🛋️| 🎪/,""),type:"decor",count:e,quality:"purple",desc:"购买于家园工坊的精美家具模型。进入家园编辑模式即可随意定位摆放它！"}),this.saveGameData(),this.updateShopCoins(),this.updateBaseUI(),this.showCoinFloatText(-s,n,i),this.showShopItemDetail(t),this.refreshHome(),this.refreshBag("decor")}}initRadialSeedMenu(){const t=document.getElementById("btn-close-radial");t&&t.addEventListener("click",()=>{this.closeRadialSeedMenu()}),document.querySelectorAll("#radial-seed-menu .radial-item-btn").forEach(n=>{n.addEventListener("click",i=>{if(i.stopPropagation(),n.classList.contains("disabled")||n.style.opacity==="0.5"){this.showToast("请走近空农地后再种植！");return}const s=n.getAttribute("data-seed");this.plantCropFromRadialMenu(s)})}),window.addEventListener("keydown",n=>{if(this.isRadialMenuOpen)if(n.key==="1"){const i=document.getElementById("radial-seed-sunflower");i&&i.click()}else if(n.key==="2"){const i=document.getElementById("radial-seed-strawberry");i&&i.click()}else n.key==="Escape"&&this.closeRadialSeedMenu()})}openRadialSeedMenu(){const t=document.getElementById("radial-seed-menu");t&&(this.isRadialMenuOpen=!0,window.parent&&(window.parent.isRadialMenuOpen=!0),t.classList.add("open"),t.style.display="block",this.updateRadialCounts(),this.updateActivePlotForRadialMenu())}closeRadialSeedMenu(){const t=document.getElementById("radial-seed-menu");t&&(this.isRadialMenuOpen=!1,window.parent&&(window.parent.isRadialMenuOpen=!1),t.classList.remove("open"),setTimeout(()=>{this.isRadialMenuOpen||(t.style.display="none")},300))}updateRadialCounts(){const t=document.querySelector("#radial-seed-sunflower .radial-count"),e=document.querySelector("#radial-seed-strawberry .radial-count"),n=this.gameData.backpack.find(s=>s.id==="sunflower_seed"&&s.type==="seed"),i=this.gameData.backpack.find(s=>s.id==="strawberry_seed"&&s.type==="seed");t&&(t.textContent=n?n.count:0),e&&(e.textContent=i?i.count:0)}updateActivePlotForRadialMenu(){if(!this.isRadialMenuOpen||this.currentMap!=="farm"||!this.player||!this.farmPlots3D)return;let t=null,e=1/0;this.gameData.farmPlots.forEach((i,s)=>{if(i.unlocked&&i.status==="empty"){const a=this.farmPlots3D[s];if(a){const r=this.player.position.x-a.x,c=this.player.position.z-a.z,l=Math.sqrt(r*r+c*c);l<e&&(e=l,t=s)}}});const n=document.getElementById("radial-seed-menu");n&&(t!==null&&e<2.2?(this.activePlotIndex=t,n.querySelectorAll(".radial-item-btn").forEach(i=>{i.classList.remove("disabled"),i.style.opacity="1"})):(this.activePlotIndex=null,n.querySelectorAll(".radial-item-btn").forEach(i=>{i.classList.add("disabled"),i.style.opacity="0.5"})))}plantCropFromRadialMenu(t){if(this.activePlotIndex===null){this.showToast("请靠近空农地后再种植！");return}const e=this.gameData.backpack.find(s=>s.id===t&&s.type==="seed");if(!e||e.count<=0){this.showToast(`${t==="sunflower_seed"?"向日葵":"草莓"}种子数量不足！正为您打开市集商店...`),this.closeRadialSeedMenu(),this.modalMgr.openModal("shop"),this.switchShopTab("agriculture");return}e.count--;const n=this.gameData.farmPlots[this.activePlotIndex];n.status="growing",n.seedId=t,n.plantTime=Date.now(),this.saveGameData(),this.refreshFarm(),this.updateRadialCounts(),this.playCustomSound(330,.25,"sine",.1),this.recreateCrop3D(this.activePlotIndex);const i=t==="sunflower_seed"?"向日葵":"草莓";this.showToast(`成功播种了 1 颗 ${i} 种子 🌱`)}buildLakePlatform(){this.lakeGroup.clear(),this.lakeColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:12}],this.lakeInteractables=[],this.bowlsList=[],this.ripplesList=[],this.noteParticles=[],this.lastBowlSoundTime=0,this.lastWaterStepTime=0;const t=new K(12,12.5,1.2,32),e=new V({color:15724532,flatShading:!0}),n=new w(t,e);n.position.y=0,n.receiveShadow=!0,n.castShadow=!0,this.lakeGroup.add(n);const i=new K(12.5,11.8,1.8,32),s=new V({color:4545124,flatShading:!0}),a=new w(i,s);a.position.y=-1.5,this.lakeGroup.add(a);const r=new Pn(6,32);r.rotateX(-Math.PI/2);const c=new _t({color:44225,side:me}),l=new w(r,c);l.position.y=.602,this.lakeGroup.add(l);const h=new Pn(6,32);h.rotateX(-Math.PI/2);const d=new _t({color:5227511,transparent:!0,opacity:.55,side:me}),u=new w(h,d);u.position.y=.61,this.lakeGroup.add(u);const p=new V({color:14737632,flatShading:!0}),g=new U(1.6,.22,.4),y=24,m=6.1;for(let ft=0;ft<y;ft++){const T=ft*Math.PI*2/y,b=Math.cos(T)*m,k=Math.sin(T)*m,it=new w(g,p);it.position.set(b,.65,k),it.rotation.y=-T+Math.PI/2,it.castShadow=!0,it.receiveShadow=!0,this.lakeGroup.add(it)}const f=new K(.42,.28,.22,12,1,!0),_=new K(.28,.28,.02,12),x=new V({color:16777215,flatShading:!0,side:me,emissive:1118481});for(let ft=0;ft<6;ft++){const T=new ot,b=ft*Math.PI*2/6+(Math.random()-.5)*.5,k=2+Math.random()*2.8,it=Math.cos(b)*k,at=Math.sin(b)*k;T.position.set(it,.61,at);const st=new w(f,x);st.castShadow=!0,st.receiveShadow=!0,T.add(st);const St=new w(_,x);St.position.y=-.1,St.castShadow=!0,T.add(St),this.lakeGroup.add(T),this.bowlsList.push({group:T,position:T.position,rotation:T.rotation,velocity:new L((Math.random()-.5)*.35,0,(Math.random()-.5)*.35),phase:Math.random()*Math.PI*2})}const M=new ot;M.position.set(0,.6,-8);const R=new V({color:1710618,flatShading:!0}),A=new V({color:16448250,flatShading:!0}),E=new w(new U(1.6,.82,.65),R);E.position.y=.41,E.castShadow=!0,E.receiveShadow=!0,M.add(E);const I=new w(new U(1.6,.6,.2),R);I.position.set(0,1.12,-.225),I.castShadow=!0,M.add(I);const v=new w(new U(1.5,.05,.25),A);v.position.set(0,.81,.22),v.castShadow=!0,M.add(v);const S=new w(new U(.05,.12,.27),R);S.position.set(-.775,.85,.22),S.castShadow=!0,M.add(S);const P=S.clone();P.position.x=.775,M.add(P);const O=new w(new U(.65,.45,.3),R);O.position.set(0,.225,.65),O.castShadow=!0,O.receiveShadow=!0,M.add(O),this.lakeGroup.add(M),this.lakeInteractables.push({id:"piano",name:"弹奏钢琴",x:0,y:.6,z:-7,triggerRadius:1.6});const j=new V({color:15658734,flatShading:!0}),D=new U(.8,.36,.45),F=new w(D,j);F.position.set(7.5,.78,0),F.castShadow=!0,F.receiveShadow=!0,this.lakeGroup.add(F),this.lakeInteractables.push({id:"lake_seat_1",name:"坐下静赏",x:7.5,y:.6,z:0,triggerRadius:1.5});const z=new w(D,j);z.position.set(-7.5,.78,0),z.castShadow=!0,z.receiveShadow=!0,this.lakeGroup.add(z),this.lakeInteractables.push({id:"lake_seat_2",name:"坐下静赏",x:-7.5,y:.6,z:0,triggerRadius:1.5});const Z=new ot;Z.position.set(0,.6,9.5);const Y=p,q=new w(new K(.8,.9,.22,12),Y);q.position.y=.11,q.castShadow=!0,q.receiveShadow=!0,Z.add(q);const J=new w(new K(.68,.58,.35,12),Y);J.position.y=.38,J.castShadow=!0,J.receiveShadow=!0,Z.add(J);const nt=new _t({color:45311,transparent:!0,opacity:.65,side:me}),ct=new w(new Pn(.64,12),nt);ct.rotateX(-Math.PI/2),ct.position.y=.54,Z.add(ct);const X=new K(.07,.14,.8,8),et=new _t({color:14743546,transparent:!0,opacity:.82}),pt=new w(X,et);pt.position.y=.9,Z.add(pt);const bt=new _t({color:16777215}),xt=new w(new U(.07,.07,.07),bt);xt.position.set(.1,1.25,.07),Z.add(xt);const It=xt.clone();It.position.set(-.12,1.3,-.09),Z.add(It);const Gt=xt.clone();Gt.position.set(.04,1.15,-.13),Z.add(Gt);const At=new w(new K(.03,.03,.8,8),new V({color:5125166}));At.position.set(.9,.4,.4),At.rotation.z=-.15,At.castShadow=!0,Z.add(At);const Et=new w(new U(.55,.16,.03),new V({color:9268835}));Et.position.set(.85,.72,.4),Et.rotation.z=-.15,Et.rotation.y=-.2,Et.castShadow=!0,Z.add(Et);const N=new w(new U(.38,.06,.04),new _t({color:58879}));N.position.set(.86,.72,.42),N.rotation.z=-.15,N.rotation.y=-.2,Z.add(N),this.lakeGroup.add(Z),this.lakeInteractables.push({id:"exit_house",name:"返回海岛大厅",x:0,y:.6,z:8.5,triggerRadius:1.5});const ht=new K(.1,.14,.8,6),tt=new V({color:5125166}),lt=new Is(.55),Q=new V({color:3046706,flatShading:!0});[{x:-9.5,z:-9.5},{x:9.5,z:-9.5},{x:-9.5,z:9.5},{x:9.5,z:9.5}].forEach(ft=>{const T=new ot;T.position.set(ft.x,.6,ft.z);const b=new w(ht,tt);b.position.y=.4,b.castShadow=!0,T.add(b);const k=new w(lt,Q);k.position.y=.95,k.castShadow=!0,T.add(k),this.lakeGroup.add(T)}),this.initPianoKeysEvents()}initPianoKeysEvents(){const t=document.querySelectorAll("#modal-piano .piano-key"),e={C4:261.63,D4:293.66,E4:329.63,F4:349.23,G4:392,A4:440,B4:493.88,C5:523.25};t.forEach(a=>{const r=c=>{c.preventDefault();const l=a.getAttribute("data-note"),h=e[l];h&&(this.playCustomSound(h,.8,"sine",.1),window.dispatchEvent(new CustomEvent("piano-note-played",{detail:{note:l}})),a.classList.add("active"),setTimeout(()=>a.classList.remove("active"),120))};a.addEventListener("mousedown",r),a.addEventListener("touchstart",r,{passive:!1})});const n={a:"C4",s:"D4",d:"E4",f:"F4",g:"G4",h:"A4",j:"B4",k:"C5"},i=a=>{const r=this.modalMgr?this.modalMgr.modals.piano:null;if(r&&r.classList.contains("open")){const c=a.key.toLowerCase(),l=n[c];if(l){const h=document.querySelector(`#modal-piano .piano-key[data-note="${l}"]`);if(h){const d=e[l];this.playCustomSound(d,.8,"sine",.1),window.dispatchEvent(new CustomEvent("piano-note-played",{detail:{note:l}})),h.classList.add("active"),setTimeout(()=>h.classList.remove("active"),120)}}}};window._pianoKeydownHandler&&window.removeEventListener("keydown",window._pianoKeydownHandler),window._pianoKeydownHandler=i,window.addEventListener("keydown",i);const s=document.getElementById("btn-exit-sitting");s&&s.addEventListener("click",a=>{a.preventDefault(),this.player&&(this.player.isSitting||this.player.isLyingDown)&&this.player.standUp()})}spawnNoteParticle(t){const e=document.createElement("canvas");e.width=64,e.height=64;const n=e.getContext("2d");n.fillStyle="#ffd700",n.font='bold 44px Outfit, "Noto Sans SC", sans-serif',n.textAlign="center",n.textBaseline="middle";const i=["🎵","🎶","楽","✨","♩","♩"],s=i[Math.floor(Math.random()*i.length)];n.fillText(s,32,32);const a=new Ih(e),r=new Ch({map:a,transparent:!0,opacity:.95,blending:Vo}),c=new mg(r),l=(Math.random()-.5)*.9,h=-7.5+(Math.random()-.5)*.3;c.position.set(l,1.45,h);const d=.32+Math.random()*.16;c.scale.set(d,d,d),this.lakeGroup.add(c),this.noteParticles.push({sprite:c,texture:a,material:r,velocity:new L((Math.random()-.5)*.7,1.1+Math.random()*.7,(Math.random()-.5)*.5),age:0,maxAge:1.6+Math.random()*.8})}playBowlCollisionSound(t,e){const n=Date.now();if(n-this.lastBowlSoundTime<80)return;this.lastBowlSoundTime=n;const i=[523.25,587.33,659.25,783.99,880,1046.5,1174.66,1318.51],s=i[Math.floor(Math.random()*i.length)];try{window.audioCtx||(window.audioCtx=new(window.AudioContext||window.webkitAudioContext)),window.audioCtx.state==="suspended"&&window.audioCtx.resume();const a=window.audioCtx.currentTime,r=.75*Math.min(e,1.2),c=.05*Math.min(e,1.2),l=window.audioCtx.createOscillator(),h=window.audioCtx.createGain();l.type="sine",l.frequency.setValueAtTime(s,a),h.gain.setValueAtTime(c,a),h.gain.exponentialRampToValueAtTime(1e-4,a+r),l.connect(h),h.connect(window.audioCtx.destination),l.start(),l.stop(a+r);const d=window.audioCtx.createOscillator(),u=window.audioCtx.createGain();d.type="sine",d.frequency.setValueAtTime(s*1.5,a),u.gain.setValueAtTime(c*.28,a),u.gain.exponentialRampToValueAtTime(1e-4,a+.25),d.connect(u),u.connect(window.audioCtx.destination),d.start(),d.stop(a+.25);const p=window.audioCtx.createOscillator(),g=window.audioCtx.createGain();p.type="sine",p.frequency.setValueAtTime(s*2,a),g.gain.setValueAtTime(c*.15,a),g.gain.exponentialRampToValueAtTime(1e-4,a+.18),p.connect(g),g.connect(window.audioCtx.destination),p.start(),p.stop(a+.18)}catch(a){console.warn("[音效] 白瓷碗磬钟音效合成失败:",a)}}createRipple(t,e,n){const i=new zs(.06,.09,32);i.rotateX(-Math.PI/2);const s=new _t({color:8445674,transparent:!0,opacity:.48,side:me}),a=new w(i,s);a.position.set(t,e,n),this.lakeGroup.add(a),this.ripplesList.push({mesh:a,geometry:i,material:s,size:.08,maxSize:1.4+Math.random()*.6,speed:1.1,maxOpacity:.5})}updateLakeFrame(t,e){if(!this.player)return;const n=this.player.position.x,i=this.player.position.z,s=Math.sqrt(n*n+i*i);if(s<6&&!this.player.isSitting){if(this.player.position.y=.52,this.player.velocity.y=0,this.player.isGrounded=!0,this.player.keys.w||this.player.keys.s||this.player.keys.a||this.player.keys.d||window.joystickDir&&(window.joystickDir.x!==0||window.joystickDir.y!==0)){const r=Date.now();r-this.lastWaterStepTime>320&&(this.createRipple(n,.612,i),this.lastWaterStepTime=r,this.playCustomSound(120,.18,"sine",.03))}this.bowlsList.forEach(r=>{const c=r.position.x-n,l=r.position.z-i,h=Math.sqrt(c*c+l*l);if(h<.82){const u=h>0?c/h:1,p=h>0?l/h:0,g=1.35;r.velocity.x+=u*g,r.velocity.z+=p*g,r.velocity.length()>2.2&&r.velocity.normalize().multiplyScalar(2.2),r.position.x=n+u*.83,r.position.z=i+p*.83,this.playBowlCollisionSound(r.position,1.1),this.createRipple(r.position.x,.612,r.position.z)}})}if(s>11.8){const a=n/s,r=i/s;this.player.position.x=a*11.8,this.player.position.z=r*11.8,this.player.group.position.copy(this.player.position),this.player.velocity.set(0,0,0)}this.bowlsList.forEach(a=>{a.position.x+=a.velocity.x*t,a.position.z+=a.velocity.z*t,a.velocity.multiplyScalar(.982),a.velocity.x+=(Math.random()-.5)*.08*t,a.velocity.z+=(Math.random()-.5)*.08*t,a.position.y=.61+Math.sin(e*.0022+a.phase)*.018,a.rotation.x=Math.sin(e*.0018+a.phase)*.038,a.rotation.z=Math.cos(e*.0024+a.phase)*.038;const r=Math.sqrt(a.position.x*a.position.x+a.position.z*a.position.z);if(r>5.58){const c=a.position.x/r,l=a.position.z/r,h=a.velocity.x*c+a.velocity.z*l;a.velocity.x-=2*h*c,a.velocity.z-=2*h*l,a.position.x=c*5.56,a.position.z=l*5.56,this.playBowlCollisionSound(a.position,.45),this.createRipple(a.position.x,.612,a.position.z)}});for(let a=0;a<this.bowlsList.length;a++)for(let r=a+1;r<this.bowlsList.length;r++){const c=this.bowlsList[a],l=this.bowlsList[r],h=l.position.x-c.position.x,d=l.position.z-c.position.z,u=Math.sqrt(h*h+d*d),p=.84;if(u<p){const g=h/u,y=d/u,m=l.velocity.x-c.velocity.x,f=l.velocity.z-c.velocity.z,_=m*g+f*y;if(_<0){const A=-1.05*_;c.velocity.x-=A*g*.5,c.velocity.z-=A*y*.5,l.velocity.x+=A*g*.5,l.velocity.z+=A*y*.5}const x=p-u;c.position.x-=g*x*.5,c.position.z-=y*x*.5,l.position.x+=g*x*.5,l.position.z+=y*x*.5;const M=(c.position.x+l.position.x)/2,R=(c.position.z+l.position.z)/2;this.playBowlCollisionSound(new L(M,.61,R),1),this.createRipple(M,.612,R)}}for(let a=this.ripplesList.length-1;a>=0;a--){const r=this.ripplesList[a];r.size+=r.speed*t,r.mesh.scale.set(r.size*10,1,r.size*10),r.material.opacity=r.maxOpacity*(1-r.size/r.maxSize),r.size>=r.maxSize&&(this.lakeGroup.remove(r.mesh),r.geometry.dispose(),r.material.dispose(),this.ripplesList.splice(a,1))}for(let a=this.noteParticles.length-1;a>=0;a--){const r=this.noteParticles[a];r.age+=t,r.sprite.position.addScaledVector(r.velocity,t),r.sprite.position.x+=Math.sin(r.age*6)*.012;const c=r.age/r.maxAge;r.material.opacity=.95*(1-c);const l=(.32+Math.sin(r.age*2)*.05)*(1-c*.4);r.sprite.scale.set(l,l,l),r.age>=r.maxAge&&(this.lakeGroup.remove(r.sprite),r.texture.dispose(),r.material.dispose(),this.noteParticles.splice(a,1))}}buildCastlePlatform(){this.castleGroup.clear(),this.castleColliders=[{type:"floor",worldX:0,worldZ:0,worldY:.6,radius:24}],this.castleInteractables=[],this.sakuraList=[],this.castleRipples=[],this.lastCastleWaterStepTime=0;const t=16745889,e=16777215,n=12000284,i=8505220,s=14142664,a=16731501,r=8445674;new _t({color:16728193});const c=new V({color:16757702,flatShading:!0}),l=new V({color:16777215,flatShading:!0}),h=new V({color:t,flatShading:!0}),d=new V({color:e,flatShading:!0}),u=new V({color:n,flatShading:!0}),p=new V({color:i,flatShading:!0}),g=new V({color:s,flatShading:!0}),y=new V({color:a,flatShading:!0}),m=new _t({color:r,transparent:!0,opacity:.65,side:me});new V({color:8445674,transparent:!0,opacity:.7,flatShading:!0});const f=new V({color:14743546,emissive:8445674,emissiveIntensity:.4,transparent:!0,opacity:.9,flatShading:!0}),_=new V({color:6111287,flatShading:!0}),x=new V({color:3046706,flatShading:!0}),M=new V({color:9268835,flatShading:!0}),R=33,A=33,E=new w(new U(R,1.2,A),p);E.position.set(0,0,0),E.receiveShadow=!0,E.castShadow=!0,this.cas;const I=-7.5,v=4.2,S=.6+v,P=(Zt,Wt,oe,ye,xe=0)=>{const qe=new ot;qe.position.set(Wt,oe,ye),qe.rotation.y=xe;const fn=new w(new U(1.3,1.7,.25),d);fn.castShadow=!0,qe.add(fn);const mn=new w(new K(.65,.65,.25,10,1,!1,0,Math.PI),d);mn.rotation.x=Math.PI/2,mn.position.y=.85,mn.castShadow=!0,qe.add(mn);const ii=new w(new U(1.05,1.45,.12),f);ii.position.y=.05,qe.add(ii);const Ke=new w(new U(1.5,.1,.35),d);Ke.position.y=-.9,Ke.position.z=.05,Ke.castShadow=!0,qe.add(Ke),Zt.add(qe)},O=(Zt,Wt,oe)=>{const ye=new ot;ye.position.set(Zt,.6,Wt),ye.scale.set(oe,oe,oe);const xe=new ot,qe=5;let fn=0,mn=0;const ii=new K(.08,.12,.4,5);for(let Je=0;Je<qe;Je++){const ke=new w(ii,_);ke.position.set(mn,fn+.2,0);const Ta=.08*Je;ke.rotation.z=Ta,ke.castShadow=!0,ke.receiveShadow=!0,xe.add(ke),fn+=.36*Math.cos(Ta),mn-=.36*Math.sin(Ta)}ye.add(xe);const Ke=new ot;Ke.position.set(mn,fn,0);const Ii=new U(.8,.02,.25);Ii.translate(.4,0,0);const xs=6;for(let Je=0;Je<xs;Je++){const ke=new w(Ii,x);ke.rotation.y=Je/xs*Math.PI*2,ke.rotation.z=-.22,ke.castShadow=!0,Ke.add(ke)}ye.add(Ke);const vs=new Rt(.09,4,4);for(let Je=0;Je<2;Je++){const ke=new w(vs,M);ke.position.set(mn+.08*Math.cos(Je*Math.PI),fn-.05,.08*Math.sin(Je*Math.PI)),ke.castShadow=!0,ye.add(ke)}this.castleGroup.add(ye)},j=-3.5,D=19,F=7.5,z=-10.5,Z=6,Y=-5.5,q=4,J=7.5,nt=new w(new U(D,.12,F),l);nt.position.set(j,.6+.06,I),nt.receiveShadow=!0,nt.castShadow=!0,this.castleGroup.add(nt),this.castleColliders.push({type:"floor",worldX:j,worldZ:I,worldY:.72,radius:D/2+1});const ct=new w(new U(D,v,.3),h);ct.position.set(j,.6+v/2,I-F/2+.15),ct.castShadow=!0,this.castleGroup.add(ct);const X=new w(new U(7,v,.3),h);X.position.set(-9.5,.6+v/2,I+F/2-.15),X.castShadow=!0,this.castleGroup.add(X);const et=new w(new U(5.5,v,.3),h);et.position.set(-.25,.6+v/2,I+F/2-.15),et.castShadow=!0,this.castleGroup.add(et);const pt=new w(new U(1.2,v,.3),h);pt.position.set(-6.9,.6+v/2,I+F/2-.15),this.castleGroup.add(pt);const bt=new w(new U(1.2,v,.3),h);bt.position.set(-4.1,.6+v/2,I+F/2-.15),this.castleGroup.add(bt);const xt=2.4,It=1.6,Gt=-5.5,At=I+F/2,Et=new ot;Et.position.set(Gt,.6,At),this.castleGroup.add(Et);const N=.12,ht=v,tt=new K(N,N*1.2,ht,12),lt=new w(tt,d);lt.position.set(-xt/2-.1,ht/2,It-.3),lt.castShadow=!0,Et.add(lt);const Q=lt.clone();Q.position.z-=.45,Et.add(Q);const Lt=new w(tt,d);Lt.position.set(xt/2+.1,ht/2,It-.3),Lt.castShadow=!0,Et.add(Lt);const ft=Lt.clone();ft.position.z-=.45,Et.add(ft);const T=new U(.38,.12,.85),b=new w(T,d);b.position.set(-xt/2-.1,ht-.06,It-.52),Et.add(b);const k=b.clone();k.position.x=xt/2+.1,Et.add(k);const it=new w(new U(xt+.6,.45,1.2),d);it.position.set(0,ht+.225,It-.52),it.castShadow=!0,Et.add(it);const at=new w(new U(xt+.8,.18,1.4),u);at.rotation.x=.22,at.position.set(0,ht+.48,It-.42),at.castShadow=!0,Et.add(at);const st=new w(new U(2.4,3.2,.22),d);st.position.set(0,1.6,-.05),Et.add(st);const St=new w(new U(2,3,.12),c);St.position.set(0,1.5,-.05),St.castShadow=!0,Et.add(St);const wt=new w(new Rt(.06,8,8),new V({color:16766720}));wt.position.set(-.1,1.45,.05),Et.add(wt);const Mt=wt.clone();Mt.position.x=.1,Et.add(Mt);const Pt=3,Ut=7.5,rt=-14.5,Jt=new ot;Jt.position.set(rt,.6,I),this.castleGroup.add(Jt);const qt=new w(new U(Pt,.18,Ut),l);qt.position.y=.09,qt.receiveShadow=!0,qt.castShadow=!0,Jt.add(qt),this.castleColliders.push({type:"floor",worldX:rt,worldZ:I,worldY:.78,radius:Pt/2+.5});const Ht=3.2,Dt=new K(.1,.1,Ht,8);for(let Zt=-Ut/2+.6;Zt<=Ut/2-.6;Zt+=2){const Wt=new w(Dt,d);Wt.position.set(-Pt/2+.2,.18+Ht/2,Zt),Wt.castShadow=!0,Jt.add(Wt)}const Tt=new w(new U(Pt+.2,.24,Ut+.2),d);Tt.position.set(0,.18+Ht+.12,0),Jt.add(Tt);const Yt=new K(.05,.05,.6,6),ee=(Zt,Wt,oe,ye)=>{const xe=oe-Zt,qe=ye-Wt,fn=Math.sqrt(xe*xe+qe*qe),ii=Math.round(fn/.5);for(let Ii=0;Ii<=ii;Ii++){const xs=Ii/ii,vs=new w(Yt,d);vs.position.set(Zt+xe*xs,.18+.3,Wt+qe*xs),vs.castShadow=!0,Jt.add(vs)}const Ke=new w(new U(fn+.1,.06,.06),d);Ke.position.set((Zt+oe)/2,.18+.6,(Wt+ye)/2),Ke.rotation.y=-Math.atan2(ye-Wt,oe-Zt),Jt.add(Ke)};ee(-Pt/2+.2,-Ut/2+.2,-Pt/2+.2,Ut/2-.2),ee(-Pt/2+.2,Ut/2-.2,Pt/2-.2,Ut/2-.2),ee(-Pt/2+.2,-Ut/2+.2,Pt/2-.2,-Ut/2+.2),P(this.castleGroup,-10.5,.6+v/2+.2,I+F/2-.05),P(this.castleGroup,-1.5,.6+v/2+.2,I+F/2-.05);const pe=1,jt=-4.5,ut=1.35,B=S+.15+3.8,mt=new ot;mt.position.set(pe,.6,jt),this.castleGroup.add(mt);const yt=new w(new K(ut,ut,B,18),h);yt.position.y=B/2,yt.castShadow=!0,yt.receiveShadow=!0,mt.add(yt);const Ft=Zt=>{const Wt=new w(new K(ut+.08,ut+.08,.12,18),d);Wt.position.y=Zt,mt.add(Wt)};Ft(.12),Ft(S-.05),Ft(B-.06);const Bt=new K(.44,.44,2.2,10),ne=new w(Bt,f);ne.position.set(0,S+1.2,ut-.08),ne.rotation.y=Math.PI/2,mt.add(ne);const ie=new w(new K(.48,.48,2.22,10,1,!0),d);ie.position.set(0,S+1.2,ut-.06),ie.rotation.y=Math.PI/2,mt.add(ie);const Me=new Rt(ut+.08,16,12,0,Math.PI*2,0,Math.PI/2),Se=new w(Me,d);Se.position.y=B,Se.castShadow=!0,mt.add(Se);const se=new w(new K(.02,.05,1.6,8),new V({color:16766720}));se.position.set(0,B+1.2,0),Se.add(se);const Re=new w(new Rt(.12,8,8),new V({color:16766720}));Re.position.y=.8,se.add(Re);const We=4,ps=-4.5,Zn=4,dn=3.5,un=new ot;un.position.set(We,.6,ps),this.castleGroup.add(un);const xn=new w(new U(Zn,.12,dn),l);xn.position.y=.06,xn.receiveShadow=!0,xn.castShadow=!0,un.add(xn),this.castleColliders.push({type:"floor",worldX:We,worldZ:ps,worldY:.72,radius:Zn/2+.3});const yi=new w(new U(.3,v,dn),h);yi.position.set(Zn/2-.15,v/2,0),yi.castShadow=!0,un.add(yi);const xi=new w(new U(.3,v,dn),h);xi.position.set(-Zn/2+.15,v/2,0),xi.castShadow=!0,un.add(xi);const fs=new w(new U(Zn,v,.3),h);fs.position.set(0,v/2,dn/2-.15),fs.castShadow=!0,un.add(fs),P(un,0,v/2+.1,dn/2-.05),O(14,9,1.15),O(-15,-1,1.1),O(15,-1,1.1),O(-13,-12,1),O(13,-12,1);const ra=D+.4,ca=F+.4,C=new w(new U(ra,.25,ca),d);C.position.set(j,S+.125,I),C.receiveShadow=!0,C.castShadow=!0,this.castleGroup.add(C);const G=new w(new U(D,.15,F),d);G.position.set(j,S+.075,I),G.receiveShadow=!0,G.castShadow=!0,this.castleGroup.add(G),this.castleColliders.push({type:"floor",worldX:j,worldZ:I,worldY:S+.15,radius:D/2+.5});const H=3.5,$=5,W=4.8,vt=-4.5,Ct=new ot;Ct.position.set(vt,S+.15,I),this.castleGroup.add(Ct);const Nt=new w(new U($,H,.3),h);Nt.position.set(0,H/2,-W/2+.15),Nt.castShadow=!0,Ct.add(Nt);const zt=new w(new U($,H,.3),h);zt.position.set(0,H/2,W/2-.15),zt.castShadow=!0,Ct.add(zt);const Xt=new w(new U(.3,H,W),h);Xt.position.set($/2-.15,H/2,0),Xt.castShadow=!0,Ct.add(Xt),P(Ct,-1.1,H/2+.1,W/2-.05),P(Ct,1.1,H/2+.1,W/2-.05);const Ot=4,kt=6.5,fe=-10,Ie=I-.5,ce=new ot;ce.position.set(fe,S+.15,Ie),this.castleGroup.add(ce);const Xe=new w(new U(Ot,H,.3),h);Xe.position.set(0,H/2,-kt/2+.15),Xe.castShadow=!0,ce.add(Xe);const le=new w(new U(.3,H,kt),h);le.position.set(-Ot/2+.15,H/2,0),le.castShadow=!0,ce.add(le);const $t=new w(new U(.3,H,kt),h);$t.position.set(Ot/2-.15,H/2,0),$t.castShadow=!0,ce.add($t);const jn=new w(new U(Ot,H,.3),h);jn.position.set(0,H/2,kt/2-.15),jn.castShadow=!0,ce.add(jn),P(ce,0,H/2+.1,kt/2-.05),P(ce,-Ot/2+.05,H/2+.1,0,-Math.PI/2);const ae=3,je=6.5,Kn=.5,Nn=I+.5,pn=new ot;pn.position.set(Kn,S+.15,Nn),this.castleGroup.add(pn);const be=new w(new U(ae,H,.3),h);be.position.set(0,H/2,-je/2+.15),be.castShadow=!0,pn.add(be);const on=new w(new U(ae,H,.3),h);on.position.set(0,H/2,je/2-.15),on.castShadow=!0,pn.add(on);const Jn=new w(new U(.3,H,je),h);Jn.position.set(-ae/2+.15,H/2,0),Jn.castShadow=!0,pn.add(Jn),P(pn,0,H/2+.1,je/2-.05);const Be=new K(.07,.07,.72,8),ms=new U(q+Z,.08,.08),vi=new ot;vi.position.set((Y+z)/2,S+.15,I);const _i=new w(ms,d);_i.position.set(0,.72,J/2-.1),_i.castShadow=!0,vi.add(_i);for(let Zt=-10/2+.4;Zt<=(q+Z)/2-.4;Zt+=.8){const Wt=Zt+(Y+z)/2;if(Wt>Kn-ae/2-.2&&Wt<Kn+ae/2+.2||Wt>vt-$/2-.2)continue;const oe=new w(Be,d);oe.position.set(Zt,.36,J/2-.1),oe.castShadow=!0,vi.add(oe)}this.castleGroup.add(vi);const la=S+.15+H,kr=4.6,Gr=3.8,Mi=new ot;Mi.position.set(fe,la,Ie);const Ws=new w(new U(kr,.18,Gr),u);Ws.position.set(0,.82,-1.6),Ws.rotation.x=-.42,Ws.castShadow=!0,Mi.add(Ws);const Xs=new w(new U(kr,.18,Gr),u);Xs.position.set(0,.82,1.6),Xs.rotation.x=.42,Xs.castShadow=!0,Mi.add(Xs);const ha=new w(new U(.35,1.3,kt-.6),h);ha.position.set(-Ot/2+.15,.6,0),Mi.add(ha);const Hr=ha.clone();Hr.position.x=Ot/2-.15,Mi.add(Hr),this.castleGroup.add(Mi);const Vr=5,Wr=4.2,Si=new ot;Si.position.set(vt,la+.15,I);const qs=new w(new U(Vr,.18,Wr),u);qs.position.set(0,.9,-1.8),qs.rotation.x=-.42,qs.castShadow=!0,Si.add(qs);const Ys=new w(new U(Vr,.18,Wr),u);Ys.position.set(0,.9,1.8),Ys.rotation.x=.42,Ys.castShadow=!0,Si.add(Ys);const da=new w(new U(.35,1.45,W-.6),h);da.position.set(-$/2+.15,.65,0),Si.add(da);const Xr=da.clone();Xr.position.x=$/2-.15,Si.add(Xr),this.castleGroup.add(Si);const qr=3.6,Yr=3.8,$s=new ot;$s.position.set(Kn,la-.1,Nn);const Zs=new w(new U(qr,.18,Yr),u);Zs.position.set(0,.8,-1.6),Zs.rotation.x=-.42,Zs.castShadow=!0,$s.add(Zs);const js=new w(new U(qr,.18,Yr),u);js.position.set(0,.8,1.6),js.rotation.x=.42,js.castShadow=!0,$s.add(js),this.castleGroup.add($s);const ua=4,pa=-.25,Qn=3.6,vn=2.4,bi=5,ti=new ot;ti.position.set(ua,.6,pa),this.castleGroup.add(ti);const $r=.12,Zr=new K($r,$r*1.1,Qn,10);[-2,0,2].forEach(Zt=>{const Wt=new w(Zr,d);Wt.position.set(-vn/2+.1,Qn/2,Zt),Wt.castShadow=!0,ti.add(Wt);const oe=new w(Zr,d);oe.position.set(vn/2-.1,Qn/2,Zt),oe.castShadow=!0,ti.add(oe)});const Vh=.2,jr=.3,Wh=bi+.2,Ks=new w(new U(Vh,jr,Wh),d);Ks.position.set(-vn/2+.1,Qn-jr/2,0),Ks.castShadow=!0,ti.add(Ks);const Kr=Ks.clone();Kr.position.x=vn/2-.1,ti.add(Kr);const Js=new w(new U(vn+.2,.15,bi+.2),d);Js.position.y=Qn+.075,Js.castShadow=!0,Js.receiveShadow=!0,ti.add(Js),this.castleColliders.push({type:"floor",worldX:ua,worldZ:pa,worldY:.6+Qn+.15,radius:bi/2+.3});const Ei=new ot;Ei.position.set(ua,.6+Qn+.15,pa);const Xh=.06,qh=.06,Qs=new w(new U(qh,Xh,bi),d);Qs.position.set(-vn/2+.08,.72,0),Qs.castShadow=!0,Ei.add(Qs);const Jr=Qs.clone();Jr.position.x=vn/2-.08,Ei.add(Jr);for(let Zt=-bi/2+.4;Zt<=bi/2-.4;Zt+=.8){const Wt=new w(Be,d);Wt.position.set(-vn/2+.08,.36,Zt),Wt.castShadow=!0,Ei.add(Wt);const oe=Wt.clone();oe.position.x=vn/2-.08,Ei.add(oe)}this.castleGroup.add(Ei);const _n=4,Mn=5.75,Ti=3.8,ei=7,Ai=7,to=new w(new U(ei,Ti,Ai),h);to.position.set(_n,.6+Ti/2,Mn),to.castShadow=!0,to.receiveShadow=!0,this.castleGroup.add(to),this.castleColliders.push({type:"floor",worldX:_n,worldZ:Mn,worldY:.72,radius:ei/2+.5});const Qr=new w(new U(ei+.4,.15,Ai+.4),d);Qr.position.set(_n,.6+Ti+.075,Mn),this.castleGroup.add(Qr);const fa=2.4,ni=2.5,tc=Zt=>{const Wt=new w(new U(fa+.3,ni+.15,.2),d);Wt.position.set(Zt,.6+ni/2+.075,Mn+Ai/2-.05),Wt.castShadow=!0,this.castleGroup.add(Wt);const oe=new w(new U(fa,ni,.1),d);oe.position.set(Zt,.6+ni/2,Mn+Ai/2-.02),this.castleGroup.add(oe);for(let ye=-ni/2+.3;ye<ni/2;ye+=.4){const xe=new w(new U(fa-.15,.06,.05),g);xe.position.set(Zt,.6+ni/2+ye,Mn+Ai/2+.03),this.castleGroup.add(xe)}};tc(_n-1.6),tc(_n+1.6);const eo=new w(new U(ei+.6,.18,4.2),u);eo.position.set(_n,.6+Ti+.75,Mn-1.7),eo.rotation.x=-.42,eo.castShadow=!0,this.castleGroup.add(eo);const no=new w(new U(ei+.6,.18,4.2),u);no.position.set(_n,.6+Ti+.75,Mn+1.7),no.rotation.x=.42,no.castShadow=!0,this.castleGroup.add(no);const io=new w(new U(Ai,1.2,.3),h);io.position.set(_n-ei/2+.15,.6+Ti+.5,Mn),io.rotation.y=Math.PI/2,this.castleGroup.add(io);const ec=io.clone();ec.position.x=_n+ei/2-.15,this.castleGroup.add(ec);const ma=14,nc=.2,Yh=1.8,$h=I-1,Zh=1.3,ga=.16,jh=(S+.15-.6)/ma,Kh=(Yh-nc)/ma;for(let Zt=0;Zt<ma;Zt++){const Wt=nc+Zt*Kh,oe=.6+Zt*jh,ye=$h,xe=new w(new U(Zh,ga,.45),d);xe.position.set(Wt,oe+ga/2,ye),xe.castShadow=!0,xe.receiveShadow=!0,this.castleGroup.add(xe),this.castleColliders.push({type:"floor",worldX:Wt,worldZ:ye,worldY:oe+ga,radius:.85})}const gs=-11,ws=2,Ci=2.6,so=new w(new Pn(Ci,16),y);so.rotateX(-Math.PI/2),so.position.set(gs,.602,ws),so.receiveShadow=!0,this.castleGroup.add(so);const wa=new w(new Pn(Ci-.1,16),m);wa.rotateX(-Math.PI/2),wa.position.set(gs,.61,ws),this.castleGroup.add(wa);const Jh=new U(.7,.12,.25),ic=14;for(let Zt=0;Zt<ic;Zt++){const Wt=Zt*Math.PI*2/ic,oe=gs+Math.cos(Wt)*(Ci+.1),ye=ws+Math.sin(Wt)*(Ci+.1),xe=new w(Jh,d);xe.position.set(oe,.64,ye),xe.rotation.y=-Wt+Math.PI/2,xe.castShadow=!0,this.castleGroup.add(xe)}const sc=new V({color:16745889,flatShading:!0}),oc=gs+Ci+.8,ac=ws-.7,Ri=new ot;Ri.position.set(oc,.6,ac),Ri.rotation.y=-Math.PI/2.5;const ya=new w(new U(1.5,.08,.6),sc);ya.position.y=.04,ya.castShadow=!0,Ri.add(ya);const oo=new w(new U(.6,.08,.6),sc);oo.position.set(-.55,.18,0),oo.rotation.z=.42,oo.castShadow=!0,Ri.add(oo),this.castleGroup.add(Ri),this.castleInteractables.push({id:"lie_lounger_1",name:"日光浴 (躺椅)",x:oc,y:.6,z:ac,triggerRadius:1.3});const rc=gs+Ci+.8,cc=ws+.7,lc=Ri.clone();lc.position.set(rc,.6,cc),this.castleGroup.add(lc),this.castleInteractables.push({id:"lie_lounger_2",name:"日光浴 (躺椅)",x:rc,y:.6,z:cc,triggerRadius:1.3});const Li=new ot;Li.position.set(Y,.72,I);const xa=new w(new U(4,.4,1.2),c);xa.position.y=.2,xa.castShadow=!0,Li.add(xa);const Qh=new U(.48,.68,1.2),ao=new w(Qh,c);ao.position.set(-2+.24,.34,0),ao.castShadow=!0,Li.add(ao);const hc=ao.clone();hc.position.x=2-.24,Li.add(hc);const td=new U(4,.68,.35),va=new w(td,c);va.position.set(0,.5,-.42),va.castShadow=!0,Li.add(va),this.castleGroup.add(Li),this.castleInteractables.push({id:"sit_sofa",name:"坐下大沙发",x:Y,y:.72,z:I+.8,triggerRadius:1.5});const Pi=new ot;Pi.position.set(z,.72,I-1.2);const _a=new w(new U(1.5,.72,.65),d);_a.position.y=.36,_a.castShadow=!0,Pi.add(_a);const ro=new w(new K(.5,.5,.05,16),new V({color:16766720}));ro.rotateX(Math.PI/2),ro.position.set(0,1.3,-.28),ro.castShadow=!0,Pi.add(ro);const Ma=new w(new K(.44,.44,.06,16),new _t({color:8445674,transparent:!0,opacity:.85}));Ma.rotateX(Math.PI/2),Ma.position.set(0,1.3,-.26),Pi.add(Ma);const Sa=new w(new K(.28,.28,.42,12),c);Sa.position.set(0,.21,.55),Sa.castShadow=!0,Pi.add(Sa),this.castleGroup.add(Pi),this.castleInteractables.push({id:"wardrobe",name:"整理仪容 (试衣镜)",x:z,y:.72,z:I-.6,triggerRadius:1.5});const Sn=new ot;Sn.position.set(vt,S+.15,I-1.2);const ba=new w(new U(2.6,.32,2.2),new V({color:16766720,flatShading:!0}));ba.position.y=.16,ba.castShadow=!0,Sn.add(ba);const co=new w(new U(2.4,.28,2),l);co.position.set(0,.32,0),co.castShadow=!0,co.receiveShadow=!0,Sn.add(co);const ed=new U(.72,.1,.42),ys=new w(ed,c);ys.position.set(-.55,.5,-.75),ys.rotation.x=.12,ys.castShadow=!0,Sn.add(ys);const dc=ys.clone();dc.position.x=.55,Sn.add(dc);const nd=new V({color:16766720,flatShading:!0}),id=new K(.03,.03,2,8),lo=new w(id,nd);lo.position.set(-1.2,1,-.9),lo.castShadow=!0,Sn.add(lo);const uc=lo.clone();uc.position.x=1.2,Sn.add(uc);const sd=new V({color:16761553,transparent:!0,opacity:.5,side:me}),Ea=new w(new K(1.2,1.4,.35,12,1,!0),sd);Ea.position.set(0,2,-.45),Ea.castShadow=!0,Sn.add(Ea),this.castleGroup.add(Sn),this.castleInteractables.push({id:"lie_bed",name:"小憩睡下 (公主床)",x:vt,y:S+.15,z:I-1.2,triggerRadius:1.6});const od=new U(.18,.02,.18),ad=new _t({color:16758725,transparent:!0,opacity:.85});for(let Zt=0;Zt<25;Zt++){const Wt=new w(od,ad),oe=(Math.random()-.5)*26,ye=(Math.random()-.5)*26-2,xe=1+Math.random()*11;Wt.position.set(oe,xe,ye),Wt.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,0),this.castleGroup.add(Wt),this.sakuraList.push({mesh:Wt,velocity:new L((Math.random()-.5)*.4,-.5-Math.random()*.5,(Math.random()-.5)*.4),rotSpeed:new L(Math.random()*1.2,Math.random()*1.2,0),phase:Math.random()*Math.PI*2})}}updateCastleFrame(t,e){if(this.sakuraList){if(this.sakuraList.forEach(n=>{n.mesh.position.addScaledVector(n.velocity,t),n.mesh.rotation.x+=n.rotSpeed.x*t,n.mesh.rotation.y+=n.rotSpeed.y*t,n.mesh.position.x+=Math.sin(e*1.5+n.phase)*.005,n.mesh.position.y<=.6&&(n.mesh.position.y=11+Math.random()*3,n.mesh.position.x=(Math.random()-.5)*22,n.mesh.position.z=(Math.random()-.5)*22-2)}),this.player){const n=this.player.position.x,i=this.player.position.z;if(Math.sqrt((n- -11)*(n- -11)+(i-2)*(i-2))<3&&(this.player.position.y>=.58&&(this.player.position.y=.52,this.player.velocity.y=0,this.player.isGrounded=!0),Math.sqrt(this.player.velocity.x*this.player.velocity.x+this.player.velocity.z*this.player.velocity.z)>.05&&e-this.lastCastleWaterStepTime>.32)){this.lastCastleWaterStepTime=e;const r=new zs(.01,.28,12),c=new _t({color:16745889,transparent:!0,opacity:.6,side:me}),l=new w(r,c);l.rotateX(-Math.PI/2),l.position.set(n,.612,i),this.castleGroup.add(l),this.castleRipples.push({mesh:l,geometry:r,material:c,size:.01,maxSize:.65,speed:1.4,maxOpacity:.6})}}for(let n=this.castleRipples.length-1;n>=0;n--){const i=this.castleRipples[n];i.size+=i.speed*t,i.mesh.scale.set(i.size*5,i.size*5,1),i.material.opacity=i.maxOpacity*(1-i.size/i.maxSize),i.size>=i.maxSize&&(this.castleGroup.remove(i.mesh),i.geometry.dispose(),i.material.dispose(),this.castleRipples.splice(n,1))}}}}window.gameApp=new lw;
